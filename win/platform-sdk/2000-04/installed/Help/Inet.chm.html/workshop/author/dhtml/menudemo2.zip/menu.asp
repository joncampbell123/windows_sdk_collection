<% @LANGUAGE="JScript" %>
<%
	// -------------------------------------------------------------
	// SERVER-SIDE SNIFF
	// -------------------------------------------------------------

	function BrowserData(sUA) {
		var iMSIE = sUA.indexOf("MSIE");
		this.userAgent = sUA;
		this.browser = (iMSIE > -1) ? "MSIE" : "Other";
		this.majorVer = parseInt(sUA.substring(iMSIE + 5, iMSIE + 6));
		this.getsMenus = ("MSIE" == this.browser && 4 <= this.majorVer);
	}
	var oBD = new BrowserData(new String(Request.ServerVariables("HTTP_USER_AGENT")));
%>	
<HTML>
<HEAD>
<TITLE>SBN Server Menu Demo</TITLE>
<SCRIPT LANGUAGE="JavaScript"><!--  

	// --------------------------
	// CLIENT-SIDE SNIFF
	// --------------------------

	function BrowserData(sUA) {
		var iMSIE = sUA.indexOf("MSIE");
		this.userAgent = sUA;
		this.browser = (-1 != iMSIE) ? "MSIE" : "Other";
		this.majorVer = parseInt(sUA.substring(iMSIE + 5, iMSIE + 6));
		this.getsMenus = ("MSIE" == this.browser && 4 <= this.majorVer);
	}
	var oBD = new BrowserData(navigator.userAgent);

//--></SCRIPT>
<%
	if (oBD.getsMenus)
	{
		Response.Write('<SCRIPT SRC="/menudemo/menus.js"></SCRIPT> \n');
		Response.Write('<LINK REL="stylesheet" TYPE="text/css" HREF="/menudemo/menus.css"></SCRIPT> \n');
	}
%>
</HEAD>
<BODY>
<H1>Server Menu Demo</H1>

<TABLE ID="tblMenu" CELLPADDING="0" CELLSPACING="0" BORDER="0">
   <TR>  
      <TD ALIGN="left" VALIGN="top">
         <A HREF="http://www.microsoft.com/workshop/server/toc.asp#nextgen"><IMG ID="imgMenuTitle1" CLASS="clsMenuTitle" SRC="server-nextgen-navb.gif" WIDTH="140" HEIGHT="27" BORDER=0 ALIGN="top" ALT="Next Generation" /></A>
      </TD>
   </TR>
   <TR>
      <TD ALIGN="left" VALIGN="top">
         <A HREF="http://www.microsoft.com/workshop/server/toc.asp#nextgen"><IMG ID="imgMenuTitle2" CLASS="clsMenuTitle" SRC="server-asp-navb.gif" WIDTH="140" HEIGHT="24" BORDER=0 ALIGN="top" ALT="ASP" /></A>
      </TD>
   </TR>
   <TR>
      <TD ALIGN="left" VALIGN="top">
         <A HREF="http://www.microsoft.com/workshop/server/toc.asp#nextgen"><IMG ID="imgMenuTitle3" CLASS="clsMenuTitle" SRC="server-feature-navb.gif" WIDTH="140" HEIGHT="24" BORDER="0" ALIGN="top" ALT="Features" /></A>
      </TD>
   </TR>
   <TR>
      <TD ALIGN="left" VALIGN="top">
         <A HREF="http://www.microsoft.com/workshop/server/toc.asp#nextgen"><IMG ID="imgMenuTitle4" CLASS="clsMenuTitle" SRC="server-toolbox-navb.gif" WIDTH="140" HEIGHT="24" BORDER=0 ALIGN="top" ALT="Toolbox" /></A>
      </TD>
   </TR>
   <TR>
      <TD ALIGN="left" VALIGN="top">
         <A HREF="http://www.microsoft.com/workshop/server/toc.asp#nextgen"><IMG ID="imgMenuTitle5" CLASS="clsMenuTitle" SRC="server-components-navb.gif" WIDTH="140" HEIGHT="24" BORDER=0 ALIGN="top" ALT="Components" /></A>
      </TD>             
   </TR>
   <TR>
      <TD ALIGN="left" VALIGN="top">
         <A HREF="http://www.microsoft.com/workshop/server/toc.asp#nextgen"><IMG ID="imgMenuTitle6" CLASS="clsMenuTitle" SRC="server-scenario-navb.gif" WIDTH="140" HEIGHT="24" BORDER=0 ALIGN="top" ALT="Scenarios" /></A>
      </TD>     
   </TR>
   <TR>
      <TD ALIGN="left" VALIGN="top">
         <A HREF="http://www.microsoft.com/workshop/server/toc.asp#nextgen"><IMG ID="imgMenuTitle7" CLASS="clsMenuTitle" SRC="server-bugz-navb.gif" WIDTH="140" HEIGHT="19" BORDER=0 ALIGN="top" ALT="Bug Zapper" /></A>
      </TD> 
   </TR>
   <TR>
      <TD ALIGN="left" VALIGN="top"><A HREF="http://www.microsoft.com/sitebuilder/magazine/server.asp"><IMG SRC="server-editor-navb.gif" WIDTH="140" HEIGHT="19" BORDER=0 ALT="Editor's View" /></A></TD>
   </TR>
   <TR>
      <TD ALIGN="left" VALIGN="top"><A HREF="http://www.microsoft.com/workshop/server/toc.htm"><IMG SRC="server-toc-navb.gif" WIDTH="140" HEIGHT="19" BORDER=0 ALT="Table of Contents" /></A></TD>
   </TR>
</TABLE>

<%
	if (oBD.getsMenus)
	{
%>
		<!-- #include virtual="/menudemo/menus.inc" -->
<%
	}
%>

<!-- Insert text here -->

</BODY>
</HTML>