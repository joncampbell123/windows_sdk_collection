// MarkProcessorObj.cpp : Implementation of CMarkProcessorObj
#include "stdafx.h"
#include "MarkProcessor.h"
#include "MarkProcessorObj.h"

/////////////////////////////////////////////////////////////////////////////
// CMarkProcessorObj

