// ClientAppDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ClientApp.h"
#include "ClientAppDlg.h"

#include "CallBackObj.h" 

#include "AboutDlg.h"

//midl generated code with interface prototypes
#include <DCOMServer.h>		
//CLSID and IID
#include <DCOMServer_i.c>	  

#include <BaseClassDataProcessor.h>
const IID IID_IBaseClassDataProcessorObj = {0xFFD77865,0x53CF,0x11D2,{0x91,0x95,0x00,0x60,0x08,0xA4,0xFB,0x73}};

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CClientAppDlg, CDialog)
	//{{AFX_MSG_MAP(CClientAppDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnSubmit)
	ON_WM_DESTROY()
	ON_MESSAGE(WM_RECEIVE_DATA_FROM_PLUG_IN, OnMessageFromPlugIn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientAppDlg dialog

//----------------------------------------------------------------------------------
CClientAppDlg::CClientAppDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CClientAppDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CClientAppDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_pIDCOMServerObj = NULL;

	m_pIServerCallBack = NULL;
}

//----------------------------------------------------------------------------------
CClientAppDlg::~CClientAppDlg()
{
	if(m_pIDCOMServerObj != NULL)
	{
		m_pIDCOMServerObj->Release();
		m_pIDCOMServerObj = NULL;
	}
}

//----------------------------------------------------------------------------------
void CClientAppDlg::OnDestroy() 
{
	for (int i = 0; i < m_ListBoxWithCLSIDs.GetCount(); i++)
	{
		CString* psClsid = (CString*)m_ListBoxWithCLSIDs.GetItemData(i);
		delete psClsid;
	}

	CDialog::OnDestroy();
}

//----------------------------------------------------------------------------------
void CClientAppDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClientAppDlg)
	DDX_Control(pDX, IDC_CURRENCIES,m_ListBoxCurrencies);
	DDX_Control(pDX, IDC_LIST_PLUG_INS, m_ListBoxWithCLSIDs);
	//}}AFX_DATA_MAP
}

//----------------------------------------------------------------------------------
BOOL CClientAppDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	//let's create the DCOM server and QI for our interface

	IUnknown* pUnk = NULL;
	HRESULT hRes = ::CoCreateInstance(CLSID_DCOMServerObj, NULL, CLSCTX_ALL,
									  IID_IUnknown, (void**)&pUnk);
	if(SUCCEEDED(hRes))
	{
		//get our IDCOMServerObj into our class member
		hRes = pUnk->QueryInterface(IID_IDCOMServerObj, (void**)&m_pIDCOMServerObj);
		pUnk->Release();
		pUnk = NULL;
		ASSERT(SUCCEEDED(hRes));
		ASSERT(m_pIDCOMServerObj != NULL);

		if(SUCCEEDED(hRes))
		{
			//create the CCallBackObj and set the owner window 
			hRes = CComObject<CCallBackObj>::CreateInstance(&m_pIServerCallBack);
			ASSERT(SUCCEEDED(hRes));
			if(SUCCEEDED(hRes))
			{
				m_pIServerCallBack->SetOwnerWindow(this);

				//register the interface with the DCOM Server
				hRes = m_pIDCOMServerObj->RegisterCallBack(m_pIServerCallBack);
				ASSERT(SUCCEEDED(hRes));
			}
		}
	}


	//add our server supported currencies to the list box.
	m_ListBoxCurrencies.AddString(_T("Dollar"));
	m_ListBoxCurrencies.AddString(_T("Mark"));
	m_ListBoxCurrencies.AddString(_T("Yen"));
	m_ListBoxCurrencies.SetCurSel(0);

	
	/*
	Fill the list box with available plug-ins.

	Each plug-in has an easy to use name and a CLSID as string.  All plug-ins support
	the same interface.

    The easy to use name goes in the list box to display the CLSID as string
	goes in the list box's item data.
	*/

	BOOL bCLSID = FALSE;
	CString sKey = _T("Software\\PantherCurrencyComponents\\AvailablePlugInDataProcessors\\");
	
	//first open the registry key
	HKEY hKey = NULL;
	LONG lRes = ::RegOpenKeyEx(HKEY_LOCAL_MACHINE, sKey, 0, 		                         
							   KEY_READ, &hKey);
	if (lRes == ERROR_SUCCESS && hKey != NULL)
	{
		DWORD dwIndex = 0;
		DWORD size;
		TCHAR buff[128];
		LONG  lRes;
		DWORD type;
		byte  buff2[128];
		DWORD size2 = 128;

		//Read registry entries until the end of key is reached
		while(TRUE)
		{
			buff[0] = '\0';
			size = 128;
			lRes = ::RegEnumValue(hKey, dwIndex++, buff, &size, 
								  NULL, &type, buff2, &size2);
			if(lRes == ERROR_SUCCESS)
			{
				CString sKeyName = buff;
				int iIndex = m_ListBoxWithCLSIDs.AddString(sKeyName);
				CString* psClsid = new CString(buff2);
				m_ListBoxWithCLSIDs.SetItemData(iIndex, (DWORD)psClsid);

				CString sTemp = *psClsid;
				sTemp += _T("\n");
				TRACE(sTemp);
			}
			else
			{
				break;
			}
		}
		
		// now close the registry key
		::RegCloseKey(hKey);
		hKey = NULL;
	}

	if(m_ListBoxWithCLSIDs.GetCount())
		m_ListBoxWithCLSIDs.SetCurSel(0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

//----------------------------------------------------------------------------------
void CClientAppDlg::OnSubmit() 
{
	if(m_pIDCOMServerObj)
	{
		//get data and submit
		UpdateData(TRUE);

		int iIndex = m_ListBoxCurrencies.GetCurSel();
		CString sCurrency;
		m_ListBoxCurrencies.GetText(iIndex, sCurrency);

		long lValue = -1;

		if(sCurrency.CompareNoCase(_T("Dollar")) == 0)
			lValue = 1;
		else if(sCurrency.CompareNoCase(_T("Mark")) == 0)
			lValue = 2;
		else if(sCurrency.CompareNoCase(_T("Yen")) == 0)
			lValue = 3;

		else
		{
			ASSERT(false);
			return;
		}

		m_pIDCOMServerObj->ProcessRequest(lValue);
	}
}

//----------------------------------------------------------------------------------
LRESULT CClientAppDlg::OnMessageFromPlugIn(WPARAM wParam, LPARAM lParam)
{
	long lValueFromServer = (long) lParam;

	//first set the original dollar conversion
	CString sOneDollarGetsYou = _T("1 Dollar gets you ");
	
	CString sValue;
	sValue.Format(_T("%ld "), lValueFromServer);
	sOneDollarGetsYou += sValue;

	CString sTargetCurrency;
	int iIndex = m_ListBoxCurrencies.GetCurSel();
	m_ListBoxCurrencies.GetText(iIndex, sTargetCurrency);
	sOneDollarGetsYou += sTargetCurrency;
	sOneDollarGetsYou += _T("(s)");


	CWnd* pWnd = GetDlgItem(IDC_STATIC_RESULT1);
	pWnd->SetWindowText(sOneDollarGetsYou);
	
	//ok, go to the listbox and see what plug in the user has highlighed.
	//CoCreate the plug-in and have it process the value

	/*
	1)  Get index from listbox.
	2)  Get string from item data.
	3)	Convert to CLSID
	4)  CoCreateInstance
	5)  Call interface method.
	*/

	iIndex = m_ListBoxWithCLSIDs.GetCurSel();
	
	if(iIndex < 0)
	{
		::MessageBox(NULL, _T("Please highlight a plug-in"), _T("Message"), MB_OK);
		return -1;
	}

	CString sPlugInCurrency;
	m_ListBoxWithCLSIDs.GetText(iIndex, sPlugInCurrency);
	
	if(sPlugInCurrency.Find(_T("Dollar")) != -1)
		sPlugInCurrency = _T("Dollar");
	else if(sPlugInCurrency.Find(_T("Mark")) != -1)
		sPlugInCurrency = _T("Mark");
	else if(sPlugInCurrency.Find(_T("Yen")) != -1)
		sPlugInCurrency = _T("Yen");
	else
	{
		ASSERT(false);
	}


	CString* pstrCLSID = (CString*)m_ListBoxWithCLSIDs.GetItemData(iIndex);
	CComBSTR bstr(*pstrCLSID);
	CLSID clsid;

	HRESULT hRes = ::CLSIDFromString(bstr, &clsid);
	if(!SUCCEEDED(hRes))
	{
		::MessageBox(NULL, _T("Higlighted item does not have a valid CLSID"), _T("Message"), MB_OK);
		return -1;
	}

	IUnknown* pUnk = NULL;
	hRes = CoCreateInstance(clsid, NULL, CLSCTX_ALL, 
							IID_IUnknown, (void**)&pUnk);
	if(SUCCEEDED(hRes))
	{
		IBaseClassDataProcessorObj* pIDataProcessor = NULL;
		hRes = pUnk->QueryInterface(IID_IBaseClassDataProcessorObj, (void**) &pIDataProcessor);
		pUnk->Release();

		if(SUCCEEDED(hRes))
		{
			float fltValueFromDataProcessor;
			hRes = pIDataProcessor->ProcessData(1, &fltValueFromDataProcessor);
			ASSERT(SUCCEEDED(hRes));
			pIDataProcessor->Release();

			//sTargetCurrency contains target currency
			CString sMessage = _T("1 ");
			sMessage += sTargetCurrency;
			sMessage += _T(" gets you ");
			sValue.Format(_T("%f "), ( ((float)1)/ fltValueFromDataProcessor / ((float)lValueFromServer)));
			sMessage += sValue;
			sMessage += sPlugInCurrency;
			sMessage += _T("(s)");

			pWnd = GetDlgItem(IDC_STATIC_RESULT2);
			pWnd->SetWindowText(sMessage);
		}
		else
		{
			::MessageBox(NULL, _T("Selected component does not support IID_IBaseClassDataProcessorObj interface"), 
						 _T("Message"), MB_OK);
		}
	}
	else
	{
		::MessageBox(NULL, _T("Currently highlighted COM object not found"), _T("Message"), MB_OK);
	}

	return 0;
}

//----------------------------------------------------------------------------------
void CClientAppDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

//----------------------------------------------------------------------------------
void CClientAppDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//----------------------------------------------------------------------------------
HCURSOR CClientAppDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


