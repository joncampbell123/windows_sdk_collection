// YenProcessorObj.cpp : Implementation of CYenProcessorObj
#include "stdafx.h"
#include "YenProcessor.h"
#include "YenProcessorObj.h"

/////////////////////////////////////////////////////////////////////////////
// CYenProcessorObj

