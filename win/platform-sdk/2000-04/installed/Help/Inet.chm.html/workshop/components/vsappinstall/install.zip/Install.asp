<% @LANGUAGE="JScript" %>
<HTML>
<HEAD>
<%
  // -----------------------------------------------------------
  // MetaData constructor function
  // Authors/Editors enter document-specific data here to populate INC'd elements
  // -----------------------------------------------------------

	function MetaData()
	{
		// -----------------------------------------------------------
		// Generic information entered for every document
		// Put in HEAD TITLE and META tags
		// -----------------------------------------------------------

		this.title = "Installing Windows Applications via the Web with Visual Studio 6.0";
		this.description = "Using Visual Studio download tools to compress applications and components into CAB files and self-extracting executable files for distribution over the Internet";
		this.keywords = "Visual Studio 6.0, code download, CAB files, cabinet files, security, components";
		this.robots = "All";

		this.author = "Michael Edwards";
		this.posted = "11/23/98";
		this.updated = "";

		// -----------------------------------------------------------
		// Optional DocDataBlock in footer-xxx.inc
		// TENTATIVE
		// -----------------------------------------------------------

		this.displayDocDataBlock = false;
	}

	var oMD = new MetaData();
%>
<!-- #include virtual="/sitebuilder/shared/inc/header.inc" -->

<SCRIPT LANGUAGE="Javascript"><!--

	// -----------------------------------------------------------
	// window_load()
	// Container function for load.
	// -----------------------------------------------------------

	function window_load()
	{
		if (oBD.getsNavBar) if ("function" == typeof(InitNavLinks)) InitNavLinks();
		if (oBD.getsNavBar) if ("function" == typeof(CheckToTop)) CheckToTop();
	}
	window.onload = window_load;

//--></SCRIPT>

</HEAD>

<BODY TOPMARGIN="0" LEFTMARGIN="0" MARGINHEIGHT="0" MARGINWIDTH="0" BGCOLOR="#FFFFFF">

<!-- #include virtual="/sitebuilder/shared/inc/doctop-wks.inc" -->

<DIV CLASS="clsDocBody">

<!-- DOCUMENT CONTENT START -->


<h1><A NAME="top" IDX_TYPE="sbngen" IDX_CONCEPT="stopindex;Applications, installing via Internet, creating download packages with VS 6.0">Installing Windows Applications via the Web with Visual Studio 6.0</A></h1>
<HR CLASS="clsTransHR" />
<H6><A NAME="top2" IDX_TYPES="sbngen" IDX_CONCEPT="Application, Web installation with Visual Studio 6.0"></A></H6>
<p>Michael Edwards<br>
Developer Technology Engineer</p>
<P>November 23, 1998</P>
<p>
<b>Contents</b><br>
<a href="#intro">Introduction</a><br>
<a href="#setup">Creating a Setup Application</a><br>
&nbsp;&nbsp;&nbsp;<a href="#specing">Specifying Project Properties</a><br>
&nbsp;&nbsp;&nbsp;<a href="#extract">Building and Deploying</a><br>
<a href="#config">Making Sure the Target Computer Can Run WFC Applications</a><br>
&nbsp;&nbsp;&nbsp;<a href="#vmjava">Detecting the Microsoft Virtual Machine for Java</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#object">Using the &lt;OBJECT&gt; tag</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#notie">When the client isn't using Internet Explorer</a><br>
&nbsp;&nbsp;&nbsp;<a href="#otherwfc">Other WFC Application Requirements</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#WJVIEW">WJVIEW.exe</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#systemcom">Dependencies on system- or vendor-supplied COM components</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#depends">Dependencies on your own COM Components</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#buildcom">Building distribution units for custom components</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#cabs">Building a cabinet file the old-fashioned way</a><br>
<a href="#summary">Summary</a>
<p>
<a name="intro"></a><h2>Introduction</h2>
<p>Microsoft&reg; Visual Studio&#174; 6.0 introduces a whole new set of features for automatically packaging your project outputs into &quot;distribution units.&quot; This means a couple of things:  first, you are no longer required to learn all the incantations and myriad command-line switches of the several tools required to create a code-signed download package, and second, a setup application can be automatically included. What's the catch? You will need to learn a new set of Visual Studio 6.0 dialogs to provide the necessary information for building your package and setting the installation parameters. What's the payoff? You can create the self-extracting executable file that goes directly onto your Web server in one step from within the Visual Studio development environment. Further, because you don't need to use any server-side scripting, the same Web page can be used to install your application from other distribution media (such as CD-ROM or DVD). 
</p>
<p>
<A HREF="#top" CLASS="clsBackTop"><IMG SRC="/msdn-online/shared/graphics/top.gif"  WIDTH="18" HEIGHT="8" BORDER="0" ALT="Top">Back to top</A>
</p>
<a NAME="setup" IDX_TYPES="sbngen" IDX_CONCEPT="Setup Application:  Creating"></a><h2>Creating a Setup Application</h2>
<p>I will now discuss how to build a setup application based upon a Visual J++&#8482; 6.0 custom browser project I created (and that you can download from my <a href="htmlcontrol.asp"> browser install page</a>). Even though I used a Visual J++ 6.0 sample, you can apply this technique to create a download package and setup application from any other Visual Studio 6.0 tool, or even other application-development tools (such as Delphi by Inprise). 
</p>
<a name="specing"></a><h3>Specifying Project Properties</h3>
<p>While Visual Studio 6.0 can produce other output formats, the most appropriate download package for installing a stand-alone Windows application from a Web page is a self-extracting executable. Therefore I am going to confine my explanation to the &quot;Self-extracting Setup (.EXE)&quot; package type. 
</p>
<p>Below is the <B>Properties</B> dialog box (accessed from the <b>Project</b> menu) with the "Output Format" tab selected for my MyWebBrowser project. This tab includes all the information needed to build a package and set up the application. 
</p>
<p><img src="output.gif" WIDTH="350" HEIGHT="324"><br>
<b>Figure 1. "Output Format" tab of HTMLControl sample Properties dialog box</b> 
</p>
<p>There are three things you need to do in this dialog. First, select the "Configuration" you will be working with, debug or retail, from the drop-down menu. This option doesn't establish whether you are building a debug or release application, but whether changes to the output format settings apply to the debug or retail version. (You can choose whether you are building a debug or release version from the Build Configuration item in the <b>Build</b> menu.) 
</p>
<p>
Second, choose "Packaging type." The most appropriate packaging type for Windows applications, and the one I'll discuss at length in this article, is the Self-extracting Setup (.EXE). It's the only executable output format that can be digitally signed with your software publishing credentials. If your users don't require assurance, and you know your download has not been tampered with, you could choose the Zip Archive (.ZIP) option. Of course, this requires fairly advanced users who will know what to do with your archive.  
</p>
<p>Third, select the files to include in the package that will be extracted on the target computer. In this case, &quot;package&quot; refers to the code-signed cabinet file that will contain all the files that need to be distributed with your application. In my case, I only needed the .class and .resources files (the resources file has information about the controls and forms in WFC applications). If I'd wanted to include other files, such as sample Web pages, or maybe some image or audio files, I could have directly added them from the Package Contents area of the dialog. The &quot;Outputs of type&quot; edit field and &quot;These outputs&quot; checklist are two different ways to add files that are part of your project. The <b>Include Additional Files</b> button brings up a standard file dialog that enables you to select 
other, non-project files to include (I'll show how this is useful in a minute). 
</p>
<p>The options available in the <b>Advanced</b> dialog box (activated by clicking on the <b>Advanced</b> button next to the "Packaging type" drop-down menu) depend on the packaging type. The <b>Advanced</b> dialog box for the Self-extracting Setup (.EXE) package type is shown below: 
</p>
<p><img src="target.gif" WIDTH="350" HEIGHT="314"> 
<br><b>Figure 2. Advanced Properties dialog box with &quot;Target&quot; tab open</b> 
</p>
<p>
The &quot;Target&quot; tab specifies the destinations and titles your application will assume once installed. Providing an entry in the &quot;Application title&quot; option enables the setup application to register your application with the <B>Add/Remove Programs</B> Control Panel program (so users can uninstall your application). &quot;Installation Folder&quot; specifies the location to extract the contents of your application package to, which can be installed under the &quot;Program Files&quot; folder if you check the "Install under the 'Program Files' folder" checkbox (the user can override this location at install time). You can also create a <b>Start</b> menu entry using the &quot;Shortcut name&quot; textbox. Activating the "Create an entry in the Start menu" checkbox for your application activates the &quot;Command-line Program&quot; options; in my case, WJVIEW.exe will execute with the argument &quot;browser&quot; (the main application class that extends wfc.ui.Form and implements the <B>main()</B> method). You can pass command line arguments to a method by including them in the &quot;Argument&quot; field after your startup class name. 
</p>
<p>The &quot;Signing&quot; tab in this dialog specifies the settings for code-signing your package with your software publisher credentials. You can choose to automatically sign your package with a test certificate included with Visual J++ 6.0. If you test-sign the package, a timestamp is not generated, although you can indicate a timestamp server (Verisign's is used by default). This feature is a HUGE time-saver. Those of you who haven't had to figure out the command-line code-signing tools will just not fully appreciate this (that's a good thing). Because I live in the United States, it only costs US$20 to get an Individual Software Publisher (Class 2) Digital ID from <a href="http://www.verisign.com">Verisign</a> <IMG SRC="/sitebuilder/graphics/leave-ms.gif" WIDTH="33" HEIGHT="11" BORDER="0" ALT="Non-MS link">. In order to prove it really works, I obtained my own Digital ID and signed all the executable downloads in this article with it. I just clicked the &quot;Use certificate file&quot; radio button and navigated to my certificate and private key files after clicking the <B>Browse</B> button.
<p><img src="signing.GIF" WIDTH="350" HEIGHT="314"><br><b>Figure 3: Advanced Properties dialog box with &quot;Signing&quot; tab active</b> 
</p>
<p><a name="NestedSetup"></a>The &quot;Nested Setups&quot; tab allows you to insert other setup applications within your own package. The embedded setup application is extracted and run at install time (before your own application). For example, self-extracting executables for the software dependencies of your application can be separately installed from a nested setup file. If you have struggled to figure out how to nest setup applications, you'll really like this feature. Note that you will have to first add the desired setup application files to your package using the <b>Include Additional Files</b> button on the main &quot;Output Format&quot; tab before they will show up in the Nested Setups listbox. Also, the additional files will not show up in the &quot;Nested Setups&quot; tab until you select <b>OK</b> in the &quot;Output Format&quot; dialog and reopen it.</p>
<p><a name="sysdir"></a>The &quot;System Directory Installation&quot; tab allows you to install any of your files directly into the Windows system folder. This feature is useful if there are certain shared files in your application that you don't want removed if the user uninstalls your application. It can also be used to <a href="#WJVIEW">install the WJVIEW.exe application</a>.</p>
<p>There are two other tabs in the &quot;Advanced Properties&quot; dialog that I did not use in my sample application but will go over briefly.</p>
<a name="redist">The &quot;Microsoft System Libraries&quot; tab includes the packages that are     installed in the &lt;Program Files&gt;\Microsoft Visual Studio\Common\IDE\IDE98\Redist folder. For version 6.0, this includes the MSJavX86.exe self-extracting setup component which installs the Microsoft Virtual Machine for Java, the WFC classes, and the md_ac.exe self-extracting setup component (which installs the data access components for wfc.data.* classes). If you include these system components in your package, they will be automatically installed on the target computer before your own application. If one or both of these system components are already up-to-date on the target computer, they will not be installed. Including these redistributable components in your package is by far the easiest and most trouble-free approach to ensuring the target computer can run your application. The only issue that might make you think twice is any requirement to keep your package as small as possible for Internet download (or to conserve intranet bandwidth). After all, you don't want to force users to download many extra megabytes to get your application if they don't need to. However, as I explain below in <a href="#config">Making Sure the Target Computer Can Run WFC Applications</a>, not including these redistributable components in your package can mean a lot of extra work to make sure the target computer can run your application.
</p>
<p>
The &quot;Remote Components&quot; tab is disabled on my computer because I havn't registered any remote DCOM computers. If your project uses remote DCOM, you'll have to add the DCOM server files to your project (see &quot;For More Information&quot; below).
<p><br></p>
<h3><a name="extract"></a>Building and Deploying</h3>
<p>Once you have made all your selections in the &quot;Output Format&quot; tab, simply build your project to create the self-extracting executable file. This file just needs to be run on the target computer to install your application. To help you with that, Visual Studio 6.0 includes new features for deploying your project outputs on your development computer, directly to a Web server on your intranet, or even to the Internet. So just build your projects, and all the necessary outputs are automatically copied to all the right places. This can be real convenient, especially if your solution includes multiple projects. However, I did not play with the deployment features very much, so I'm not going to go over deployment any further in this article. Once the package is deployed on a Web server, you just need to create the page that will host the download using a simple anchor tag:</p>
<p><PRE CLASS="clsCode">&lt;A href=&quot;setupApp.exe&quot;&gt;Download and run</a>&lt;/A&gt; the self-extracting setup application. </PRE>
</p>
<p>In fact, this is the method I used in my <a href="htmlcontrol.asp">custom browser application install page</a>.</p>
<h4>For more information </h4>
<p>If you're like me, you sometimes forge ahead before taking the time to really look through all the docs. This can cost you time when the docs are good. In my own case, I took the time to skim through the Visual J++ 6.0 documentation, but neglected to look at the Visual Studio 6.0 docs. That was a mistake, because the new packaging and deployment features are part of Visual Studio 6.0 (meaning they apply to the whole Visual Studio family). Read all about the new packaging and deployment features in the documentation at:</p>
<ul>
    <li>MSDN Library Visual Studio 6.0/Visual Studio 
    Documentation/Component, Design, and Analysis Tools/Solution Building and 
    Packaging Reference
    <li>MSDN Library Visual Studio 6.0/Visual Studio 
    Documentation/Component, Design, and Analysis Tools/Solution Deployment 
    Reference</li></ul>
<p>
<A HREF="#top" CLASS="clsBackTop"><IMG SRC="/workshop/graphics/top.gif"  WIDTH="18" HEIGHT="8" BORDER="0" ALT="Top">Back to top</A>
</p>
<a name="config" IDX_TYPES="sbngen" IDX_CONCEPT="Setup Application, Checking dependencies: WFC applications"></a><h2>Making Sure the Target Computer Can Run WFC Applications</h2>
<p>Packaged products sold through &quot;normal&quot; distribution channels are always labeled to indicate application requirements such as operating system, minimum memory, disk space, and so on. If you distribute your application on the Web, your installation page should include the same type of information. However, there are many obscure application requirements that you can't expect end users to know, especially things like the version and vendor for various system dependencies. The problem is that some end users will have up-to-date system components, while others won't. And of course, most end users won't know the difference. In this case, descriptive labeling is insufficient and inappropriate -- you have to take specific steps on behalf of your customer to ensure required system components are installed and up to date.</p>
<p> As I mentioned above, by far the safest and easiest approach to ensure the target computer will run your application is to <a href="#redist">embed the setup applications for all your dependent components in your single, self-extracting executable</a>. All the end-user has to do is click one download link and all your dependencies, as well as your application, are installed. The problem with this easy solution is size. For example, WFC applications depend upon a recent version of the Microsoft VM for Java, and the MSJavX86.exe redistributable is over 6 MB! If your situation is such that you don't have to worry too much about size, then great, but since this is an article about installing from Web pages, I will go the extra mile and talk about the issues you'll need to deal with if you choose to not include your dependent components in your application package.</p>
<p> I am going to focus on the types of dependencies common in WFC applications, but the same idea applies to any application. It comes down to carefully thinking about what dependencies your application has, how you determine whether the target is up-do-date, and how you bring it up to date.</p>
<a name="vmjava" IDX_TYPES="sbngen" IDX_CONCEPT="Setup application, checking dependencies: Microsoft VM for Java"></a><h3>Detecting the Microsoft Virtual Machine for Java</h3>
<p>WFC applications require the Microsoft� Virtual Machine for Java (version 5.00.2925 or greater) and the Microsoft Windows� Foundation Classes (WFC) for Java. When you install a WFC application, therefore, it is important to make sure the client computer has compatible VM 
and WFC libraries. There are two ways you can accomplish this "invisibly" (without asking the user to do any investigating), both of which, unfortunately, end up downloading the free redistributable self-extracting executable file MSJAVX86.exe that installs the Microsoft VM for Java. 
</p>
<a name="object"></a><h4>Checking and Updating with the &lt;OBJECT&gt; tag</h4>
<p>Embedding an &lt;OBJECT&gt; tag on your Web page is the easiest and safest method to install the Microsoft VM for Java : 
</p>
<pre class="clsCode">&lt;OBJECT
  CLASSID=&quot;clsid:08B0E5C0-4FCB-11CF-AAA5-00401C608500&quot; WIDTH=0 HEIGHT=0 
  CODEBASE=&quot;http://www.microsoft.com/isapi/redir.dll?prd=JAVAVM&amp;pver=5.00.2910&amp;ar=MSVISUALJ#Version=5,0,2925&quot;&gt;
&lt;/OBJECT&gt; 
</pre>
<p>When Internet Explorer encounters this tag, it will automatically check to see if the indicated CLASSID (which refers to the Java VM component MSJAVA.dll) is at least version 5.0.2925 (as indicated by the &quot;#Version=5,0,2925&quot; piece of the CODEBASE attribute). If not, the browser will automatically download and install the URL in the CODEBASE attribute (which resolves to the installer for the latest VM). The user must approve the download certificate for the Microsoft Virtual Machine for Java (which includes the necessary WFC classes) before the installer will run. If you prefer to download the VM installer from your own server, just modify the URL to point to the self-extracting executable file MSJAVX86.exe wherever it resides. Make sure you include the correct version information &quot;#Version=&quot; string on the end of your URL so the browser can avoid initiating the download if the client's VM is already up to date. It's also a good idea to study the VM redistribution information in the &quot;<a href="#moreinfo">For More Information</a>&quot; section below. 
</p>
<p>Because the &lt;OBJECT&gt; tag technique automatically starts the download operation if the customer's VM needs to be updated, this solution has the same result as embedding the MSJavX86.exe self-extracting setup directly in your application (with the benefit of <em>not</em> having to embed it in your application package). However, since the download operation begins immediately, it is not a good idea to put this tag on the same page the customer sees when they are deciding whether they want to download your application. Instead, they should be taken to a different page that contains the &lt;OBJECT&gt; tag and a link to download and run your application's self-extracting executable.</p>
<p>
The problem with using the &lt;OBJECT&gt; tag method to update the customer's VM is that Netscape browsers don't support the &lt;OBJECT&gt; tag natively. Instead, you could resort to an HTML-only method that requires the user to explicitly request the download: 
</p>
<pre class="clsCode">&lt;P&gt;
This page requires the Microsoft� Virtual Machine for Java, Version 5.00.2925 or greater, 
and the Microsoft Windows� Foundation Classes (WFC) for Java. 
  &lt;A href=&quot;http://www.microsoft.com/isapi/redir.dll?prd=JAVAVM&amp;pver=5.00.2910&amp;ar=MSVISUALJ&quot;&gt;
  Update the required components&lt;/A&gt;.
&lt;/P&gt;
</pre>
<p>Unfortunately, this technique won't detect the VM version before starting the download, so it won't tell the user whether they need the update. Also, although MSJavX86.exe will abort if the end-user's VM is already up to date, they still have to download it first. What would be more useful is the ability to first detect whether the end-user needs to update their VM. 
</p>
<a name="notie" IDX_TYPES="sbngen" IDX_CONCEPT="Setup applications, checking dependencies: non-IE browsers"></a><h4>When the Client Is not Using Internet Explorer</h4>
<p>If you read my recent <a href="/workshop/management/sniffing2.asp">sniffing article</a>, you might conclude that all you need to detect the client's VM is a simple Java applet that applies the <b>com.ms.util.SystemVersionManager</b> or <b>java.lang.System</b> methods. However, neither works for Netscape browsers, because they only tell you what VM Netscape is using. </p>
<p>
So, if the end-user is browsing your install page via a Netscape browser, you need to check the version stamp on the file msjava.dll located in the folder WINDOWS\SYSTEM32 (on Windows NT) or WINDOWS\SYSTEM (on Windows 98). Checking file version stamps on the Windows platform is accomplished using the Win32 FileVersion API, or the new DLLGetVersion API, so a pure scripting solution won't work. Instead, you will need to use either a Netscape plug-in or a Java applet. And either solution requires code-signing your component, because file system access is a protected operation for Web pages. If you still want to go this route, the MSJ article <a href="/msj/0498/c++0498.htm">C++ Q&amp;A with Paul DiLascia</a> <IMG SRC="/sitebuilder/graphics/leave-site.gif" WIDTH="17" HEIGHT="11" BORDER="0" ALT="Non-SBN link"> has example code for checking version stamps.</p>
<p>Given the above issues, the easiest solution is to have two self-extracting executables for your application. The version you use for Netscape browsers should embed the MSJavX86.exe redistributable, while for Internet Explorer browsers you can use the &lt;OBJECT&gt; tag method described above. That way you won't penalize Internet Explorer users who already have up-to-date components, but you can still be assured that customers using Netscape browsers will get the VM they need to run your application. (Note: This method won't screw up Netscape clients, because it won't replace or remove anything required by Netscape's VM.)</p>
<p>You may wish to consider telling the user how they can determine what version, if any, of the Microsoft VM for Java is installed on their machine (and thus whether they need the big or not-so-big download). The easiest way for the user to determine this information by entering "msjava.dll" in the <b>Find Files</b> dialog box (from the <b>Start</b> menu):</p>
<p><img src="msjava.GIF" WIDTH="350" HEIGHT="284"><br><b>Figure 4: Using the Find Files dialog box to locate MSJAVA.dll</b></p>
<p>Right-click on the MSJAVA.dll file (the component that implements the Microsoft VM for Java) in this dialog and select &quot;Properties&quot; to bring up a Property sheet where the &quot;Version&quot; tab indicates the VM version. </p>
<p>I demonstrate this technique in my <a href="htmlcontrol.asp">custom browser application install page</a>.</p>
<h5><a name="moreinfo"></a>For more information</h5>
<p>Documentation regarding <a href="/java/sdk/31/source/redist.htm">redistributable Java components</a> <IMG SRC="/sitebuilder/graphics/leave-site.gif" WIDTH="17" HEIGHT="11" BORDER="0" ALT="Non-SBN link"></p>
<p>Documentation on <a href="/java/sdk/31/source/jsdk_ref_util_systemversionmanager.htm"> com.ms.util.SystemVersionManager</a> <IMG SRC="/sitebuilder/graphics/leave-site.gif" WIDTH="17" HEIGHT="11" BORDER="0" ALT="Non-SBN link"></p>
<p>A Knowledge Base article entitle <a href="http://support.microsoft.com/support/kb/articles/Q163/6/37.asp">INFO:  Availability of Current Build of Microsoft VM for Java</a> <IMG SRC="/sitebuilder/graphics/leave-site.gif" WIDTH="17" HEIGHT="11" BORDER="0" ALT="Non-SBN link"></p>
<p>Another Knowledge Base article entitled <a href="http://support.microsoft.com/support/kb/articles/q169/8/03.asp">INFO: Historical List of Shipping Vehicles for Java VM</a> <IMG SRC="/sitebuilder/graphics/leave-site.gif" WIDTH="17" HEIGHT="11" BORDER="0" ALT="Non-SBN link"></p>
<p>Your support options for the redistributable Microsoft Virtual Machine for Java:<br><a href="http://www.microsoft.com/java/sdk/31/source/support.htm">http://www.microsoft.com/java/sdk/31/source/support.htm</a> <IMG SRC="/sitebuilder/graphics/leave-site.gif" WIDTH="17" HEIGHT="11" BORDER="0" ALT="Non-SBN link"><br><a href="http://msdn.microsoft.com/visualj/technical/support.asp">http://msdn.microsoft.com/visualj/technical/support.asp</a> <IMG SRC="/sitebuilder/graphics/leave-site.gif" WIDTH="17" HEIGHT="11" BORDER="0" ALT="Non-SBN link"> 
</p>
<p>
<A HREF="#top" CLASS="clsBackTop"><IMG SRC="/workshop/graphics/top.gif"  WIDTH="18" HEIGHT="8" BORDER="0" ALT="Top">Back to top</A>
</p>
<a name="otherwfc" IDX_TYPES="sbngen" IDX_CONCEPT="Setup applications, checking dependencies:  COM components"></a><h3>Other WFC Application Requirements</h3>
<p>Some WFC applications depend upon certain COM components and ActiveX&#174; controls for aspects of their functionality. Sometimes these objects are already installed on the target computer, but, again, you can't depend upon that being the case. All WFC applications depend upon WJVIEW.exe being available. </p>
<h4><a name="WJVIEW"></a>WJVIEW.exe</h4>
<p>Any WFC application distributed as a &quot;Self-extracting Executable (.EXE)&quot; requires  the WJView.exe component. WJView is added to the <b>Start</b> menu by the installer (with your main WFC class entered as a command-line parameter). You can't depend upon WJVIEW.exe being installed on the client computer, so you will need to install it yourself using the &quot;Include Additional Files&quot; feature I discussed earlier. (When you install Visual J++ 6.0, the WJVIEW.exe application is copied to your Windows folder.)
</p>
<p>After adding WJVIEW.exe to your package, you need to tell the installer to copy it to the Windows folder when your application files are installed using the <a href="#sysdir">&quot;System Directories&quot; tab</a>).</p>
<a name="systemcom"></a><h4>Dependencies on system- or vendor-supplied COM Components</h4>
<p>Even if your application depends upon COM components included with Windows, you still need to make sure they are installed. For example, my <a href="htmlcontrol.asp">custom browser sample application</a> requires the WebBrowser control and some Internet Explorer 4.01 Shell components, so the install page checks whether the proper browser software is installed on the target computer (and offers links to download them if needed). </p>
<p>Of course, you need to take into account the range of download speeds available on the expected targets, and in general for the Web it makes sense to make your download as small as possible. So, while you will want to check whether necessary system dependencies are present on the target computer, consider offering separate downloads for each necessary component. </p>
<a name="depends"><h4></a>Dependencies on your own COM Components</h4>
<p>If your WFC application uses COM components that you created yourself, it's a safe bet they aren't installed on the target computer. Therefore, install them as part of your normal application setup. Of course that means you need to create the download packages for these components as well. There are a couple ways you can do this.</p>
<a name="buildcom"></a><h4>Building distribution units for custom components</h4>
<p>One way to create the download package for a custom COM component is by using a Visual Studio 6.0 Distribution Unit project:</p>
<p><img src="cabfile.GIF" WIDTH="350" HEIGHT="246"><br><b>Figure 5. New Project dialog for creating a Distribution Unit</b></p>
<p>The Visual Studio 6.0 Distribution Unit method allows you to create a Cabinet file, self-extracting executable, or zip archive (the same choices I outlined above for packaging your WFC application) for an already-built component. Thus, distribution unit projects are great for packaging existing COM components for which you have the COM server (the .DLL or .EXE file). Because the WBAddrBook component for my sample browser application was built with Visual C++ 6.0 (which does <i>not</i> directly integrate the Visual Studio 6.0 packaging feature), a distribution unit project was my only packaging option.</p>
<p>If you create a self-extracting executable package for your custom COM component, you can install it on the target computer by adding it as a <a href="#NestedSetup">nested setup in your main application package</a>. You will need to adjust the properties for the distribution unit project just as you did with your main application package. Select &quot;YourProjectName Properties&quot; from the <b>Project</b> menu, and the following dialog box will appear:</p>
<p><img src="setup.GIF" WIDTH="350" HEIGHT="324"><br><b>Figure 6. Properties 
dialog box for self-extracting distribution unit project (named &quot;Setup&quot;)</b></p>
<p>Note how this dialog is identical to the "Output Format" tab discussed earlier. They work identically, although obviously you won't need to create an entry in the <b>Start</b> menu to set up a dependent COM component. The &quot;Application title&quot; setting is the text string that will appear in the Add/Remove Software Control Panel -- uninstalling will delete the component and remove it from the Windows registry. Also, you can install the component in the Windows/System folder (via the &quot;System Directory Installation&quot; tab), or just leave it in the folder indicated in the "Installation folder" text field (the setup software will register the component no matter where it ends up being installed).</p>
<p>It would be nice if you could install your component as a nested setup in your main application package by using a distribution unit project to create a Cabinet (.cab) file. But you can't <i>yet</i>. So, in the absence of a nested setup, how do you install a .cab file on the target? By using any of the HTML tags that are designed to accept .cab file archives (such as &lt;OBJECT&gt; or &lt;APPLET&gt;).</p>
<a NAME="cabs"></a><h4>Building a cabinet file for your COM component the old-fashioned way</h4>
<p>From a download size point of view, cabinet files are the best way to install dependent components (that are not themselves applications) because they don't need to include any setup or uninstall code. The problem with both the self-extracting executable and cabinet distribution units (as created by Visual Studio 6.0) is that they can be kind of big -- 200 KB for the setup code plus the size of your component. And there isn't an option to eliminate the setup code.</p>
<p>Fortunately, you have other options. In the case of my sample browser application, the WBAddrBook component is only 14 KB when compressed into a Cabinet by invoking the packaging and code-signing tools directly from the command line. 
</p>
<p>
I know. I spent all this time telling you how the new packaging stuff in Visual Studio 6.0 means you don't have to learn the command-line tools, and now I tell you that if you want small downloads you have to roll your own. But wait. I have a trick for you (sometimes it pays to be lazy). If you go ahead and create a "Cabinet" distribution unit project, including filling in the &quot;Signing&quot; tab on the <b>Properties</b> dialog box (to generate a certificate with your software publishing digital credentials), you can steal the command lines that Visual Studio 6.0 uses to build and sign your cabinet, and run them yourself from a command-line prompt. 
</p>
<p>Before you build your project in VJ++, enable the &quot;Output&quot; view (Ctrl-Alt-O). After the project successfully builds, copy the signcode.exe line from the Output view window and paste it into a &quot;Command Prompt&quot; window:</p>
<p><img src="outsign2.gif" WIDTH="349" HEIGHT="120"><br><b>Figure 7: Portion of output window with code-signing command-line</b></p>
<p>Although it is truncated in the above graphic, the last parameter of the (really long) packsign.exe command line is the name of the .cab file to sign. In the case of the WBAddrbook.dll component, I created WBAddrbook.cab with this command (cabarc.exe, by the way, is placed in the SDK-Java.31\bin\PackSign folder when you <a href="/java/download.htm">install the Microsoft SDK for Java</a> <IMG SRC="/sitebuilder/graphics/leave-site.gif" WIDTH="17" HEIGHT="11" BORDER="0" ALT="Non-SBN link">):</p>
<pre class="clsCode">
cabarc -s 6144 N WBAddrbook.cab WBAddrbook.dll
</pre>
<p>Once you have the signed cabinet file, users can download it from an &lt;OBJECT&gt; tag (of 
course, you'll need to use your own classid value and cabinet file name and version):</p>
<pre class="clsCode">&lt;OBJECT 
 classid=clsid:0340F05F-E75D-11D1-AFDB-000086189887 
 codeBase=WBAddrBook.cab#Version=1,0,0,0 height=0 width=0&gt;</object><br>&lt;/OBJECT&gt;
</pre>
<p>There are some other trade-offs to installing a custom COM component using an &lt;OBJECT&gt; tag (nothing really comes for free in this business):</p>
<ul>
    <li>The component will be installed into the &quot;Windows/Downloaded Program Files&quot; folder, so it is possible the user could remove your component and break your application (this same danger exists when the component is separately uninstalled via 
    the <b>Add/Remove Software</b> Control Panel, although in that case the user 
    gets a warning).</li>
    <li>If users want to uninstall your application, the component will not show up in the <b>Add/Remove Software</b> Control Panel (they will have to remove it by navigating Windows Explorer to the &quot;Windows/Downloaded Program Files&quot; folder and selecting &quot;Remove&quot; from the <b>File</b> menu).</li>
    <li>You need to require installation from Internet Explorer, because Netscape doesn't support the &lt;OBJECT&gt; tag natively.</li>
</ul>
<p>
<A HREF="#top" CLASS="clsBackTop"><IMG SRC="/workshop/graphics/top.gif"  WIDTH="18" HEIGHT="8" BORDER="0" ALT="Top">Back to top</A>
</p>
<a name="summary"></a><h2>Summary</h2>
<p>In this article I showed you how to use new features in Visual Studio 6.0 to create the download packages you'll need to deploy a Windows application from a Web page. By copying the Web folder containing your installation Web pages to a CD-ROM disc, the same methods can be leveraged for CD-ROM distribution. I also went over how Web pages need to determine whether the target computer is capable of running your application by checking for the existence of various software dependencies. In order to prove this stuff all works, I provided a sample install page that applies all these lessons in order to download a pretty nifty Visual J++ 6.0 sample application. The sample install page also has links to download all the examples. 
</p>
<p>I had a lot of fun learning how to use the new Visual Studio 6.0 features, and was very impressed with their depth, although I admit I was disappointed that I couldn't build minimally sized .Cab files or nest .Cab files in a self-extracting executable package (both of these are important from the perspective of Web deployment). But I'm expecting a lot for a first release. </P> 
<p>
At Microsoft we are actively preparing for a world where software is routinely sold and distributed over the Web. We recognize that making it easier for developers to transition to this new world is only part of the story; we also have to make sure the end-user experience is a good one. That is why I spent a lot of effort to not only show you how to use our tools to create your download packages, but also to make sure you understand what is necessary to make Web download satisfactory for your downloaders.
</p>
<!-- DOCUMENT CONTENT END -->

</DIV>

<!-- #include virtual="/sitebuilder/shared/inc/footer-wks.inc" -->

</BODY>
</HTML>
