#ifndef __CALLBACKOBJ_H_
#define __CALLBACKOBJ_H_

#include "resource.h"       // main symbols

#include <DCOMServer.h>		//midl generated code

class CCallBackObj : 
	public CComObjectRoot,
	public IDispatchImpl<ICallBackObj, &IID_ICallBackObj, 
						 &LIBID_DCOMSERVERLib>
{
public:
	CCallBackObj()
	{
		m_pOwnerWnd = NULL;
		m_lLastDataReceivedFromServer = -1;
	}

	void SetOwnerWindow(CWnd* pOwnerWnd)
	{
		m_pOwnerWnd = pOwnerWnd;
	}


DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCallBackObj)
	COM_INTERFACE_ENTRY(ICallBackObj)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

protected:

	CWnd* m_pOwnerWnd;
	long m_lLastDataReceivedFromServer;

public:
	
	STDMETHOD(ReceiveDataFromServer)(/*[in]*/ long lData)
	{
		AFX_MANAGE_STATE(AfxGetStaticModuleState())
		
		if(m_pOwnerWnd != NULL && 
		   m_pOwnerWnd->GetSafeHwnd())
		{
			//post a message since we are on a different thread
			//which will put us back on the main thread
			m_lLastDataReceivedFromServer = lData;
			m_pOwnerWnd->PostMessage(WM_RECEIVE_DATA_FROM_PLUG_IN, 
									 0, m_lLastDataReceivedFromServer);
		}
		return S_OK;
	}
};

#endif //__CALLBACKOBJ_H_
