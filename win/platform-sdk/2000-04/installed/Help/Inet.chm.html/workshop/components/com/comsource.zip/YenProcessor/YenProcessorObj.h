// YenProcessorObj.h : Declaration of the CYenProcessorObj

#ifndef __YENPROCESSOROBJ_H_
#define __YENPROCESSOROBJ_H_

#include "resource.h"       // main symbols

#include <BaseClassDataProcessorObj.h>

// CYenProcessorObj
class ATL_NO_VTABLE CYenProcessorObj : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CYenProcessorObj, &CLSID_YenProcessorObj>,
	public CBaseClassDataProcessorObj
{
public:
	CYenProcessorObj()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_YENPROCESSOROBJ)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CYenProcessorObj)
	COM_INTERFACE_ENTRY(IBaseClassDataProcessorObj)
END_COM_MAP()

// IYenProcessorObj
public:

	STDMETHOD(ProcessData)(long lValue, float* pfloatResult)
	{
		bool bValid = VerifyData(lValue);
		if(!bValid)
		{
			return E_INVALIDARG;
		}

		*pfloatResult = ((float)lValue) * (float).25;
		return S_OK;
	}
};

#endif //__YENPROCESSOROBJ_H_
