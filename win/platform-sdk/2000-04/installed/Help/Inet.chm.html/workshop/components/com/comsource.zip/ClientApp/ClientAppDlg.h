// ClientAppDlg.h : header file
//

#if !defined(AFX_CLIENTAPPDLG_H__2A0A8AD9_50AE_11D2_9193_006008A4FB73__INCLUDED_)
#define AFX_CLIENTAPPDLG_H__2A0A8AD9_50AE_11D2_9193_006008A4FB73__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CClientAppDlg dialog

interface IDCOMServerObj;
//interface ICallBackObj;
class CCallBackObj;


class CClientAppDlg : public CDialog
{
// Construction
public:
	CClientAppDlg(CWnd* pParent = NULL);	// standard constructor

	virtual ~CClientAppDlg();

// Dialog Data
	//{{AFX_DATA(CClientAppDlg)
	enum { IDD = IDD_CLIENTAPP_DIALOG };
	CListBox	m_ListBoxCurrencies;
	CListBox	m_ListBoxWithCLSIDs;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientAppDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	IDCOMServerObj* m_pIDCOMServerObj;

	CComObject<CCallBackObj>* m_pIServerCallBack;

	// Generated message map functions
	//{{AFX_MSG(CClientAppDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSubmit();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	LRESULT OnMessageFromPlugIn(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTAPPDLG_H__2A0A8AD9_50AE_11D2_9193_006008A4FB73__INCLUDED_)
