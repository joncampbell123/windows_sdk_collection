// DCOMServerObj.cpp : Implementation of CDCOMServerObj
#include "stdafx.h"
#include "DCOMServer.h"
#include "DCOMServerObj.h"

