#include "stdafx.h"
#include "WorkerThread.h"

#include "DCOMServer.h"
#include "DCOMServerObj.h"

const int SLEEP_TIME = 5;


//-----------------------------------------------------
CWorkerThreadElement::CWorkerThreadElement
(
	long lValue, 
	CDCOMServerObj* pDCOMServerObj
)
{
	m_lValue = lValue;
	m_pDCOMServerObj = pDCOMServerObj;
}


////////////////////////////////////////////////////////
// class CDataQueue

//-----------------------------------------------------
CDataQueue::CDataQueue(CCommonDataManager* pCommonDataManager)
{	
	m_bDone        = true;
	m_hThread      = NULL;
	m_pCommonDataManager = pCommonDataManager;
	::InitializeCriticalSection(&m_DataQueue_CriticalSection);
}

//-----------------------------------------------------
CDataQueue::~CDataQueue()
{
	StopQueue();
    
	// cleanup

	::EnterCriticalSection(&m_DataQueue_CriticalSection);

	ClearWorkerThreadArray();

	::LeaveCriticalSection(&m_DataQueue_CriticalSection);
	::DeleteCriticalSection(&m_DataQueue_CriticalSection);

	m_bThreadIsDone = true;
}


//-----------------------------------------------------
bool CDataQueue::StartQueue()
{	
    //are we already running
    if(m_bDone == false)
        return true;

	m_bThreadIsDone = false;

	unsigned int  threadId;

	_beginthreadex(NULL, 
				   0, 
				   &QueueChecker, 
				   this, 
	               0,
				   &threadId);

    //we are started or re-started so make sure not done
    m_bDone = false;
	
    return TRUE;
}


//-----------------------------------------------------
void CDataQueue::StopQueue()
{
	::Sleep(SLEEP_TIME);
	
	::EnterCriticalSection(&m_DataQueue_CriticalSection);
	
	m_bDone = true;
	
	::LeaveCriticalSection(&m_DataQueue_CriticalSection);
	
	while(m_bThreadIsDone == false)
	{
		::Sleep(SLEEP_TIME);
	}
}

//-----------------------------------------------------
void CDataQueue::AddEntry
(
    long lValue,
	CDCOMServerObj* pDCOMServerObj
)
{
	::EnterCriticalSection(&m_DataQueue_CriticalSection);
	
	if(m_bDone)
	{
		ClearWorkerThreadArray();
		::LeaveCriticalSection(&m_DataQueue_CriticalSection);
		return;
	}

	CWorkerThreadElement* pElement = new CWorkerThreadElement(lValue, pDCOMServerObj);

	m_WorkerThreadArray.push_back(pElement);
	
	::LeaveCriticalSection(&m_DataQueue_CriticalSection);
}

//-----------------------------------------------------
void CDataQueue::RemoveRequestsForThisDCOMServerObj
(
	CDCOMServerObj* pDCOMServerObj
)
{
	if(pDCOMServerObj == NULL)
		return;

	::EnterCriticalSection(&m_DataQueue_CriticalSection);

	if(m_bDone)
	{
		ClearWorkerThreadArray();
		::LeaveCriticalSection(&m_DataQueue_CriticalSection);
		return;
	}

	int iSize = m_WorkerThreadArray.size();
	for(int i = 0; i < iSize; i++)
	{
		CWorkerThreadElement* pWorkerThreadElement = m_WorkerThreadArray.at(0);
		
		if(pWorkerThreadElement && 
		   pWorkerThreadElement->m_pDCOMServerObj &&
		   pWorkerThreadElement->m_pDCOMServerObj == pDCOMServerObj)
		{
			m_WorkerThreadArray.erase(&m_WorkerThreadArray.at(0));
			i--;
			iSize--;

			delete pWorkerThreadElement;
			pWorkerThreadElement = NULL;
		}
	}

	::LeaveCriticalSection(&m_DataQueue_CriticalSection);
}

//-----------------------------------------------------
void CDataQueue::ClearWorkerThreadArray()
{
	int iSize = m_WorkerThreadArray.size();
	for(int i = 0; i < iSize; i++)
	{
		CWorkerThreadElement* pWorkerThreadElement = m_WorkerThreadArray.at(i);
		if(pWorkerThreadElement != NULL)
		{
			delete pWorkerThreadElement;
			pWorkerThreadElement = NULL;
		}
	}
	m_WorkerThreadArray.clear();
}

//-----------------------------------------------------
unsigned int __stdcall CDataQueue::QueueChecker(void* pArg)
{
	CDataQueue* pQueue = (CDataQueue*)pArg;

	if(pQueue == NULL)
	{
		_ASSERTE(false);
		return 0;
	}
	
	if(pQueue != NULL)
	{
        bool bDone = FALSE;

        int iSleep = SLEEP_TIME;
        
		int iPrevCount = 0;
		int iRemainingCount = 0;
		
		long lValue = 0;
		bool bHaveAnEntry = false;

		while(true) //indicates client is gone if true
		{
			::EnterCriticalSection(&pQueue->m_DataQueue_CriticalSection);
			bDone = pQueue->m_bDone;
			::LeaveCriticalSection(&pQueue->m_DataQueue_CriticalSection);

			if(bDone)
				break;
		
			//assume no entry
			CWorkerThreadElement* pWorkerThreadElement = NULL;

			::EnterCriticalSection(&pQueue->m_DataQueue_CriticalSection);
        
			//check for an entry and get value if entry exists
			if(pQueue->m_WorkerThreadArray.size() > 0)
			{
				pWorkerThreadElement = pQueue->m_WorkerThreadArray.at(0);
				pQueue->m_WorkerThreadArray.erase(&pQueue->m_WorkerThreadArray.at(0));
			}

			iRemainingCount = pQueue->m_WorkerThreadArray.size();

			//send if we have one
			if(pWorkerThreadElement)
			{
				pQueue->m_pCommonDataManager->SendDataToServer(pWorkerThreadElement->m_lValue,
															   pWorkerThreadElement->m_pDCOMServerObj);

				delete pWorkerThreadElement; 
				pWorkerThreadElement = NULL;
			}

			::LeaveCriticalSection(&pQueue->m_DataQueue_CriticalSection);

			if(iPrevCount < iRemainingCount)
			{
				iSleep -= 1;
				if (iSleep < 0)
					iSleep = 0;
			}
			else if (iPrevCount > iRemainingCount)
			{
				if(iSleep < SLEEP_TIME)
					iSleep += 1;
			}
			
			iPrevCount = iRemainingCount;

			if(iSleep > 0)
				::Sleep(iSleep);
		}

		//exit loop, tell owner
		pQueue->m_bThreadIsDone = true;
	}

	return 0;
}

