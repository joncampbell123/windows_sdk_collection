import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;
import com.ms.ie.*;
import com.ms.wfc.html.*;
import com.ms.com.*;

// miscellaneous helper tasks (Find dialog, Address Book, etc.)
import wbaddrbook.*;

// WebBrowser event classes (DWebBrowserEvents2 and DWebBrowserEvents)
import com.ms.wfc.html.om.shdocvw.WebBrowser.*;

/**
 * This class can take a variable number of parameters on the command
 * line. Program execution begins with the main() method. The class
 * constructor is not invoked unless an object of type 'browser'
 * created in the main() method.
 */

public class browser extends Form
{
	// WBAddrBook component
	IWBWAB wbHelper = null;
	// number of open browser windows (starting with this one)
	static int numBrowser = 1;
	
	public browser()
	{
		super();

		// create the browser form and all its contained controls
		initForm();
		
		// create our helper component
		try
		{
			wbHelper = (IWBWAB)new wbaddrbook.WBWAB();
			wbHelper.setWebBrowser(HTMLControl1.getOcx());
		}
		// TODO: both of these exceptions should prevent the application from loading
		// but I don't know how to (or if you can) prevent the form from creating
		// in the constructor. I think the way to do something like this is to
		// move these intializations into an initialize() method that returns
		// a boolean value, so you would do something like this:
		// browser newBrowser = new browser();
		// if (newBrowser.Initialize() == true)
		// {
		//    newBrowser.show();
		//    Application.run();
		// }
		catch (ComError error)
		{
			// ComError notifies errors creating a COM object
			// (note the undocumented methods you can see using intellisense)
			// this exception is thrown on failure to create a COM object, which
			// can occur either with a new operator (as in this example)
			// or on failure to obtain a different interface to the object
			//(in a typecast operation)
			// more info: http://www.microsoft.com/java/sdk/31/source/jsdk_ref_com_comerror.htm
			
			// Note I am avoiding the really hard work here
			// (figuring out what to tell the user, in this case that the helper
			// object did not load, probably because it was not installed or
			// registered, but also could be out of memory, or the user uninstalled
			// WBAddrBook.dll ignoring the warnings.....)
			
			MessageBox.show(error.getMessage(), "My WebBrowser Error");
		}
		catch (ComFailException error)
		{			
			// use ComFailException to catch fail codes for COM object method calls
			// more info: http://www.microsoft.com/java/sdk/31/source/jsdk_ref_com.htm
			// (in this case setWebBrowser failed)
			errorMessage(error.getMessage(), error.getHResult());
		}
		
		// add our WebBrowser control event handlers
		HTMLControl1.addOnBeforeNavigate2(new BeforeNavigate2Handler(this.OnBeforeNavigate2));
		HTMLControl1.addOnCommandStateChange(new CommandStateChangeHandler(this.OnCommandStateChange));
		HTMLControl1.addOnDocumentComplete(new DocumentCompleteHandler(this.OnDocumentComplete));
		HTMLControl1.addOnDownloadBegin(new EventHandler(this.OnDownloadBegin));
		HTMLControl1.addOnDownloadComplete(new EventHandler(this.OnDownloadComplete));
		HTMLControl1.addOnNavigateComplete2(new NavigateComplete2Handler(this.OnNavigateComplete2));
		HTMLControl1.addOnNewWindow2(new NewWindow2Handler(this.OnNewWindow2));
		HTMLControl1.addOnProgressChange(new ProgressChangeHandler(this.OnProgressChange));
		HTMLControl1.addOnPropertyChange(new PropertyChangeHandler(this.OnPropertyChange));
		HTMLControl1.addOnTitleChange(new TitleChangeHandler(this.OnTitleChange));
		
		// we need our own OnClosing handler (see comments below in main()
		this.addOnClosing(new com.ms.wfc.core.CancelEventHandler(this.OnClosing));
		
		// set the initial visit
		HTMLControl1.GoHome();
	}

	/**
	 * browser overrides dispose so it can clean up the
	 * component list.
	 */
	public void dispose()
	{
		super.dispose();
		components.dispose();
		if (wbHelper != null)
		{
			// more info on ComLib.release():
			// http://www.microsoft.com/java/sdk/31/source/jsdk_pg_com_programming_in_java_and_c___compared.htm#jsdk_pg_object_release
			ComLib.release(wbHelper);
			wbHelper = null;
		}
	}
	
	public void finalize()
	{
		try
		{
			super.finalize();
		}
		catch(Throwable error)
		{
		}
		// this method will only be called after all memory has been cleaned
		// up by the VM. Overriding this method (at least for debug versions)
		// is a great way to be sure you are cleaning up properly when your
		// Form shuts down (if you aren't then this method won't be called)
	}
	
	public void errorMessage(String message, int errNumber)
	{
		message += "HRESULT: ";
		message += errNumber;
		MessageBox.show(message, "HTMLControl Sample Application Error");
	}
	
	// onClosing event handler (see comments in main() below)
	private void OnClosing(Object sender, CancelEvent e)
	{
		doClose();
	}
	
	//
	// WebBrowser events handlers
	// more info:
	// http://www.microsoft.com/workshop/browser/contents.htm
	//
	// the sender object is the HTMLControl1 object for the frame or window

	private void OnBeforeNavigate2(Object sender, BeforeNavigate2Event event)
	{
		// this event handler can cancel or modify the navigation
		// this example redirects "http://CoolCars/" to http://carpoint.msn.com
		// (some call this the "coolest event for the coolest IE control", there
		// is so much you can do with it)
		if (event.URL.toString().compareTo("http://coolcars/") == 0)
		{
			// prevent the about:Navigation cancelled page
			((HTMLControl)sender).Stop();
			event.URL.putString("http://carpoint.msn.com/");
			// see File!New handling (below) for more info on these parameters
			((HTMLControl)sender).Navigate(event.URL.toString(), event.Flags, 
								event.TargetFrameName, event.PostData,
								event.Headers);
			// cancel the current navigation, we just specified a new one
			event.Cancel[0] = true;
		}
		
 	}

	private void OnCommandStateChange(Object sender, CommandStateChangeEvent event)
	{
        switch (event.Command)
        {
        case CommandStateChangeConstants.CSC_NAVIGATEBACK:
			// Go!Back
            menuItem34.setEnabled(event.Enable);
            break;
        case CommandStateChangeConstants.CSC_NAVIGATEFORWARD:
			// Go!Forward
            menuItem35.setEnabled(event.Enable);
            break;
        }
	}

	private void OnDocumentComplete(Object sender, DocumentCompleteEvent event)
	{
		// the document is completely downloaded, now you can safely access the
		// document object model, modify the document, or any other task that
		// requires the document be completley loaded before proceeding
	}

	private void OnDownloadBegin(Object sender, Event event)
	{
		// a new download operation is beginning
		// this could be used to indicate download progress such as is done by IE
		// in the status bar
	}

	private void OnDownloadComplete(Object sender, Event event)
	{
		// if you are doing some ui to indicate download progress, you should now
		// indicate the download operation is completed
	}

	private void OnNavigateComplete2(Object sender, NavigateComplete2Event event)
	{
		// note that URL will be a pidl for things like "My Computer"
		// (we'll still get a useful string for it in that case)
	}

	private void OnNewWindow2(Object sender, NewWindow2Event event)
	{
		// start another copy of browser (instead of IE).
		// Note this is not a separate instance of our application
		// rather it is merely another browser form
		// running off the same message pump.
		// This means we need to track our open windows so that we don't
		// exit our application until the last browser form is closed.
		browser newBrowser = new browser();
		numBrowser++;
		event.ppDisp[0] = newBrowser.HTMLControl1.getOcx();
		newBrowser.show();
	}

	private void OnProgressChange(Object sender, ProgressChangeEvent event)
	{
		// use this to do a progress bar for downloads (such as IE does in the status bar)
		// this works in tandem with the DownloadBegin and DownloadEnd events
	}
	
	private void OnPropertyChange(Object sender, PropertyChangeEvent event)
	{
		//event.szProperty is the guid of the changed property (as String)
	}
	
	// new <TITLE> tag (which probably means new page, but not necessarily)
	private void OnTitleChange(Object sender, TitleChangeEvent event)
	{
		StringBuffer strURL = new StringBuffer(event.Text);
		strURL.append(" - My Visual J++ 6.0 Browser");
		this.setText(strURL.toString());
		edit1.setText(((HTMLControl)sender).getURL());
	}
	
	//
	// File menu handling
	//
	
	// File!New
	// OLECOMDID_NEW is indicated by QueryStatusWB as supported, but it never
	// returns enabled. You will have to implement your own File!New feature.
	// (it's initialized as disabled in the menu editor)
	private void menuItem2_click(Object source, Event e)
	{		
	}

	// File!Open
    // OLECMDID_OPEN is indicated by QueryStatusWB as supported, and it does
    // bring up the open dialog you are familiar with from IE.
    // However the url that is selected in this dialog always opens in
    // a separate instance of Internet Explorer (instead of the WebBrowser
    // control the OLECMDID_OPEN command is being invoked on).
    // So we use the OpenFileDialog WFC class to do our own open dialog
	private void menuItem3_click(Object source, Event e)
	{
		OpenFileDialog ofd = new OpenFileDialog();
		ofd.setDefaultExt("java");	//sets the default extension
		//set the file filter
		ofd.setFilter("HTML files (*.htm,*.html)|*.htm;*.html|All files (*.*)|*.*");
		//set the filter that will be initially selected
		ofd.setFilterIndex(1);
		// set the initial directory as the current dir
		ofd.setInitialDir(".\\");
		// only allow one file to be selected
		ofd.setMultiselect(false);
		int dlgResult = ofd.showDialog();	
		// get the names of the files the user chose
		if (dlgResult == DialogResult.OK)
		{
			// HTMLControl provides the setURL method for navigation
			HTMLControl1.setURL(ofd.getFileName());
			// you can also just call Navigate or Navigate2 directly:
			// HTMLControl1.Navigate(ofd.getFileName(), parm2, parm3, parm4, parm5);
            // parameter 2
            // allows you to specify whether the URL reads from
            // or writes to the cache, opens in a new window (which will generate
            // a NewWindow2 event), is added to the history list, and opens in the
            // current Explorer Bar (doesn't work for a containted WebBrowser, only
            // for controlling a remote instance of IE). You can also specify 
            // attempting alternate domain roots (.org, etc.) 
            // parameter 3
            // allows you to specify to open in a particular frame
            // of a frame set
            // parameter 4
            // allows you to specify the text for a post operation,
            // or you can cause a Get opertion if the Variant is empty
            // parameter 5
            // allows you to add your own HTTP headers to the server request
			// Note: parm2 to parm4 need to be packaged as variants. 
			// Note: for null values pass new Variant() (i.e., not the keyword "null")
		}	
	}

	// File!Save
    // OLECOMDID_SAVE is indicated as supported, and is in the IE File menu,
    // so we put it here. Of course you can't save the file so we disabled this
	// menu command in the menu editor
	private void menuItem4_click(Object source, Event e)
	{
	}

	// File!SaveAs
    // OLECOMDID_SAVEAS provides this support
	private void menuItem5_click(Object source, Event e)
	{
        try {
            HTMLControl1.ExecWB(OLECMDID.OLECMDID_SAVEAS, 
                                OLECMDEXECOPT.OLECMDEXECOPT_PROMPTUSER, 
                                null, null);
        }
        catch (ComFailException error)
		{
            // if the user cancels the dialog you can catch
            // an exception here for that
		}
	}

	// File!PageSetup
    // OLECMDID_PAGESETUP provides this support
	private void menuItem7_click(Object source, Event e)
	{
        try 
		{
            HTMLControl1.ExecWB(OLECMDID.OLECMDID_PAGESETUP, 
                                OLECMDEXECOPT.OLECMDEXECOPT_PROMPTUSER, 
                                null, null);
        }
        catch (ComFailException error)
		{
            // if the user cancels the dialog you can catch
            // an exception here for that
        }
	}

	// File!Print
    // OLECMDID_PRINT provides this support
	private void menuItem8_click(Object source, Event e)
	{
        try {
            // we are asking for the print dialog, but you could also
            // use OLEMCMDEXECOPT_DONTPROMPTUSER to just do the print
            // without a dialog. However you won't be able to select
            // which frame is printed in a page with multiple frames.
			// TODO: for more information see DHTML Printing article
            HTMLControl1.ExecWB(OLECMDID.OLECMDID_PRINT, 
                                OLECMDEXECOPT.OLECMDEXECOPT_PROMPTUSER, 
                                null, null);
        }
        catch (ComFailException error) {
            // if the user cancels the dialog you can catch
            // an exception here for that
        }
	}

	// File!WorkOffline
	// Offline is a property of the webbrowser control and you might
	// even think you could use it, but I'll be darned if I can get
	// it to work. So we do it ourself using WinInet
	private void menuItem10_click(Object source, Event e)
	{
        boolean checked = menuItem10.getChecked();
		try 
		{
			wbHelper.setOffline(!checked);
		}
        catch (ComFailException error)
		{
			errorMessage(error.getMessage(), error.getHResult());
        }
	}

	// File!Close
	private void doClose()
	{
		if (numBrowser == 1)
		{
			Application.exit();
		}
		else
		{
			numBrowser--;
			this.close();
		}
	}
	private void menuItem11_click(Object source, Event e)
	{
		doClose();
	}

	// enable/disable File menu items as appropriate
	private void menuItem1_popup(Object source, Event e)
	{
        int status;
        
        try {
            // see above comments on OLECOMDID_NEW
            
            // see above comments on OLECMDID_OPEN
			// are we are in a state where we can open a new document
            status = HTMLControl1.QueryStatusWB(OLECMDID.OLECMDID_OPEN) & OLECMDF.OLECMDF_ENABLED;
            menuItem3.setEnabled(status != 0);
            
            // see above commentson OLECOMDID_SAVE
            status = HTMLControl1.QueryStatusWB(OLECMDID.OLECMDID_SAVE) & OLECMDF.OLECMDF_ENABLED;
            menuItem4.setEnabled(status != 0);
            
            // is there is a document loaded that we can saveAs
            status = HTMLControl1.QueryStatusWB(OLECMDID.OLECMDID_SAVEAS) & OLECMDF.OLECMDF_ENABLED;
            menuItem5.setEnabled(status != 0);
            
            // is there is a document loaded that we can PageSetup
            status = HTMLControl1.QueryStatusWB(OLECMDID.OLECMDID_PAGESETUP) & OLECMDF.OLECMDF_ENABLED;
			menuItem7.setEnabled(status != 0);

			// is there is a document loaded that we can Print
            status = HTMLControl1.QueryStatusWB(OLECMDID.OLECMDID_PRINT) & OLECMDF.OLECMDF_ENABLED;
            menuItem8.setEnabled(status != 0);
            
            // see above comment for Offline
			// use our helper object to determine the global offline state
            menuItem10.setChecked(wbHelper.getOffline());
		}
        catch (ComFailException error)
		{
        }
	}

	//
	// edit1 control handling
	//
	
	// on <CR> navigate to the indicated URL
	private void editKeyPress(Object source, KeyPressEvent e)
	{
		try
		{
			if (e.keyChar == Key.RETURN)
			{				
				HTMLControl1.setURL(edit1.getText());
			}
		}
        catch (ComFailException error)
		{
        }
	}

	//
	// Edit menu handling
	//
	
	private void menuItem12_popup(Object source, Event e)
	{
        int status;
        
        try {
            // OLECMDID_CUT is indicated as supported since it is "standard"
            // Edit menu item, but obviously you can't cut from a view-only
            // document. Thus this never returns enabled.
            status = HTMLControl1.QueryStatusWB(OLECMDID.OLECMDID_CUT) & OLECMDF.OLECMDF_ENABLED;
            C.setEnabled(status != 0);
           
            // you can only copy when there is a selection
            status = HTMLControl1.QueryStatusWB(OLECMDID.OLECMDID_COPY) & OLECMDF.OLECMDF_ENABLED;
            menuItem13.setEnabled(status != 0);
            
            status = HTMLControl1.QueryStatusWB(OLECMDID.OLECMDID_PASTE) & OLECMDF.OLECMDF_ENABLED;
            menuItem14.setEnabled(status != 0);
            
            // you can only select all when there is a current document  
            status = HTMLControl1.QueryStatusWB(OLECMDID.OLECMDID_SELECTALL) & OLECMDF.OLECMDF_ENABLED;
			menuItem16.setEnabled(status != 0);
            
			// if there's nothing to select then we'll assume there's nothing to find
			menuItem17.setEnabled(status != 0);
        }
        catch (ComFailException error)
		{
        }
	}

	// Edit!Cut
	// just for fun, name this differently
	private void C_click(Object source, Event e)
	{
        // see comment above abou OLECMDID_CUT
	}

	// Edit!Copy
	private void menuItem13_click(Object source, Event e)
	{
        try
		{
            HTMLControl1.ExecWB(OLECMDID.OLECMDID_COPY, 
                                OLECMDEXECOPT.OLECMDEXECOPT_PROMPTUSER, 
                                null, null);
        }
        catch (ComFailException error) {
        }
	}

	// Edit!Paste
	private void menuItem14_click(Object source, Event e)
	{
        // see comment above abou OLECMDID_PASTE
	}

	// Edit!SelectAll
	private void menuItem16_click(Object source, Event e)
	{
        try
		{
            HTMLControl1.ExecWB(OLECMDID.OLECMDID_SELECTALL, 
                                OLECMDEXECOPT.OLECMDEXECOPT_PROMPTUSER, 
                                null, null);
        }
        catch (ComFailException error)
		{
        }
	}

	// Edit!Find...
	private void menuItem17_click(Object source, Event e)
	{
        try
		{
            wbHelper.ShowFind();
        }
        catch (ComFailException error)
		{
			errorMessage(error.getMessage(), error.getHResult());
        }
	}

	//
	// View menu handling
	//
	
	// View!Fonts menu popup
	private void menuItem20_popup(Object source, Event e)
	{
        // let weboc remember our font size state
        menuItem21.setChecked(false);
        menuItem22.setChecked(false);
        menuItem23.setChecked(false);
        menuItem24.setChecked(false);
        menuItem25.setChecked(false);
    
        // we know the range goes from 0 to 4
        Variant range = new Variant();
        HTMLControl1.ExecWB(OLECMDID.OLECMDID_ZOOM, 
                           OLECMDEXECOPT.OLECMDEXECOPT_DONTPROMPTUSER, 
                           null, range);
        switch (range.toInt())
        {
        case 0:
            menuItem25.setChecked(true);
            break;
        case 1:
            menuItem24.setChecked(true);
            break;
        case 2:
            menuItem23.setChecked(true);
            break;
        case 3:
            menuItem22.setChecked(true);
            break;
        case 4:
            menuItem21.setChecked(true);
            break;
        }
	}

	// helper routine for below font size changes
	private void setFontSize(int size)
	{
		try
		{
			HTMLControl1.ExecWB(OLECMDID.OLECMDID_ZOOM, 
			                    OLECMDEXECOPT.OLECMDEXECOPT_DONTPROMPTUSER,
			                    new Variant(size), null);
		}
		catch (ComFailException error)
		{
		}
	}
	
	// View!Fonts!Largest
	private void menuItem21_click(Object source, Event e)
	{
		setFontSize(4);
	}

	// View!Fonts!Larger
	private void menuItem22_click(Object source, Event e)
	{
		setFontSize(3);
	}

	// View!Fonts!Medium
	private void menuItem23_click(Object source, Event e)
	{
		setFontSize(2);
	}

	// View!Fonts!Smaller
	private void menuItem24_click(Object source, Event e)
	{
		setFontSize(1);
	}

	// View!Fonts!Smallest
	private void menuItem25_click(Object source, Event e)
	{
		setFontSize(0);
	}

	// View!Stop
	private void menuItem27_click(Object source, Event e)
	{
		HTMLControl1.Stop();
	}

	// View!Refresh
	private void menuItem28_click(Object source, Event e)
	{
		HTMLControl1.Refresh();
	}

	// View!Source
	private void menuItem30_click(Object source, Event e)
	{
        try
		{
            wbHelper.ShowViewSource();
        }
        catch (ComFailException error)
		{
			errorMessage(error.getMessage(), error.getHResult());
        }
	}

	// View!InternetOptions...
	private void menuItem32_click(Object source, Event e)
	{
        try 
		{
            wbHelper.ShowProperties();
        }
        catch (ComFailException error)
		{
        }
	}

	//
	// Go menu handling
	//
	
	// Go!Back
	private void menuItem34_click(Object source, Event e)
	{
		HTMLControl1.GoBack();
	}

	// Go!Forward
	private void menuItem35_click(Object source, Event e)
	{
		HTMLControl1.GoForward();
	}

	// Go!UpOneLevel
	// TODO: this menu item should be activated when you are navigating
	// local folder content (such as C:\). If that is the case,
	// the proper action to take here is to go up one level
	// in the folder hierarchy (and if at the root then disable the menu)
	private void menuItem36_click(Object source, Event e)
	{
	}

	// Go!Home
	private void menuItem38_click(Object source, Event e)
	{
		HTMLControl1.GoHome();
	}

	// Go!Search
	private void menuItem39_click(Object source, Event e)
	{
		HTMLControl1.GoSearch();
	}

	// Go!Mail
	private void menuItem41_click(Object source, Event e)
	{
        try
		{
            wbHelper.ShowMail(this.getHandle());
        }
        catch (ComFailException error)
		{
			errorMessage(error.getMessage(), error.getHResult());
        }
	}

	// Go!News
	private void menuItem42_click(Object source, Event e)
	{
        try
		{
            wbHelper.ShowNews(this.getHandle());
        }
        catch (ComFailException error)
		{
			errorMessage(error.getMessage(), error.getHResult());
        }
	}

	// Go!MyComputer
	private void menuItem43_click(Object source, Event e)
	{
        try
		{
            wbHelper.ShowMyComputer(this.getHandle());
        }
        catch (ComFailException error)
		{
			errorMessage(error.getMessage(), error.getHResult());
        }
	}

	// Go!AddressBook
	private void menuItem44_click(Object source, Event e)
	{
        try
		{
            wbHelper.ShowAddressBook(this.getHandle());
        }
        catch (ComFailException error)
		{
			errorMessage(error.getMessage(), error.getHResult());
        }
	}

	//
	// Favorites menu handling
	//
	
    private void handleFavoritesFolder(Object sender, Event e)
    {
        myMenuItem menuItem = (myMenuItem)sender;
        FolderItem folderItem = (FolderItem)(menuItem.getData());
        // fill out the submenu for this folder
        addFolderToFavoritesMenu((Folder)folderItem.getGetFolder(), menuItem);
    }
    
    // navigate to the selected favorites item
    private void handleFavoritesItem(Object sender, Event e)
    {
        myMenuItem menuItem = (myMenuItem)sender;
        FolderItem folderItem = (FolderItem)menuItem.getData();
		
		// there are two ways we can do this
		//	- folderItem.InvokeVerb(new Variant("&Open"));
		//		this will open the URL in the app assigned to the file extension
		//		or the assigned protocol-handler (the default browser)
		//		we'll do this for Channel Shortcuts
		//  - use setURL to open in this browser
		//		we'll do this for all other shortcuts

		Variant URL = new Variant();
		// is this a channel shortcut
		if (folderItem.getIsFolder())
		{
			folderItem.InvokeVerb(new Variant("&Open Channel"));
		}
		else
		{
			try
			{
				wbHelper.GetURL(new Variant(folderItem.getPath()), URL);
				HTMLControl1.setURL(URL.toString());
			}
			catch (ComFailException error)
			{
			}
		}
		ComLib.release(URL);
		URL = null;
    }
	
	// recursively add folders to the menu
	// otherwise, if a link add the link to the menu
    private void addFolderToFavoritesMenu(Folder folder, MenuItem menu)
    {
        myMenuItem menuItem = null;
        FolderItems folderItems = folder.Items();
        int count = folderItems.getCount();
		
        for (int i = 0; i < count; i++)
        {
            FolderItem folderItem = folderItems.Item(new Variant(i));
			// Channel Shortcuts are not "real" folders
			String s = folderItem.getType();
            if (folderItem.getIsFolder() && 
				(folderItem.getType().compareTo("Channel Shortcut") != 0))
            {
                // create the menuitem for this folder
                Folder subFolder = (Folder)folderItem.getGetFolder();
                String subFolderName = subFolder.getTitle();
                menuItem = new myMenuItem(subFolderName);
				// add the folder's items to its submenu
				addFolderToFavoritesMenu(subFolder, menuItem);
            }
            else
            {
                String itemName = folderItem.getName();
                menuItem = new myMenuItem(itemName, new EventHandler(this.handleFavoritesItem));
            }
            menuItem.setData(folderItem);
            menu.add(menuItem);
        }
		// handle special case of empty folder
		if (count == 0)
		{
			menuItem = new myMenuItem("Empty");
			menuItem.setEnabled(false);
			menu.add(menuItem);
		}
        ComLib.release(folderItems);
    }
    
	// only do this once per form
	boolean createFavoritesMenu = true;
	
	private void menuItem45_popup(Object sender, Event e)
    {
        // merge Favorites
        if (createFavoritesMenu)
        {
            createFavoritesMenu = false;
            // first get a pidl to the favorites folder
            
            // create a Shell COM object
            Shell shell = new Shell();
            // QI for it's automation interface
            IShellDispatch shellDisp = (IShellDispatch)shell;

			// this gives us Favorites for "Default User"
			// The pathname for the favorites folder of the
			// current user is in the registry:
			// HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders
			// and you can pass that path to the NameSpace method below
			// as a Variant string value
			// (note com.ms.wfc.app.Registry can be used to access the Windows registry)
            Variant vssfFAVORITES = new Variant(ShellSpecialFolderConstants.ssfFAVORITES);
            Folder Favorites = shellDisp.NameSpace(vssfFAVORITES);
            addFolderToFavoritesMenu(Favorites, (MenuItem)sender);
			ComLib.release(Favorites);
			ComLib.release(shellDisp);
			ComLib.release(shell);
        }
    }
	
	// Favorites!AddToFavorite
	private void menuItem46_click(Object sender, Event e)
    {
        try
        {
            IShellUIHelper Favorites = new ShellUIHelper();
            Favorites.AddFavorite(HTMLControl1.getLocationURL(), 
                                  new Variant(HTMLControl1.getLocationName()));
			
			// TODO: add this to the end of the Favorites menu.
			// to do this you'll need to go to the more complicated mechanism
			// for adding favorites, that is using DoAddToFavDlg() function
			// that is exported from shdocvw.dll. For implementation details see:
			// http://support.microsoft.com/support/kb/articles/q184/7/80.asp
			// You can also look at ShowOrganizeFavorites in WBAddrBook.
        }
        catch (ComFailException error)
		{
			errorMessage(error.getMessage(), error.getHResult());
        }
    }

	// Favorites!OrganizeFavorites
	private void  menuItem47_click(Object sender, Event e)
    {
        try
		{
            wbHelper.ShowOrganizeFavorites(this.getHandle());
        }
        catch (ComFailException error)
		{
			errorMessage(error.getMessage(), error.getHResult());
        }
    }
    
	// Favorites!ManageSubscriptions
	private void menuItem49_click(Object sender, Event e)
    {
		try
		{
			// create a pathname for the subscriptions folder in the windows folder
			StringBuffer WindowsDir = new StringBuffer(255);
			int Length = GetWindowsDirectory(WindowsDir, WindowsDir.capacity());
			WindowsDir.append("\\Subscriptions");
			Variant vSubscriptionFolder = new Variant(WindowsDir.toString());
    
			// create a Shell COM object (coclass) for the Shell
			Shell shell = new Shell();
			// QI for its automation interface
			IShellDispatch Subscriptions = (IShellDispatch)shell;
			// open a separate shell window for the subscriptions folder
			Subscriptions.Open(vSubscriptionFolder);
        
			// note you could also use J/Direct with the ShellExecute function
			// to launch this shell window
		}
        catch (ComFailException error)
		{
			errorMessage(error.getMessage(), error.getHResult());
        }
    }

	// Favorites!UpdateSubscriptions
	private void menuItem50_click(Object sender, Event e)
    {
        try
		{
            wbHelper.ShowUpdateSubscriptions();
        }
        catch (ComFailException error)
		{
			errorMessage(error.getMessage(), error.getHResult());
        }
    }

	// change HTMLControl size to fit the changed browser rect
	private void onResize(Object source, Event e)
	{
		Rectangle rect = this.getClientRect();
		rect.height -= HTMLControl1.getTop();
		rect.width -= HTMLControl1.getLeft();
		Point pt = new Point(rect.width, rect.height);
		HTMLControl1.setClientSize(pt);
		
		rect = edit1.getClientRect();
		pt.y = rect.height;
		edit1.setClientSize(pt);
	}

	/**
	 * NOTE: The following code is required by the Visual J++ form
	 * designer.  It can be modified using the form editor.  Do not
	 * modify it using the code editor.
	 */
	Container components = new Container();
	HTMLControl HTMLControl1 = new HTMLControl();
	MenuItem menuItem51 = new MenuItem();
	Edit edit1 = new Edit();
	MainMenu mainMenu1 = new MainMenu();
	MenuItem menuItem1 = new MenuItem();
	MenuItem menuItem2 = new MenuItem();
	MenuItem menuItem3 = new MenuItem();
	MenuItem menuItem4 = new MenuItem();
	MenuItem menuItem5 = new MenuItem();
	MenuItem menuItem6 = new MenuItem();
	MenuItem menuItem7 = new MenuItem();
	MenuItem menuItem8 = new MenuItem();
	MenuItem menuItem9 = new MenuItem();
	MenuItem menuItem10 = new MenuItem();
	MenuItem menuItem11 = new MenuItem();
	MenuItem menuItem12 = new MenuItem();
	MenuItem C = new MenuItem();
	MenuItem menuItem13 = new MenuItem();
	MenuItem menuItem14 = new MenuItem();
	MenuItem menuItem15 = new MenuItem();
	MenuItem menuItem16 = new MenuItem();
	MenuItem menuItem17 = new MenuItem();
	MenuItem menuItem18 = new MenuItem();
	MenuItem menuItem19 = new MenuItem();
	MenuItem menuItem20 = new MenuItem();
	MenuItem menuItem21 = new MenuItem();
	MenuItem menuItem22 = new MenuItem();
	MenuItem menuItem23 = new MenuItem();
	MenuItem menuItem24 = new MenuItem();
	MenuItem menuItem25 = new MenuItem();
	MenuItem menuItem26 = new MenuItem();
	MenuItem menuItem27 = new MenuItem();
	MenuItem menuItem28 = new MenuItem();
	MenuItem menuItem29 = new MenuItem();
	MenuItem menuItem30 = new MenuItem();
	MenuItem menuItem31 = new MenuItem();
	MenuItem menuItem32 = new MenuItem();
	MenuItem menuItem33 = new MenuItem();
	MenuItem menuItem34 = new MenuItem();
	MenuItem menuItem35 = new MenuItem();
	MenuItem menuItem36 = new MenuItem();
	MenuItem menuItem37 = new MenuItem();
	MenuItem menuItem38 = new MenuItem();
	MenuItem menuItem39 = new MenuItem();
	MenuItem menuItem40 = new MenuItem();
	MenuItem menuItem41 = new MenuItem();
	MenuItem menuItem42 = new MenuItem();
	MenuItem menuItem43 = new MenuItem();
	MenuItem menuItem44 = new MenuItem();
	MenuItem menuItem45 = new MenuItem();
	MenuItem menuItem46 = new MenuItem();
	MenuItem menuItem47 = new MenuItem();
	MenuItem menuItem48 = new MenuItem();
	MenuItem menuItem49 = new MenuItem();
	MenuItem menuItem50 = new MenuItem();
	MenuItem menuItem52 = new MenuItem();

	private void initForm()
	{
		// NOTE:  This form is storing resource information in an
		// external file.  Do not modify the string parameter to any
		// resources.getObject() function call. For example, do not
		// modify "foo1_location" in the following line of code
		// even if the name of the Foo object changes: 
		//   foo1.setLocation((Point)resources.getObject("foo1_location"));

		IResourceManager resources = new ResourceManager(this, "browser");
		components.add(HTMLControl1, "HTMLControl1");
		HTMLControl1.setLocation(new Point(0, 24));
		HTMLControl1.setSize(new Point(544, 304));
		HTMLControl1.setTabIndex(0);
		HTMLControl1.setTabStop(false);
		HTMLControl1.setOcxState((AxHost.State)resources.getObject("HTMLControl1_ocxState"));

		components.add(menuItem51, "menuItem51");
		menuItem51.setText("");

		components.add(edit1, "edit1");
		edit1.setSize(new Point(544, 20));
		edit1.setTabIndex(1);
		edit1.setText("");
		edit1.addOnKeyPress(new KeyPressEventHandler(this.editKeyPress));

		components.add(menuItem2, "menuItem2");
		menuItem2.setEnabled(false);
		menuItem2.setText("&New");
		menuItem2.addOnClick(new EventHandler(this.menuItem2_click));

		components.add(menuItem3, "menuItem3");
		menuItem3.setShortcut(Shortcut.CTRL_O);
		menuItem3.setText("&Open...");
		menuItem3.addOnClick(new EventHandler(this.menuItem3_click));

		components.add(menuItem4, "menuItem4");
		menuItem4.setEnabled(false);
		menuItem4.setShortcut(Shortcut.CTRL_S);
		menuItem4.setText("&Save");
		menuItem4.addOnClick(new EventHandler(this.menuItem4_click));

		components.add(menuItem5, "menuItem5");
		menuItem5.setText("Save &As...");
		menuItem5.addOnClick(new EventHandler(this.menuItem5_click));

		components.add(menuItem6, "menuItem6");
		menuItem6.setText("-");

		components.add(menuItem7, "menuItem7");
		menuItem7.setText("Page Set&up...");
		menuItem7.addOnClick(new EventHandler(this.menuItem7_click));

		components.add(menuItem8, "menuItem8");
		menuItem8.setShortcut(Shortcut.CTRL_P);
		menuItem8.setText("Print...");
		menuItem8.addOnClick(new EventHandler(this.menuItem8_click));

		components.add(menuItem9, "menuItem9");
		menuItem9.setText("-");

		components.add(menuItem10, "menuItem10");
		menuItem10.setText("Work &Offline");
		menuItem10.addOnClick(new EventHandler(this.menuItem10_click));

		components.add(menuItem11, "menuItem11");
		menuItem11.setText("&Close");
		menuItem11.addOnClick(new EventHandler(this.menuItem11_click));

		components.add(menuItem1, "menuItem1");
		menuItem1.setMenuItems(new MenuItem[] {
							   menuItem2, 
							   menuItem3, 
							   menuItem4, 
							   menuItem5, 
							   menuItem6, 
							   menuItem7, 
							   menuItem8, 
							   menuItem9, 
							   menuItem10, 
							   menuItem11});
		menuItem1.setText("&File");
		menuItem1.addOnPopup(new EventHandler(this.menuItem1_popup));

		components.add(C, "C");
		C.setShortcut(Shortcut.CTRL_X);
		C.setText("Cu&t");
		C.addOnClick(new EventHandler(this.C_click));

		components.add(menuItem13, "menuItem13");
		menuItem13.setShortcut(Shortcut.CTRL_C);
		menuItem13.setText("&Copy");
		menuItem13.addOnClick(new EventHandler(this.menuItem13_click));

		components.add(menuItem14, "menuItem14");
		menuItem14.setShortcut(Shortcut.CTRL_V);
		menuItem14.setText("&Paste");
		menuItem14.addOnClick(new EventHandler(this.menuItem14_click));

		components.add(menuItem15, "menuItem15");
		menuItem15.setText("-");

		components.add(menuItem16, "menuItem16");
		menuItem16.setShortcut(Shortcut.CTRL_A);
		menuItem16.setText("Select &All");
		menuItem16.addOnClick(new EventHandler(this.menuItem16_click));

		components.add(menuItem17, "menuItem17");
		menuItem17.setShortcut(Shortcut.CTRL_F);
		menuItem17.setText("&Find...");
		menuItem17.addOnClick(new EventHandler(this.menuItem17_click));

		components.add(menuItem18, "menuItem18");
		menuItem18.setText("-");

		components.add(menuItem12, "menuItem12");
		menuItem12.setMenuItems(new MenuItem[] {
								C, 
								menuItem13, 
								menuItem14, 
								menuItem15, 
								menuItem16, 
								menuItem18, 
								menuItem17});
		menuItem12.setText("&Edit");
		menuItem12.addOnPopup(new EventHandler(this.menuItem12_popup));

		components.add(menuItem21, "menuItem21");
		menuItem21.setText("Lar&gest");
		menuItem21.addOnClick(new EventHandler(this.menuItem21_click));

		components.add(menuItem22, "menuItem22");
		menuItem22.setText("&Larger");
		menuItem22.addOnClick(new EventHandler(this.menuItem22_click));

		components.add(menuItem23, "menuItem23");
		menuItem23.setText("&Medium");
		menuItem23.addOnClick(new EventHandler(this.menuItem23_click));

		components.add(menuItem24, "menuItem24");
		menuItem24.setText("&Small");
		menuItem24.addOnClick(new EventHandler(this.menuItem24_click));

		components.add(menuItem25, "menuItem25");
		menuItem25.setText("Sm&allest");
		menuItem25.addOnClick(new EventHandler(this.menuItem25_click));

		components.add(menuItem20, "menuItem20");
		menuItem20.setMenuItems(new MenuItem[] {
								menuItem21, 
								menuItem22, 
								menuItem23, 
								menuItem24, 
								menuItem25});
		menuItem20.setText("Fo&nts");
		menuItem20.addOnPopup(new EventHandler(this.menuItem20_popup));

		components.add(menuItem26, "menuItem26");
		menuItem26.setText("-");

		components.add(menuItem27, "menuItem27");
		menuItem27.setText("Sto&p");
		menuItem27.addOnClick(new EventHandler(this.menuItem27_click));

		components.add(menuItem28, "menuItem28");
		menuItem28.setShortcut(Shortcut.F5);
		menuItem28.setText("&Refresh");
		menuItem28.addOnClick(new EventHandler(this.menuItem28_click));

		components.add(menuItem29, "menuItem29");
		menuItem29.setText("-");

		components.add(menuItem30, "menuItem30");
		menuItem30.setText("Sour&ce");
		menuItem30.addOnClick(new EventHandler(this.menuItem30_click));

		components.add(menuItem31, "menuItem31");
		menuItem31.setText("-");

		components.add(menuItem32, "menuItem32");
		menuItem32.setText("Internet &Options...");
		menuItem32.addOnClick(new EventHandler(this.menuItem32_click));

		components.add(menuItem19, "menuItem19");
		menuItem19.setMenuItems(new MenuItem[] {
								menuItem20, 
								menuItem26, 
								menuItem27, 
								menuItem28, 
								menuItem29, 
								menuItem30, 
								menuItem31, 
								menuItem32});
		menuItem19.setText("&View");

		components.add(menuItem34, "menuItem34");
		menuItem34.setText("&Back");
		menuItem34.addOnClick(new EventHandler(this.menuItem34_click));

		components.add(menuItem35, "menuItem35");
		menuItem35.setText("&Forward");
		menuItem35.addOnClick(new EventHandler(this.menuItem35_click));

		components.add(menuItem36, "menuItem36");
		menuItem36.setEnabled(false);
		menuItem36.setText("&Up One Level");
		menuItem36.addOnClick(new EventHandler(this.menuItem36_click));

		components.add(menuItem37, "menuItem37");
		menuItem37.setText("-");

		components.add(menuItem38, "menuItem38");
		menuItem38.setText("&Home Page");
		menuItem38.addOnClick(new EventHandler(this.menuItem38_click));

		components.add(menuItem39, "menuItem39");
		menuItem39.setText("&Search the Web");
		menuItem39.addOnClick(new EventHandler(this.menuItem39_click));

		components.add(menuItem40, "menuItem40");
		menuItem40.setText("-");

		components.add(menuItem41, "menuItem41");
		menuItem41.setText("&Mail");
		menuItem41.addOnClick(new EventHandler(this.menuItem41_click));

		components.add(menuItem42, "menuItem42");
		menuItem42.setText("&News");
		menuItem42.addOnClick(new EventHandler(this.menuItem42_click));

		components.add(menuItem43, "menuItem43");
		menuItem43.setText("My &Computer");
		menuItem43.addOnClick(new EventHandler(this.menuItem43_click));

		components.add(menuItem44, "menuItem44");
		menuItem44.setText("&Address Book");
		menuItem44.addOnClick(new EventHandler(this.menuItem44_click));

		components.add(menuItem33, "menuItem33");
		menuItem33.setMenuItems(new MenuItem[] {
								menuItem34, 
								menuItem35, 
								menuItem36, 
								menuItem37, 
								menuItem38, 
								menuItem39, 
								menuItem40, 
								menuItem41, 
								menuItem42, 
								menuItem43, 
								menuItem44});
		menuItem33.setText("&Go");

		components.add(menuItem46, "menuItem46");
		menuItem46.setText("&Add to Favorites...");
		menuItem46.addOnClick(new EventHandler(this.menuItem46_click));

		components.add(menuItem47, "menuItem47");
		menuItem47.setText("&Organize Favorites...");
		menuItem47.addOnClick(new EventHandler(this.menuItem47_click));

		components.add(menuItem48, "menuItem48");
		menuItem48.setText("-");

		components.add(menuItem49, "menuItem49");
		menuItem49.setText("&Manage Subscriptions...");
		menuItem49.addOnClick(new EventHandler(this.menuItem49_click));

		components.add(menuItem50, "menuItem50");
		menuItem50.setText("&Update Subscriptions");
		menuItem50.addOnClick(new EventHandler(this.menuItem50_click));

		components.add(menuItem52, "menuItem52");
		menuItem52.setText("-");

		components.add(menuItem45, "menuItem45");
		menuItem45.setMenuItems(new MenuItem[] {
								menuItem46, 
								menuItem47, 
								menuItem48, 
								menuItem49, 
								menuItem50, 
								menuItem52});
		menuItem45.setText("&Favorites");
		menuItem45.addOnPopup(new EventHandler(this.menuItem45_popup));

		components.add(mainMenu1, "mainMenu1");
		mainMenu1.setMenuItems(new MenuItem[] {
							   menuItem1, 
							   menuItem12, 
							   menuItem19, 
							   menuItem33, 
							   menuItem45});
		/* @designTimeOnly mainMenu1.setLocation(new Point(16, 8)); */

		this.setText("browser");
		this.setAutoScaleBaseSize(new Point(5, 13));
		this.setClientSize(new Point(545, 341));
		this.setMenu(mainMenu1);
		this.addOnResize(new EventHandler(this.onResize));

		this.setNewControls(new Control[] {
							edit1, 
							HTMLControl1});

		HTMLControl1.begin();
	}

	/**
	 * The main entry point for the application. 
	 *
	 * @param args Array of parameters passed to the application
	 * via the command line.
	 */
	// TODO: Catch initialization errors due to WFC classes not being installed.
	// If you want to have your WFC app check for WFC and catch exceptions, you need to 
	// point your project startup at another main().  The WFC app templates always have 
	// main() in the main form class, e.g. "Form1" extending com.ms.wfc.ui.Form which 
	// means the class can't get loaded without WFC.  Use main() in another class that
	// extends nothing (effectively java.lang.Object) and has no other class references.
	// In there, use reflection to load com.ms.wfc.ui.Form, and catch exceptions that 
	// trigger your "no WFC installed" message.  If loading Form succeeds, 
	// use reflection further to load your main form class and execute main() there.
	// If you do this, do everybody a favor and send me your project and I'll update this
	// sample (and forever be your debt).
	
	public static void main(String args[])
	{
		//Application.run(new browser());
		// the above line is created automatically for wfc app projects, but
		// calling run(Form) adds an onClosing handler to the Form
		// that calls the Application.exit() method for you. That is
		// bad because closing the first browser window will then
		// exit the application (and close all other open browser windows)
		// So we do this instead (which does not add the bad onClosing handler):
		browser theBrowser = new browser();
		theBrowser.show();
		Application.run();
	}

	//
	// declare the Win32 APIs we use above
	//
	/**
	 * @dll.import("KERNEL32", auto) 
	 */
	public static native int GetWindowsDirectory(StringBuffer lpBuffer, int uSize);
}
