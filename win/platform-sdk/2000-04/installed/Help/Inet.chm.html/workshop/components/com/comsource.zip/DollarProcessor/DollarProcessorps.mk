
DollarProcessorps.dll: dlldata.obj DollarProcessor_p.obj DollarProcessor_i.obj
	link /dll /out:DollarProcessorps.dll /def:DollarProcessorps.def /entry:DllMain dlldata.obj DollarProcessor_p.obj DollarProcessor_i.obj \
		kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib \

.c.obj:
	cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL \
		$<

clean:
	@del DollarProcessorps.dll
	@del DollarProcessorps.lib
	@del DollarProcessorps.exp
	@del dlldata.obj
	@del DollarProcessor_p.obj
	@del DollarProcessor_i.obj
