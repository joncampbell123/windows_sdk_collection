# Microsoft Developer Studio Generated NMAKE File, Based on DCOMServer.dsp
!IF "$(CFG)" == ""
CFG=DCOMServer - Win32 Debug
!MESSAGE No configuration specified. Defaulting to DCOMServer - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "DCOMServer - Win32 Debug" && "$(CFG)" != "DCOMServer - Win32 Unicode Debug" && "$(CFG)" != "DCOMServer - Win32 Release MinSize" && "$(CFG)" != "DCOMServer - Win32 Release MinDependency" && "$(CFG)" != "DCOMServer - Win32 Unicode Release MinSize" && "$(CFG)" != "DCOMServer - Win32 Unicode Release MinDependency"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "DCOMServer.mak" CFG="DCOMServer - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "DCOMServer - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE "DCOMServer - Win32 Unicode Debug" (based on "Win32 (x86) Application")
!MESSAGE "DCOMServer - Win32 Release MinSize" (based on "Win32 (x86) Application")
!MESSAGE "DCOMServer - Win32 Release MinDependency" (based on "Win32 (x86) Application")
!MESSAGE "DCOMServer - Win32 Unicode Release MinSize" (based on "Win32 (x86) Application")
!MESSAGE "DCOMServer - Win32 Unicode Release MinDependency" (based on "Win32 (x86) Application")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

!IF  "$(CFG)" == "DCOMServer - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

ALL : "$(OUTDIR)\DCOMServer.exe" ".\DCOMServer.tlb" ".\DCOMServer.h" ".\DCOMServer_i.c" ".\Debug\regsvr32.trg"


CLEAN :
	-@erase "$(INTDIR)\CommonDataManager.obj"
	-@erase "$(INTDIR)\DCOMServer.obj"
	-@erase "$(INTDIR)\DCOMServer.pch"
	-@erase "$(INTDIR)\DCOMServer.res"
	-@erase "$(INTDIR)\DCOMServerObj.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(INTDIR)\WorkerThread.obj"
	-@erase "$(OUTDIR)\DCOMServer.exe"
	-@erase "$(OUTDIR)\DCOMServer.ilk"
	-@erase "$(OUTDIR)\DCOMServer.pdb"
	-@erase ".\DCOMServer.h"
	-@erase ".\DCOMServer.tlb"
	-@erase ".\DCOMServer_i.c"
	-@erase ".\Debug\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /D "_AFXDLL" /Fp"$(INTDIR)\DCOMServer.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\DCOMServer.res" /d "_DEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\DCOMServer.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /subsystem:windows /incremental:yes /pdb:"$(OUTDIR)\DCOMServer.pdb" /debug /machine:I386 /out:"$(OUTDIR)\DCOMServer.exe" /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\CommonDataManager.obj" \
	"$(INTDIR)\DCOMServer.obj" \
	"$(INTDIR)\DCOMServerObj.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\WorkerThread.obj" \
	"$(INTDIR)\DCOMServer.res"

"$(OUTDIR)\DCOMServer.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\Debug
TargetPath=.\Debug\DCOMServer.exe
InputPath=.\Debug\DCOMServer.exe
SOURCE="$(InputPath)"

"$(OUTDIR)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	"$(TargetPath)" /RegServer 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	echo Server registration done! 
<< 
	

!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Unicode Debug"

OUTDIR=.\DebugU
INTDIR=.\DebugU
# Begin Custom Macros
OutDir=.\DebugU
# End Custom Macros

ALL : "$(OUTDIR)\DCOMServer.exe" ".\DCOMServer.tlb" ".\DCOMServer.h" ".\DCOMServer_i.c" ".\DebugU\regsvr32.trg"


CLEAN :
	-@erase "$(INTDIR)\CommonDataManager.obj"
	-@erase "$(INTDIR)\DCOMServer.obj"
	-@erase "$(INTDIR)\DCOMServer.pch"
	-@erase "$(INTDIR)\DCOMServer.res"
	-@erase "$(INTDIR)\DCOMServerObj.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(INTDIR)\WorkerThread.obj"
	-@erase "$(OUTDIR)\DCOMServer.exe"
	-@erase "$(OUTDIR)\DCOMServer.ilk"
	-@erase "$(OUTDIR)\DCOMServer.pdb"
	-@erase ".\DCOMServer.h"
	-@erase ".\DCOMServer.tlb"
	-@erase ".\DCOMServer_i.c"
	-@erase ".\DebugU\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MLd /W3 /Gm /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_UNICODE" /Fp"$(INTDIR)\DCOMServer.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\DCOMServer.res" /d "_DEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\DCOMServer.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /entry:"wWinMainCRTStartup" /subsystem:windows /incremental:yes /pdb:"$(OUTDIR)\DCOMServer.pdb" /debug /machine:I386 /out:"$(OUTDIR)\DCOMServer.exe" /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\CommonDataManager.obj" \
	"$(INTDIR)\DCOMServer.obj" \
	"$(INTDIR)\DCOMServerObj.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\WorkerThread.obj" \
	"$(INTDIR)\DCOMServer.res"

"$(OUTDIR)\DCOMServer.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\DebugU
TargetPath=.\DebugU\DCOMServer.exe
InputPath=.\DebugU\DCOMServer.exe
SOURCE="$(InputPath)"

"$(OUTDIR)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	if "%OS%"=="" goto NOTNT 
	if not "%OS%"=="Windows_NT" goto NOTNT 
	"$(TargetPath)" /RegServer 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	echo Server registration done! 
	goto end 
	:NOTNT 
	echo Warning : Cannot register Unicode EXE on Windows 95 
	:end 
<< 
	

!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Release MinSize"

OUTDIR=.\ReleaseMinSize
INTDIR=.\ReleaseMinSize
# Begin Custom Macros
OutDir=.\ReleaseMinSize
# End Custom Macros

ALL : "$(OUTDIR)\DCOMServer.exe" ".\DCOMServer.tlb" ".\DCOMServer.h" ".\DCOMServer_i.c" ".\ReleaseMinSize\regsvr32.trg"


CLEAN :
	-@erase "$(INTDIR)\CommonDataManager.obj"
	-@erase "$(INTDIR)\DCOMServer.obj"
	-@erase "$(INTDIR)\DCOMServer.pch"
	-@erase "$(INTDIR)\DCOMServer.res"
	-@erase "$(INTDIR)\DCOMServerObj.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\WorkerThread.obj"
	-@erase "$(OUTDIR)\DCOMServer.exe"
	-@erase ".\DCOMServer.h"
	-@erase ".\DCOMServer.tlb"
	-@erase ".\DCOMServer_i.c"
	-@erase ".\ReleaseMinSize\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /ML /W3 /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_ATL_DLL" /D "_ATL_MIN_CRT" /Fp"$(INTDIR)\DCOMServer.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\DCOMServer.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\DCOMServer.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /incremental:no /pdb:"$(OUTDIR)\DCOMServer.pdb" /machine:I386 /out:"$(OUTDIR)\DCOMServer.exe" 
LINK32_OBJS= \
	"$(INTDIR)\CommonDataManager.obj" \
	"$(INTDIR)\DCOMServer.obj" \
	"$(INTDIR)\DCOMServerObj.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\WorkerThread.obj" \
	"$(INTDIR)\DCOMServer.res"

"$(OUTDIR)\DCOMServer.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\ReleaseMinSize
TargetPath=.\ReleaseMinSize\DCOMServer.exe
InputPath=.\ReleaseMinSize\DCOMServer.exe
SOURCE="$(InputPath)"

"$(OUTDIR)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	"$(TargetPath)" /RegServer 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	echo Server registration done! 
<< 
	

!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Release MinDependency"

OUTDIR=.\ReleaseMinDependency
INTDIR=.\ReleaseMinDependency
# Begin Custom Macros
OutDir=.\ReleaseMinDependency
# End Custom Macros

ALL : "$(OUTDIR)\DCOMServer.exe" ".\DCOMServer.tlb" ".\DCOMServer.h" ".\DCOMServer_i.c" ".\ReleaseMinDependency\regsvr32.trg"


CLEAN :
	-@erase "$(INTDIR)\CommonDataManager.obj"
	-@erase "$(INTDIR)\DCOMServer.obj"
	-@erase "$(INTDIR)\DCOMServer.pch"
	-@erase "$(INTDIR)\DCOMServer.res"
	-@erase "$(INTDIR)\DCOMServerObj.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\WorkerThread.obj"
	-@erase "$(OUTDIR)\DCOMServer.exe"
	-@erase ".\DCOMServer.h"
	-@erase ".\DCOMServer.tlb"
	-@erase ".\DCOMServer_i.c"
	-@erase ".\ReleaseMinDependency\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /ML /W3 /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_ATL_STATIC_REGISTRY" /D "_ATL_MIN_CRT" /Fp"$(INTDIR)\DCOMServer.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\DCOMServer.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\DCOMServer.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /incremental:no /pdb:"$(OUTDIR)\DCOMServer.pdb" /machine:I386 /out:"$(OUTDIR)\DCOMServer.exe" 
LINK32_OBJS= \
	"$(INTDIR)\CommonDataManager.obj" \
	"$(INTDIR)\DCOMServer.obj" \
	"$(INTDIR)\DCOMServerObj.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\WorkerThread.obj" \
	"$(INTDIR)\DCOMServer.res"

"$(OUTDIR)\DCOMServer.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\ReleaseMinDependency
TargetPath=.\ReleaseMinDependency\DCOMServer.exe
InputPath=.\ReleaseMinDependency\DCOMServer.exe
SOURCE="$(InputPath)"

"$(OUTDIR)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	"$(TargetPath)" /RegServer 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	echo Server registration done! 
<< 
	

!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Unicode Release MinSize"

OUTDIR=.\ReleaseUMinSize
INTDIR=.\ReleaseUMinSize
# Begin Custom Macros
OutDir=.\ReleaseUMinSize
# End Custom Macros

ALL : "$(OUTDIR)\DCOMServer.exe" ".\DCOMServer.tlb" ".\DCOMServer.h" ".\DCOMServer_i.c" ".\ReleaseUMinSize\regsvr32.trg"


CLEAN :
	-@erase "$(INTDIR)\CommonDataManager.obj"
	-@erase "$(INTDIR)\DCOMServer.obj"
	-@erase "$(INTDIR)\DCOMServer.pch"
	-@erase "$(INTDIR)\DCOMServer.res"
	-@erase "$(INTDIR)\DCOMServerObj.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\WorkerThread.obj"
	-@erase "$(OUTDIR)\DCOMServer.exe"
	-@erase ".\DCOMServer.h"
	-@erase ".\DCOMServer.tlb"
	-@erase ".\DCOMServer_i.c"
	-@erase ".\ReleaseUMinSize\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /ML /W3 /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_UNICODE" /D "_ATL_DLL" /D "_ATL_MIN_CRT" /Fp"$(INTDIR)\DCOMServer.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\DCOMServer.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\DCOMServer.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /incremental:no /pdb:"$(OUTDIR)\DCOMServer.pdb" /machine:I386 /out:"$(OUTDIR)\DCOMServer.exe" 
LINK32_OBJS= \
	"$(INTDIR)\CommonDataManager.obj" \
	"$(INTDIR)\DCOMServer.obj" \
	"$(INTDIR)\DCOMServerObj.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\WorkerThread.obj" \
	"$(INTDIR)\DCOMServer.res"

"$(OUTDIR)\DCOMServer.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\ReleaseUMinSize
TargetPath=.\ReleaseUMinSize\DCOMServer.exe
InputPath=.\ReleaseUMinSize\DCOMServer.exe
SOURCE="$(InputPath)"

"$(OUTDIR)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	if "%OS%"=="" goto NOTNT 
	if not "%OS%"=="Windows_NT" goto NOTNT 
	"$(TargetPath)" /RegServer 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	echo Server registration done! 
	goto end 
	:NOTNT 
	echo Warning : Cannot register Unicode EXE on Windows 95 
	:end 
<< 
	

!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Unicode Release MinDependency"

OUTDIR=.\ReleaseUMinDependency
INTDIR=.\ReleaseUMinDependency
# Begin Custom Macros
OutDir=.\ReleaseUMinDependency
# End Custom Macros

ALL : "$(OUTDIR)\DCOMServer.exe" ".\DCOMServer.tlb" ".\DCOMServer.h" ".\DCOMServer_i.c" ".\ReleaseUMinDependency\regsvr32.trg"


CLEAN :
	-@erase "$(INTDIR)\CommonDataManager.obj"
	-@erase "$(INTDIR)\DCOMServer.obj"
	-@erase "$(INTDIR)\DCOMServer.pch"
	-@erase "$(INTDIR)\DCOMServer.res"
	-@erase "$(INTDIR)\DCOMServerObj.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\WorkerThread.obj"
	-@erase "$(OUTDIR)\DCOMServer.exe"
	-@erase ".\DCOMServer.h"
	-@erase ".\DCOMServer.tlb"
	-@erase ".\DCOMServer_i.c"
	-@erase ".\ReleaseUMinDependency\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /ML /W3 /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_UNICODE" /D "_ATL_STATIC_REGISTRY" /D "_ATL_MIN_CRT" /Fp"$(INTDIR)\DCOMServer.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\DCOMServer.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\DCOMServer.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /incremental:no /pdb:"$(OUTDIR)\DCOMServer.pdb" /machine:I386 /out:"$(OUTDIR)\DCOMServer.exe" 
LINK32_OBJS= \
	"$(INTDIR)\CommonDataManager.obj" \
	"$(INTDIR)\DCOMServer.obj" \
	"$(INTDIR)\DCOMServerObj.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\WorkerThread.obj" \
	"$(INTDIR)\DCOMServer.res"

"$(OUTDIR)\DCOMServer.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\ReleaseUMinDependency
TargetPath=.\ReleaseUMinDependency\DCOMServer.exe
InputPath=.\ReleaseUMinDependency\DCOMServer.exe
SOURCE="$(InputPath)"

"$(OUTDIR)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	if "%OS%"=="" goto NOTNT 
	if not "%OS%"=="Windows_NT" goto NOTNT 
	"$(TargetPath)" /RegServer 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	echo Server registration done! 
	goto end 
	:NOTNT 
	echo Warning : Cannot register Unicode EXE on Windows 95 
	:end 
<< 
	

!ENDIF 


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("DCOMServer.dep")
!INCLUDE "DCOMServer.dep"
!ELSE 
!MESSAGE Warning: cannot find "DCOMServer.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "DCOMServer - Win32 Debug" || "$(CFG)" == "DCOMServer - Win32 Unicode Debug" || "$(CFG)" == "DCOMServer - Win32 Release MinSize" || "$(CFG)" == "DCOMServer - Win32 Release MinDependency" || "$(CFG)" == "DCOMServer - Win32 Unicode Release MinSize" || "$(CFG)" == "DCOMServer - Win32 Unicode Release MinDependency"
SOURCE=.\CommonDataManager.cpp

"$(INTDIR)\CommonDataManager.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\DCOMServer.pch"


SOURCE=.\DCOMServer.cpp

"$(INTDIR)\DCOMServer.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\DCOMServer.pch"


SOURCE=.\DCOMServer.idl

!IF  "$(CFG)" == "DCOMServer - Win32 Debug"

MTL_SWITCHES=/tlb ".\DCOMServer.tlb" /h "DCOMServer.h" /iid "DCOMServer_i.c" /Oicf 

".\DCOMServer.tlb"	".\DCOMServer.h"	".\DCOMServer_i.c" : $(SOURCE) "$(INTDIR)"
	$(MTL) @<<
  $(MTL_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Unicode Debug"

MTL_SWITCHES=/tlb ".\DCOMServer.tlb" /h "DCOMServer.h" /iid "DCOMServer_i.c" /Oicf 

".\DCOMServer.tlb"	".\DCOMServer.h"	".\DCOMServer_i.c" : $(SOURCE) "$(INTDIR)"
	$(MTL) @<<
  $(MTL_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Release MinSize"

MTL_SWITCHES=/tlb ".\DCOMServer.tlb" /h "DCOMServer.h" /iid "DCOMServer_i.c" /Oicf 

".\DCOMServer.tlb"	".\DCOMServer.h"	".\DCOMServer_i.c" : $(SOURCE) "$(INTDIR)"
	$(MTL) @<<
  $(MTL_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Release MinDependency"

MTL_SWITCHES=/tlb ".\DCOMServer.tlb" /h "DCOMServer.h" /iid "DCOMServer_i.c" /Oicf 

".\DCOMServer.tlb"	".\DCOMServer.h"	".\DCOMServer_i.c" : $(SOURCE) "$(INTDIR)"
	$(MTL) @<<
  $(MTL_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Unicode Release MinSize"

MTL_SWITCHES=/tlb ".\DCOMServer.tlb" /h "DCOMServer.h" /iid "DCOMServer_i.c" /Oicf 

".\DCOMServer.tlb"	".\DCOMServer.h"	".\DCOMServer_i.c" : $(SOURCE) "$(INTDIR)"
	$(MTL) @<<
  $(MTL_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Unicode Release MinDependency"

MTL_SWITCHES=/tlb ".\DCOMServer.tlb" /h "DCOMServer.h" /iid "DCOMServer_i.c" /Oicf 

".\DCOMServer.tlb"	".\DCOMServer.h"	".\DCOMServer_i.c" : $(SOURCE) "$(INTDIR)"
	$(MTL) @<<
  $(MTL_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\DCOMServer.rc

"$(INTDIR)\DCOMServer.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) $(RSC_PROJ) $(SOURCE)


SOURCE=.\DCOMServerObj.cpp

"$(INTDIR)\DCOMServerObj.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\DCOMServer.pch"


SOURCE=.\StdAfx.cpp

!IF  "$(CFG)" == "DCOMServer - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /D "_AFXDLL" /Fp"$(INTDIR)\DCOMServer.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\DCOMServer.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Unicode Debug"

CPP_SWITCHES=/nologo /MLd /W3 /Gm /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_UNICODE" /Fp"$(INTDIR)\DCOMServer.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\DCOMServer.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Release MinSize"

CPP_SWITCHES=/nologo /ML /W3 /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_ATL_DLL" /D "_ATL_MIN_CRT" /Fp"$(INTDIR)\DCOMServer.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\DCOMServer.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Release MinDependency"

CPP_SWITCHES=/nologo /ML /W3 /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_ATL_STATIC_REGISTRY" /D "_ATL_MIN_CRT" /Fp"$(INTDIR)\DCOMServer.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\DCOMServer.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Unicode Release MinSize"

CPP_SWITCHES=/nologo /ML /W3 /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_UNICODE" /D "_ATL_DLL" /D "_ATL_MIN_CRT" /Fp"$(INTDIR)\DCOMServer.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\DCOMServer.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "DCOMServer - Win32 Unicode Release MinDependency"

CPP_SWITCHES=/nologo /ML /W3 /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_UNICODE" /D "_ATL_STATIC_REGISTRY" /D "_ATL_MIN_CRT" /Fp"$(INTDIR)\DCOMServer.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\DCOMServer.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\WorkerThread.cpp

"$(INTDIR)\WorkerThread.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\DCOMServer.pch"



!ENDIF 

