
YenProcessorps.dll: dlldata.obj YenProcessor_p.obj YenProcessor_i.obj
	link /dll /out:YenProcessorps.dll /def:YenProcessorps.def /entry:DllMain dlldata.obj YenProcessor_p.obj YenProcessor_i.obj \
		kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib \

.c.obj:
	cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL \
		$<

clean:
	@del YenProcessorps.dll
	@del YenProcessorps.lib
	@del YenProcessorps.exp
	@del dlldata.obj
	@del YenProcessor_p.obj
	@del YenProcessor_i.obj
