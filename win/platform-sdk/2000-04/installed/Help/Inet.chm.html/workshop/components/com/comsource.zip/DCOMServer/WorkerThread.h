
#ifndef	_WORKER_THREAD_H_
#define _WORKER_THREAD_H_

#include <process.h>
#include "CommonDataManager.h"

class CDCOMServerObj;

class CWorkerThreadElement
{
public:
	CWorkerThreadElement(long lValue, CDCOMServerObj* pDCOMServerObj);

	long m_lValue;
	CDCOMServerObj* m_pDCOMServerObj;
};


class CDataQueue
{
private:

    //this is my array to hold all incoming data 
    
	vector<CWorkerThreadElement*>   m_WorkerThreadArray;

	HANDLE        m_hThread;
	bool          m_bDone;
	bool		  m_bThreadIsDone;

public:

    CCommonDataManager* m_pCommonDataManager;

	CDataQueue(CCommonDataManager* pCommonDataManager);
	
	virtual ~CDataQueue();

	void AddEntry(long lEntry, CDCOMServerObj* pDCOMServerObj);

    //this critical protects our data
	CRITICAL_SECTION m_DataQueue_CriticalSection;

	bool StartQueue();

	void RemoveRequestsForThisDCOMServerObj(CDCOMServerObj* pDCOMServerObj);

protected:

	void StopQueue();

	void ClearWorkerThreadArray();

private:
 	static unsigned int __stdcall QueueChecker(void* pArg);

};

#endif  //_WORKER_THREAD_H_