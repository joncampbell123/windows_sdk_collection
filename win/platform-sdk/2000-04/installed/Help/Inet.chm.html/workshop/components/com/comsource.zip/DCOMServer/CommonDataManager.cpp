#include "stdafx.h"
#include "CommonDataManager.h"

#include "WorkerThread.h"

#include "DCOMServer.h"

//-------------------------------------------------------------------
CDCOMServerArrayElement::CDCOMServerArrayElement
(
	CDCOMServerObj* pDCOMServerObj,
	ICallBackObj* pICallBackObj
)
{
	_ASSERTE(pDCOMServerObj != NULL);
	_ASSERTE(pICallBackObj != NULL);

	m_pDCOMServerObj = pDCOMServerObj;
	
	m_pICallBackObj = pICallBackObj;
	m_pICallBackObj->AddRef();
}

CDCOMServerArrayElement::~CDCOMServerArrayElement()
{
	m_pDCOMServerObj = NULL;

	if(m_pICallBackObj != NULL)
	{
		m_pICallBackObj->Release();
		m_pICallBackObj = NULL;
	}
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////


//-------------------------------------------------------------------
CCommonDataManager::CCommonDataManager()
{
	m_pDataQueue = new CDataQueue(this);
	m_bThreadStarted = false;

	::InitializeCriticalSection(&m_CommonDataManagerCriticalSection);
}

//-------------------------------------------------------------------
CCommonDataManager::~CCommonDataManager()
{
	if(m_pDataQueue != NULL)
	{
		delete m_pDataQueue;
		m_pDataQueue = NULL;
	}

	//make sure to clean array!
	::EnterCriticalSection(&m_CommonDataManagerCriticalSection);

	for(int i = 0; i < m_DCOMServerArray.size(); i++)
	{
		CDCOMServerArrayElement* pDCOMServerArrayElement = m_DCOMServerArray.at(i);
		if(pDCOMServerArrayElement != NULL)
		{
			delete pDCOMServerArrayElement;
			pDCOMServerArrayElement = NULL;
		}
	}

    m_DCOMServerArray.clear();

	::LeaveCriticalSection(&m_CommonDataManagerCriticalSection);
	::DeleteCriticalSection(&m_CommonDataManagerCriticalSection);
}

//-------------------------------------------------------------------
bool CCommonDataManager::RegisterClientCallBack
(
	CDCOMServerObj* pDCOMServerObj,
	ICallBackObj* pICallBackObj				//call back in client
)
{
/*
	We are passed and instance of a COM object that is owned by a client along
	with a call back interface.  Let's add it to our array.
*/

	if(pDCOMServerObj == NULL || pICallBackObj == NULL)
		return false;

	bool bSuccess = false;

	//The constructor of CDCOMServerArrayElement calls AddRef() on the ICallBackObj
	//when it uses the assignment operator to set a class member.
	CDCOMServerArrayElement* pDCOMServerArrayElement 
			= new CDCOMServerArrayElement(pDCOMServerObj, pICallBackObj);

	if(pDCOMServerArrayElement == NULL)
		return false;

	::EnterCriticalSection(&m_CommonDataManagerCriticalSection);

	m_DCOMServerArray.push_back(pDCOMServerArrayElement);

	::LeaveCriticalSection(&m_CommonDataManagerCriticalSection);

	return true;
}

//-------------------------------------------------------------------
void CCommonDataManager::UnregisterClientCallBacks
(
	CDCOMServerObj* pDCOMServerObj
)
{
	if(pDCOMServerObj == NULL)
		return;
/*
	First tell the worker thread to remove all requests 
	from this COM instance.
*/
	m_pDataQueue->RemoveRequestsForThisDCOMServerObj(pDCOMServerObj);

/*
	Next we need to find all call back interfaces registered to this 
	client and release them by deleting the array element (which calls Release()
	in its destructor).  The pDCOMServerObj can be in the array multiple times 
	so we need to check for all occurrences.
*/

	::EnterCriticalSection(&m_CommonDataManagerCriticalSection);
	
	CDCOMServerArrayElement* pDCOMServerArrayElement = NULL;

	int iTotal = m_DCOMServerArray.size();

	for(int i = 0; i < iTotal; i++)
	{
		pDCOMServerArrayElement = m_DCOMServerArray.at(i);

		if(pDCOMServerArrayElement && pDCOMServerArrayElement->m_pDCOMServerObj == pDCOMServerObj)
		{
			//delete and remove from array, delete of pDCOMServerArrayElement
			//calls Release of the ICallBackObj
			delete pDCOMServerArrayElement;
			pDCOMServerArrayElement = NULL;
			m_DCOMServerArray.erase(&m_DCOMServerArray.at(i));
			i--;
			iTotal--;
		}
	}

	::LeaveCriticalSection(&m_CommonDataManagerCriticalSection);
}

//-------------------------------------------------------------------
void CCommonDataManager::DataManagerAddEntry
(
	long lValue,
	CDCOMServerObj* pDCOMServerObj
)
{
	//make sure thread is started.
	//This is called only once since there is only one instance of CCommonDataManager.
	if(!m_bThreadStarted) 
	{
		m_bThreadStarted = m_pDataQueue->StartQueue();
	}
	
	_ASSERTE(m_pDataQueue);

	//add value to the queue passing the DCOMServerObj so we know to whom to
	//send it back to
	m_pDataQueue->AddEntry(lValue, pDCOMServerObj);
}

//-------------------------------------------------------------------
int CCommonDataManager::SendDataToServer
(
	long lData,
	CDCOMServerObj* pDCOMServerObj
)
{
	int iNumberSent = 0;

	::EnterCriticalSection(&m_CommonDataManagerCriticalSection);
	
	for(int i = 0; i < m_DCOMServerArray.size(); i++)
	{
		CDCOMServerArrayElement* pDCOMServerArrayElement = m_DCOMServerArray.at(i);
		
		//send only to requester
		if(pDCOMServerArrayElement && 
		   pDCOMServerArrayElement->m_pDCOMServerObj == pDCOMServerObj &&
		   pDCOMServerArrayElement->m_pICallBackObj)
		{
			long lReturnValue = -1;
			
			//lData = 1 for dollar, 1 dollar = 1 dollar
			if(lData == 1)
				lReturnValue = 1;
			else if(lData == 2) //1 dollar gets you two marks
				lReturnValue = 2;
			else if(lData == 3) //lData = 3 for yen
				lReturnValue = 4;  //1 dollar gets you 4 yen.

			pDCOMServerArrayElement->m_pICallBackObj->ReceiveDataFromServer(lReturnValue);
		}
	}

	::LeaveCriticalSection(&m_CommonDataManagerCriticalSection);

	return iNumberSent;
}



