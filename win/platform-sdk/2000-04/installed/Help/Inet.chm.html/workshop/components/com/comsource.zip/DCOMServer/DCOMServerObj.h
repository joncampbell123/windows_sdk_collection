#ifndef __DCOMSERVEROBJ_H_
#define __DCOMSERVEROBJ_H_

#include "resource.h"       // main symbols
#include "CommonDataManager.h"

// CDCOMServerObj
class ATL_NO_VTABLE CDCOMServerObj : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CDCOMServerObj, &CLSID_DCOMServerObj>,
	public IDispatchImpl<IDCOMServerObj, &IID_IDCOMServerObj, &LIBID_DCOMSERVERLib>
{
public:
	CDCOMServerObj(){}

	void FinalRelease()
	{
		_Module.m_pCommonDataManager->UnregisterClientCallBacks(this);
	}


DECLARE_REGISTRY_RESOURCEID(IDR_DCOMSERVEROBJ)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDCOMServerObj)
	COM_INTERFACE_ENTRY(IDCOMServerObj)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IDCOMServerObj
public:
	
	STDMETHOD(RegisterCallBack)(ICallBackObj* pICallBack)
	{
		if(NULL != pICallBack)
		{
			bool bSuccess = _Module.m_pCommonDataManager->RegisterClientCallBack(this, pICallBack);
			if(bSuccess)
				return S_OK;
			else
				return E_FAIL;
		}

		return E_FAIL;
	}

	STDMETHOD(ProcessRequest)(long lValue)
	{
		_Module.m_pCommonDataManager->DataManagerAddEntry(lValue, this);
		return S_OK;
	}
};

#endif //__DCOMSERVEROBJ_H_
