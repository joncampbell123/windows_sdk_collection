// MarkProcessorObj.h : Declaration of the CMarkProcessorObj

#ifndef __MARKPROCESSOROBJ_H_
#define __MARKPROCESSOROBJ_H_

#include "resource.h"       // main symbols

#include <BaseClassDataProcessorObj.h>

// CMarkProcessorObj
class ATL_NO_VTABLE CMarkProcessorObj : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMarkProcessorObj, &CLSID_MarkProcessorObj>,
	public CBaseClassDataProcessorObj
{
public:
	CMarkProcessorObj()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MARKPROCESSOROBJ)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMarkProcessorObj)
	COM_INTERFACE_ENTRY(IBaseClassDataProcessorObj)
END_COM_MAP()

// IMarkProcessorObj
public:
	STDMETHOD(ProcessData)(long lValue, float* pfloatResult)
	{
		bool bValid = VerifyData(lValue);
		if(!bValid)
		{
			return E_INVALIDARG;
		}

		*pfloatResult = ((float)lValue) * (float).5;
		return S_OK;
	}
};

#endif //__MARKPROCESSOROBJ_H_
