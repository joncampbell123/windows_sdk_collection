<% @LANGUAGE="JScript" %>
<HTML>
<HEAD>
<%
  // -----------------------------------------------------------
  // MetaData constructor function
  // Authors/Editors enter document-specific data here to populate INC'd elements
  // -----------------------------------------------------------

	function MetaData()
	{
		// -----------------------------------------------------------
		// Generic information entered for every document
		// Put in HEAD TITLE and META tags
		// -----------------------------------------------------------

		this.title = "My Custom Browser Sample Application Install Page";
		this.description = "A sample application that illustrates many of the techniques for creating and distributing Windows applications on the Web";
		this.keywords = "code download, Internet Explorer, CAB files, cabinet files, security";
		this.robots = "All";

		this.author = "Michael Edwards";
		this.posted = "11/24/98";
		this.updated = "";

		// -----------------------------------------------------------
		// Optional DocDataBlock in footer-xxx.inc
		// TENTATIVE
		// -----------------------------------------------------------

		this.displayDocDataBlock = false;
	}

	var oMD = new MetaData();
%>
<!-- #include virtual="/sitebuilder/shared/inc/header.inc" -->

<SCRIPT LANGUAGE="Javascript"><!--

	// -----------------------------------------------------------
	// window_load()
	// Container function for load.
	// -----------------------------------------------------------

	function window_load()
	{
		if (oBD.getsNavBar)
		{
			if ("function" == typeof(InitNavLinks)) InitNavLinks();
			if ("function" == typeof(CheckToTop)) CheckToTop();
		}
	}
	window.onload = window_load;

//--></SCRIPT>

</HEAD>

<BODY TOPMARGIN="0" LEFTMARGIN="0" MARGINHEIGHT="0" MARGINWIDTH="0" BGCOLOR="#FFFFFF">

<!-- #include virtual="/sitebuilder/shared/inc/doctop-wks.inc" -->

<DIV CLASS="clsDocBody">

<!-- DOCUMENT CONTENT START -->

<HTML>
<HEAD>

<script LANGUAGE="javascript">
<!--
function gotoInstallPage() 
{
  // sniff the browser to make sure they are running IE
  if (navigator.userAgent.indexOf("MSIE") >=  1)
    window.navigate("ie.htm");
  else
    window.navigate("netscape.htm");
}
//-->
</SCRIPT>
<h1>My Custom Browser Application Install Page</h1>
<HR CLASS="clsTransHR" />
<p>Michael Edwards<br>Developer Technology 
Engineer</p>
<p>This page demonstrates techniques from my article <a href="install.asp">Installing Windows Applications via the Web with Visual Studio 6.0</a> for installing a custom browser I built with Visual J++ 6.0. While the purpose of this page is to apply my installation guidelines, some of you may find the application itself interesting (or at least will want to know what the heck it is before installing it). So first I'll talk about the browser -- what any publisher should do on a Web page about their application - and then I'll discuss some installation guidelines. </p>
<h2>The Visual J++ 6.0 Sample Application</h2>
<p>The sample is a Windows browser application that implements most of the features found in  Internet Explorer. While you are welcome to use my browser as your preferred Web browser, I wrote the sample to demonstrate how Visual J++ applications can integrate browsing functionality by leveraging various publicly-supported Internet Explorer components.</p>
<p>Below is a screen shot of my browser in action:</p>
<p><img src="htmlcontrol.GIF" WIDTH="350" HEIGHT="215">
<br><b>Figure 1. My Sample Application browsing <a href="http://home.microsoft.com">http://home.microsoft.com</a></b></p>
<h3>Internet Explorer Features Used by My Browser</h3>
<ul>
    <li>The <b>WebBrowser Control</b> -- My browser uses the WebBrowser control 
    via the new <b>com.ms.wfc.ui.HTMLControl</b> WFC class introduced in the 2nd technology preview for Visual J++ 6.0.
    <li>An <b>Address Book</b> --	Internet Explorer and Outlook Express share a fully featured address book for storing contact information. This feature is also available for reuse in your own application, and is demonstrated in my browser from the &quot;Address Book&quot; item in the <b>Go</b> menu.
    <li>An <b>Internet Mail and News</b> feature -- Just like Internet Explorer, this browser accesses e-mail and Internet newsgroup applications. The &quot;Mail&quot; and &quot;News&quot; options in the <b>Go</b> menu activate the default Mail and News applications.
    <li><b>Shell Automation objects</b> -- Shell Automation objects are components that allow applications to access the Windows shell. The sample code discusses how to access shell components from Visual J++ in order to do such useful things as parse the client's Favorites folder to build their <b>Favorites</b> menu, duplicate the other functionality in the <b>Favorites</b> menu, and navigate Windows shell extensions such as the &quot;My Computer&quot; and &quot;Subscriptions&quot; folders.
    <li><b>And more</b> --	The sample code also demonstrates how to access the <b>Find</b> and <b>Internet Properties</b> dialog boxes, how to change font sizes, how to add items to the <b>Favorites</b> menu, and other functionality that you can borrow from Internet Explorer rather than waste time reproducing on your own. There is nothing here that isn't already documented elsewhere, but sometimes it is difficult to know where to look (so I include <i>lots</i> of comments in the source code to help you find all the relevant docs, and any caveats to keep in mind).</li></ul>
<h3>Known Issues</h3>
<p>There are a number of problems using the HTMLControl class with the Internet Explorer 5 Beta. These problems will be fixed in the final release of Internet Explorer 5. The sample application will still work, but certain important features won't function properly: 
</p>
<ul>
    <li>None of the WebBrowser events are received by the WFC event handler callbacks, which affects several other features (see the event handlers for details)
    <li><b>com.ms.ie.*</b> shell automation objects that were moved to shdoc401.dll from shdocvw.dll are inaccessible (ClassDefNotFound exceptions are thrown when the <b>Favorites</b> menu is opened), disabling much of the <b>Favorites</b> menu functionality (I'm not catching this exception either, so you will see the standard unhandled exception dialog)</li></ul>
<h4>
For more information 
</h4>
<p>
<a href="/workshop/browser/default.asp">Reusing Browser Technology</a> (in the SBN Workshop) includes all the documentation you need in order to reuse browser technologies in your own application (including <a href="/workshop/browser/reusebovw.asp">Reusing Internet Explorer and the WebBrowser Control:  An Array of Options</a>, an article Scott Roberts and I wrote about customizing Internet Explorer components).</p>

<H3>Install the Sample Application</H3>
<p><a href="javascript:gotoInstallPage()">Install the sample browser</a>. You will be taken to one of two pages, depending upon whether you are using Internet Explorer or a Netscape browser.</p>
<p><i>Disclaimer -- this application is unsupported by me or Microsoft. However, if you have feedback or make any nifty improvements to it, I'd love to hear from you.</i></p>
<h4>Installing with Internet Explorer browsers</h4>
<p>It is easier to install the sample application using an Internet Explorer browser because I can use script to detect whether the target computer has Internet Explorer 4 or 5 (via the navigator.userAgent string). Because <b>wfc.ui.HTMLControl</b> requires either Internet Explorer 4 or 5, we may need to update the copy of Internet Explorer on the target computer. Also, I use &lt;OBJECT&gt; tags to update two other dependencies, the Microsoft Virtual Machine for Java and the WBAddrBook component, without needing to include them in our self-extracting setup package (which will save umpteen hours of downloading for end-users with up-to-date versions).</p>
<H4>Installing with Netscape browsers</H4>
<p>If the end-user is browsing the install page with a Netscape browser, there is no pure scripting method available to determine if the target computer has Internet Explorer 4 or 5 installed. In that case, you could assume they don't have it, and offer a link to update their local copy of Internet Explorer before installing your application. That is what I am doing in 
this sample. There are other alternatives: 1) create a Netscape Plugin that will detect Internet Explorer, or 2) add Internet Explorer detection to your application startup procedures and display a suitable message to the end-user. (See below for more information on detecting Internet Explorer.) </p>
<H4>Installing via CD-ROM or a fast Intranet connection</H4>
<P>If you are distributing your install files on CD-ROM or over a fast Intranet, you don't need to be so hyper about the size of your distributables. A single installation setup application is probably preferable. If your application depended upon a recent version of Internet Explorer, or a big (in size) dependency you are licensing and distributing, you could include redistributables on your CD-ROM rather than sending them to an Internet site. This could significantly speed up the application installation process.</P>
<H4>For more information</H4>
<p> The <a href="/workshop/browser/license/licensing.asp">Licensing and Distribution area of the SBN Workshop</a> has details about redistributing Internet Explorer (including how to detect if it is installed). </p>
<H3>Download the source code and project files for the sample application</H3>
<p><a href="browser.zip">Browser.zip</a> contains the source files for the my sample browser application. The source code is heavily commented with additional details and tidbits.</p>
<p><a href="wbaddrbook.zip">WBAddrbook.zip</a> contains the sources for the Visual C++ (5.0 or 6.0) project that I created for use by my browser application. It builds the WBAddrbook.dll component that accesses some of the Internet Explorer technology used in the HTMLControl sample. See the code for additional details. </p>

<H3>Download the files for these sample install pages</H3>
<p><a href="install.zip">Install.zip</a> contains all the html files used in this article. </p>
<p></p>

<!-- DOCUMENT CONTENT END -->

</DIV>

<!-- #include virtual="/sitebuilder/shared/inc/footer-wks.inc" -->

</BODY>
</HTML>