// myMenuItem.java
// used to create favorite menu for browser sample
import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;
import com.ms.ie.*;
import com.ms.com.*;

public class myMenuItem extends MenuItem
{
    Object Data;

    public myMenuItem(String p1)
    {
        super(p1);
		Data = null;
    }
    public myMenuItem(String p1, EventHandler p2)
    {
        super(p1, p2);
		Data = null;
    }
    public void setData(Object Data)
    {
        this.Data = Data;
    }
    public Object getData()
    {
        return this.Data;
    }
	public void dispose()
	{
		super.dispose();
		if (Data != null)
		{
			ComLib.release((FolderItem) Data);
			Data = null;
		}
	}
}
