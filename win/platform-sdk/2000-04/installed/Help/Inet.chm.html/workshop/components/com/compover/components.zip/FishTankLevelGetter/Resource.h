//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FishTankLevelGetter.rc
//
#define IDS_PROJNAME                    100
#define IDS_LEVELGETTER_DESC            102
#define IDR_LevelGetter                 103

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
