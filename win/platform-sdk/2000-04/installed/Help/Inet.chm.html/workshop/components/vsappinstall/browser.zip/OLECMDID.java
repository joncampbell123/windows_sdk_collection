//
// Auto-generated using JActiveX.EXE 4.79.2611
//   ("d:\Microsoft Visual Studio\VJ98\jactivex.exe" /wfc /w /X:rkc /l "C:\TEMP\jvc34.tmp" /nologo /d "C:\My Documents\MyWebBrowser" "C:\WINNT\System32\SHDOCVW.DLL")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

// Enum: OLECMDID

public class OLECMDID extends com.ms.wfc.core.Enum
{
  public static final int OLECMDID_OPEN = 1;
  public static final int OLECMDID_NEW = 2;
  public static final int OLECMDID_SAVE = 3;
  public static final int OLECMDID_SAVEAS = 4;
  public static final int OLECMDID_SAVECOPYAS = 5;
  public static final int OLECMDID_PRINT = 6;
  public static final int OLECMDID_PRINTPREVIEW = 7;
  public static final int OLECMDID_PAGESETUP = 8;
  public static final int OLECMDID_SPELL = 9;
  public static final int OLECMDID_PROPERTIES = 10;
  public static final int OLECMDID_CUT = 11;
  public static final int OLECMDID_COPY = 12;
  public static final int OLECMDID_PASTE = 13;
  public static final int OLECMDID_PASTESPECIAL = 14;
  public static final int OLECMDID_UNDO = 15;
  public static final int OLECMDID_REDO = 16;
  public static final int OLECMDID_SELECTALL = 17;
  public static final int OLECMDID_CLEARSELECTION = 18;
  public static final int OLECMDID_ZOOM = 19;
  public static final int OLECMDID_GETZOOMRANGE = 20;
  public static final int OLECMDID_UPDATECOMMANDS = 21;
  public static final int OLECMDID_REFRESH = 22;
  public static final int OLECMDID_STOP = 23;
  public static final int OLECMDID_HIDETOOLBARS = 24;
  public static final int OLECMDID_SETPROGRESSMAX = 25;
  public static final int OLECMDID_SETPROGRESSPOS = 26;
  public static final int OLECMDID_SETPROGRESSTEXT = 27;
  public static final int OLECMDID_SETTITLE = 28;
  public static final int OLECMDID_SETDOWNLOADSTATE = 29;
  public static final int OLECMDID_STOPDOWNLOAD = 30;
  public static final int OLECMDID_ONTOOLBARACTIVATED = 31;
  public static final int OLECMDID_FIND = 32;
  public static final int OLECMDID_DELETE = 33;
  public static final int OLECMDID_HTTPEQUIV = 34;
  public static final int OLECMDID_HTTPEQUIV_DONE = 35;
  public static final int OLECMDID_ENABLE_INTERACTION = 36;
  public static final int OLECMDID_ONUNLOAD = 37;
  public static final int OLECMDID_PROPERTYBAG2 = 38;
  public static final int OLECMDID_PREREFRESH = 39;
}
