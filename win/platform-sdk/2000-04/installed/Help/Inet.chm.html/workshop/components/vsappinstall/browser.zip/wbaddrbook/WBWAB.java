//
// Auto-generated using JActiveX.EXE 5.00.2918
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe" /wfc  /w /xi /X:rkc /l "C:\TEMP\jvc12B.tmp" /nologo /d "C:\My Documents\TechEd98\MyWebBrowser.VJ" "C:\My Documents\TechEd98\WBAddrBook\ReleaseMinSize\WBAddrBook.dll")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package wbaddrbook;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

/** @com.class(classid=0340F05F-E75D-11D1-AFDB-000086189887,DynamicCasts) 
    @com.interface(iid=0340F05E-E75D-11D1-AFDB-000086189887, thread=AUTO, type=DUAL) */
public class WBWAB implements IUnknown,com.ms.com.NoAutoScripting,wbaddrbook.IWBWAB
{
  /** @com.method(vtoffset=4, dispid=1, type=PROPGET, name="WebBrowser", name2="getWebBrowser", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native Object getWebBrowser();

  /** @com.method(vtoffset=5, dispid=1, type=PROPPUTREF, name="WebBrowser", name2="putWebBrowser", addFlagsVtable=4)
      @com.parameters([in,iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] ppWebBrowser) */
  public native void setWebBrowser(Object ppWebBrowser);

  /** @com.method(vtoffset=6, dispid=2, type=PROPGET, name="Offline", name2="getOffline", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public native boolean getOffline();

  /** @com.method(vtoffset=7, dispid=2, type=PROPPUT, name="Offline", name2="putOffline", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pbOffline) */
  public native void setOffline(boolean pbOffline);

  /** @com.method(vtoffset=8, dispid=3, type=METHOD, name="ShowAddressBook", addFlagsVtable=4)
      @com.parameters([in,type=I4] __MIDL_0015) */
  public native void ShowAddressBook(int __MIDL_0015);

  /** @com.method(vtoffset=9, dispid=4, type=METHOD, name="ShowMail", addFlagsVtable=4)
      @com.parameters([in,type=I4] hWnd) */
  public native void ShowMail(int hWnd);

  /** @com.method(vtoffset=10, dispid=5, type=METHOD, name="ShowNews", addFlagsVtable=4)
      @com.parameters([in,type=I4] hWnd) */
  public native void ShowNews(int hWnd);

  /** @com.method(vtoffset=11, dispid=6, type=METHOD, name="ShowProperties", addFlagsVtable=4)
      @com.parameters() */
  public native void ShowProperties();

  /** @com.method(vtoffset=12, dispid=7, type=METHOD, name="ShowViewSource", addFlagsVtable=4)
      @com.parameters() */
  public native void ShowViewSource();

  /** @com.method(vtoffset=13, dispid=8, type=METHOD, name="ShowFind", addFlagsVtable=4)
      @com.parameters() */
  public native void ShowFind();

  /** @com.method(vtoffset=14, dispid=9, type=METHOD, name="ShowOrganizeFavorites", addFlagsVtable=4)
      @com.parameters([in,type=I4] __MIDL_0016) */
  public native void ShowOrganizeFavorites(int __MIDL_0016);

  /** @com.method(vtoffset=15, dispid=10, type=METHOD, name="ShowUpdateSubscriptions", addFlagsVtable=4)
      @com.parameters() */
  public native void ShowUpdateSubscriptions();

  /** @com.method(vtoffset=16, dispid=11, type=METHOD, name="ShowMyComputer", addFlagsVtable=4)
      @com.parameters([in,type=I4] __MIDL_0017) */
  public native void ShowMyComputer(int __MIDL_0017);

  /** @com.method(vtoffset=17, dispid=12, type=METHOD, name="GetURL", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] vPath, [out,elementType=VARIANT,type=PTR] vURL) */
  public native void GetURL(Variant vPath, Variant vURL);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x340f05e, (short)0xe75d, (short)0x11d1, (byte)0xaf, (byte)0xdb, (byte)0x0, (byte)0x0, (byte)0x86, (byte)0x18, (byte)0x98, (byte)0x87);

  public static final com.ms.com._Guid clsid = new com.ms.com._Guid((int)0x340f05f, (short)0xe75d, (short)0x11d1, (byte)0xaf, (byte)0xdb, (byte)0x0, (byte)0x0, (byte)0x86, (byte)0x18, (byte)0x98, (byte)0x87);
}
