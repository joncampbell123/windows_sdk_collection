// DollarProcessorObj.h : Declaration of the CDollarProcessorObj

#ifndef __DOLLARPROCESSOROBJ_H_
#define __DOLLARPROCESSOROBJ_H_

#include "resource.h"       // main symbols

#include <BaseClassDataProcessorObj.h>

// CDollarProcessorObj
class ATL_NO_VTABLE CDollarProcessorObj : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDollarProcessorObj, &CLSID_DollarProcessorObj>,
	public CBaseClassDataProcessorObj
{
public:
	CDollarProcessorObj(){}

DECLARE_REGISTRY_RESOURCEID(IDR_DOLLARPROCESSOROBJ)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDollarProcessorObj)
	COM_INTERFACE_ENTRY(IBaseClassDataProcessorObj)
END_COM_MAP()

// IDollarProcessorObj
public:

	//There is no implementation here which will cause
	//it to use base class methods.
};

#endif //__DOLLARPROCESSOROBJ_H_
