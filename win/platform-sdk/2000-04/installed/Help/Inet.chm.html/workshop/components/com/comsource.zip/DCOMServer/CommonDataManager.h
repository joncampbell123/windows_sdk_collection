#ifndef _COMMON_DATA_MANAGER_H_
#define _COMMON_DATA_MANAGER_H_

class CDCOMServerObj;

#include <vector>
using namespace std;


/////////////////////////////////////////////////////////////////////////////////

interface ICallBackObj;

class CDCOMServerArrayElement
{
public:

	CDCOMServerObj*			m_pDCOMServerObj;
	ICallBackObj*			m_pICallBackObj;

	CDCOMServerArrayElement(CDCOMServerObj* pDCOMServerObj, ICallBackObj* pICallBackObj);

	virtual ~CDCOMServerArrayElement();

};



/////////////////////////////////////////////////////////////////////////////////

class CDataQueue;

class CCommonDataManager
{
public:
	CCommonDataManager();
	virtual ~CCommonDataManager();

	bool RegisterClientCallBack(CDCOMServerObj* pDCOMServerObj, //an instance of the com object
								ICallBackObj* pICallBackObj);	//client call back's interface

	void DataManagerAddEntry(long lValue, CDCOMServerObj* pDCOMServerObj);

	void UnregisterClientCallBacks(CDCOMServerObj* pDCOMServerObj); //an instance of the com object

	int SendDataToServer(long lData, CDCOMServerObj* pDCOMServerObj);

protected:

	CDataQueue* m_pDataQueue;
	bool m_bThreadStarted;

	
	//critical section and vector array
	CRITICAL_SECTION m_CommonDataManagerCriticalSection;
	vector<CDCOMServerArrayElement*> m_DCOMServerArray;
};
 
/////////////////////////////////////////////////////////////////////////////////


#endif //_COMMON_DATA_MANAGER_H_



