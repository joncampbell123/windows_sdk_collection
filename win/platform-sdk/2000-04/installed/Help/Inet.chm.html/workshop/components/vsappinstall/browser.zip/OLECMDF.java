//
// Auto-generated using JActiveX.EXE 4.79.2611
//   ("d:\Microsoft Visual Studio\VJ98\jactivex.exe" /wfc /w /X:rkc /l "C:\TEMP\jvc34.tmp" /nologo /d "C:\My Documents\MyWebBrowser" "C:\WINNT\System32\SHDOCVW.DLL")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

// Enum: OLECMDF

public class OLECMDF extends com.ms.wfc.core.Enum
{
  public static final int OLECMDF_SUPPORTED = 1;
  public static final int OLECMDF_ENABLED = 2;
  public static final int OLECMDF_LATCHED = 4;
  public static final int OLECMDF_NINCHED = 8;
}
