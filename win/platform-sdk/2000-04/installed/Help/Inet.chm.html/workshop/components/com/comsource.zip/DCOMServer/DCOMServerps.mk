
DCOMServerps.dll: dlldata.obj DCOMServer_p.obj DCOMServer_i.obj
	link /dll /out:DCOMServerps.dll /def:DCOMServerps.def /entry:DllMain dlldata.obj DCOMServer_p.obj DCOMServer_i.obj \
		kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib \

.c.obj:
	cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL \
		$<

clean:
	@del DCOMServerps.dll
	@del DCOMServerps.lib
	@del DCOMServerps.exp
	@del dlldata.obj
	@del DCOMServer_p.obj
	@del DCOMServer_i.obj
