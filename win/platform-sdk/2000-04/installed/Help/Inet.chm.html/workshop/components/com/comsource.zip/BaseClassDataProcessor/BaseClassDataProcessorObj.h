#ifndef __BASECLASSDATAPROCESSOROBJ_H_
#define __BASECLASSDATAPROCESSOROBJ_H_

class CBaseClassDataProcessorObj : public IBaseClassDataProcessorObj
{
protected:
	virtual bool VerifyData(long lValue)
	{
		if(lValue < 0)
		{
			_ASSERTE(false);
			return false;
		}
		return true;
	}

	STDMETHOD(ProcessData)(long lValue, float* pfloatResult)
	{
		bool bValid = VerifyData(lValue);
		if(!bValid)
		{
			return E_INVALIDARG;
		}

		*pfloatResult = (float) lValue;
		return S_OK;
	}

};

#endif //__BASECLASSDATAPROCESSOROBJ_H_
