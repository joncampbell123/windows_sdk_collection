<% response.expires="0" %><html><head>

<!--
ASP code � 1997 Aaron Bertrand
e-mail: aaron@waterworksia.com
-->

<%
br1 = lcase(request.servervariables("http_user_agent"))
dim ie4
ie4="false" ' sets initial value, unless it passes the following:
if instr(br1,"95")>0 or instr(br1,"nt")>0 or instr(br1,"98")>0 then 
	if instr(br1,"mozilla/4.0")>0 and instr(br1,"msie 4")>0 then
		if instr(br1,"4.0b1")<=0 then
			ie4="true"
		end if 
	end if
end if %>

<% if ie4="true" then %>

<% 
star1 = trim(lcase(request.queryString("star1")))
star2 = trim(lcase(request.queryString("star2")))
star3 = trim(lcase(request.queryString("star3")))
star4 = trim(lcase(request.queryString("star4")))
tourn1 = trim(lcase(request.queryString("tourn1")))
tourn2 = trim(lcase(request.queryString("tourn2")))
tourn3 = trim(lcase(request.queryString("tourn3")))
tourn4 = trim(lcase(request.queryString("tourn4")))

dim today1,month1,weekday1,trunc
weekdaya = weekday(date)
montha = month(date)
daya = day(date)

if weekdaya = 1 then
	weekday1 = "Sunday"
elseif weekdaya = 2 then
	weekday1 = "Monday"
elseif weekdaya = 3 then
	weekday1 = "Tuesday"
elseif weekdaya = 4 then
	weekday1 = "Wednesday"
elseif weekdaya = 5 then
	weekday1 = "Thursday"
elseif weekdaya = 6 then
	weekday1 = "Friday"
elseif weekdaya = 7 then
	weekday1 = "Saturday"
end if
if montha = 1 then 
	month1 = "January"
elseif montha = 2 then 
	month1 = "February"
elseif montha = 3 then 
	month1 = "March"
elseif montha = 4 then 
	month1 = "April"
elseif montha = 5 then 
	month1 = "May"
elseif montha = 6 then 
	month1 = "June"
elseif montha = 7 then 
	month1 = "July"
elseif montha = 8 then 
	month1 = "August"
elseif montha = 9 then 
	month1 = "September"
elseif montha = 10 then 
	month1 = "October"
elseif montha = 11 then 
	month1 = "November"
elseif montha = 12 then 
	month1 = "December"
end if
if daya = 1 or daya = 21 or daya =31 then
	trunc = "st"
elseif daya = 2 or daya = 22 then
	trunc = "nd"
elseif daya = 3 or daya = 23 then
	trunc = "rd"
else
	trunc="th"
end if
today1 = weekday1 & ", " & month1 & " " & daya & trunc
today2 = month1 & " " & daya & trunc
%>

<title>eXplore Summer '97 - <%= today2 %></title>

<style type="text/css">
<!--
body { font-size: 10pt; font-family: verdana,arial; color: black }
input1  { font-size: 10pt; font-family: verdana,arial; color: navy }
-->
</style>

</head>

<script language="vbscript">
' msgbox "Welcome to my eXplore Summer '97 entry.",0," eXplore Summer '97"
if screen.width > 950 then 
	bgimage = "1"
elseif screen.width > 700 then
	bgimage = "2"
else
	bgimage = "3"
end if
document.write("<body bgcolor=#ffffff bgproperties=fixed topmargin=4 background=")
document.write("back" & bgimage & ".jpg link=#000080 vlink=#000080 alink=#000080>")
</script><center><table

 border=0 width=80%><tr><td><center><div style="font-family: verdana,tahoma,arial; font-size: 25pt; color: #008000"><b><div id="aaron"
   style="background-color:white;filter:revealTrans(Duration=3.0, Transition=8);width:400;height:25"><div id="bertrand"
      style="background-color:white;font-family:verdana,tahome,arial;color:#008000;font-size:25pt;width:400;height:25;text-decoration:underline;"></div></div></b></div></center><p style="font-family: verdana,tahoma,arial; font-size: 10pt; color: #000000"><div width=80%>The object is to unscramble the words to reveal names of world-class tennis stars... start by moving your mouse over the stars preceding each clue, then rearrange the letters that appear.  The clues themselves refer to actual Grand Slam tournaments... can you guess which tournaments they are?  Questions you miss will be highlighted in red once you submit your answers.  Once all the answers say <b style="color: #000080">"x was correct"</b> press <b>Submit</b> one more time.  Good luck!</div></p><p><form

 name="tennis" action="default.asp"><center><hr

 width=500 color=#666666 size=1><div id="game"><br><b><div style="font-family: verdana,tahoma,arial; font-size: 10pt; color: #000080"><span id="tourney1" style="font-size: 8pt; cursor: hand">** 1. **</span>&nbsp; This tournament is played on grass courts in England.</div></b><div id="str1" style="display: none"><p><span style="font-size: 8pt">Name of star: </span><input class=input1 type="text" name="star1" size=20 style="font-family: verdana,arial; font-size: 8pt; color: navy"><span style="font-size: 8pt"> Tournament: </span><input class=input1 type="text" name="tourn1" size=25 style="font-family: verdana,arial; font-size: 8pt; color: navy"><p></div><hr

 width=500 color=#666666 size=1><br><b><div

 style="font-family: verdana,tahoma,arial; font-size: 10pt; color: #000080"><span id="tourney2" style="font-size: 8pt; cursor: hand">** 2. **</span>&nbsp; This is a clay court tournament held in Southern France.</div></b><div id="str2" style="display: none"><p><span style="font-size: 8pt">Name of star: </span><input class=input1 type="text" name="star2" size=23 style="font-family: verdana,arial; font-size: 8pt; color: navy"><span style="font-size: 8pt"> Tournament: </span><input class=input1 type="text" name="tourn2" size=25 style="font-family: verdana,arial; font-size: 8pt; color: navy"><p></div><hr

 width=500 color=#666666 size=1><br><b><div

 style="font-family: verdana,tahoma,arial; font-size: 10pt; color: #000080"><span id="tourney3" style="font-size: 8pt; cursor: hand">** 3. **</span>&nbsp; Dubbed the "giant-killer," this tourney is held down under.</div></b><div id="str3" style="display: none"><p><span style="font-size: 8pt">Name of star: </span><input class=input1 type="text" name="star3" size=21 style="font-family: verdana,arial; font-size: 8pt; color: navy"><span style="font-size: 8pt"> Tournament: </span><input class=input1 type="text" name="tourn3" size=28 style="font-family: verdana,arial; font-size: 8pt; color: navy"><p></div><hr

 width=500 color=#666666 size=1><br><b><div

 style="font-family: verdana,tahoma,arial; font-size: 10pt; color: #000080"><span id="tourney4" style="font-size: 8pt; cursor: hand">** 4. **</span>&nbsp; This tournament is on hard courts here in North America.</div></b><div id="str4" style="display: none"><p><span style="font-size: 8pt">Name of star: </span><input class=input1 type="text" name="star4" size=21 style="font-family: verdana,arial; font-size: 8pt; color: navy"><span style="font-size: 8pt"> Tournament: </span><input class=input1 type="text" name="tourn4" size=28 style="font-family: verdana,arial; font-size: 8pt; color: navy"><p></div></div><div

 id="congrats" style="display: none">
<div style="font-family: brushart,verdana,tahoma,arial; font-size: 22pt; color: #000080"><b><marquee width=500>Congratulations!</marquee></b><br><div style="font-size: 10pt; font-family: verdana,tahoma,arial"><a id="won" style="text-decoration: none" href="mailto:webmaster@desktop.on.ca?subject=I won! (<%= date %>)">e-mail Aaron</a></div></div></div><br><hr

 width=500 color=#666666 size=1><div id="footer"><br><input type=button name="start" value="Start over" style="cursor: hand; font-family: verdana,tahoma,arial; color: white; background-color: #000080; border-color: white"><span id="submitter" style="visibility: hidden"><input  id="b1"  type=button name="button1" value="Submit" style="cursor: hand; font-family: verdana,tahoma,arial; color: white; background-color: #000080; border-color: white"></span></form><hr

 width=240 color=#666666 size=1></div><br><div style="font-family: verdana,tahoma,arial; font-size: 8pt; color: #666666"><%= today1 %><br>Designed by <a id="link1" href="mailto:webmaster@desktop.on.ca" style="color:#000080;text-decoration:none">Aaron Bertrand</a></div></td></tr></table></body>


<script language="vbscript">

sub button1_onclick()
	tennis.submit()
end sub


sub link1_onmouseover()
	link1.style.color="#ff0000"
	link1.style.textDecoration="underline"
end sub


sub link1_onmouseout()
	link1.style.color="#000080"
	link1.style.textDecoration="none"
end sub


sub start_onclick()
	window.location.href="contest.asp"
end sub


<% if star1 = "" then %>

sub tourney1_onmouseover()
	tennis.star1.value="iasgas"
	str1.style.display=""
	submitter.style.visibility="visible"
end sub

<% elseif star1 = "agassi" or star1 = "'agassi' was correct" then %>

	tennis.star1.value="'Agassi' was correct"
	str1.style.display="inline"
	submitter.style.visibility="visible"

<% elseif star1<>"" and star1<>"agassi" then
	if star1<>"'agassi' was correct" then %>

	tennis.star1.value="iasgas"
	tennis.star1.style.color="red"
	str1.style.display="inline"
	submitter.style.visibility="visible"
	
	<% end if
end if %>



<% if tourn1 = "" then %>

	tennis.tourn1.value="What is this tournament?"

<% elseif tourn1="what is this tournament?" then %>

	tennis.tourn1.value="What is this tournament?"
	tennis.tourn1.style.color="red"

<% elseif tourn1 <> "wimbledon" and tourn1 <> "wimbeldon" and tourn1 <> "'wimbledon' was correct" then %>
	<%
		if instr(tourn1,"was incorrect")>0 then 
			tourn1 = left(tourn1,len(tourn1)-14)
		end if 
	%>
	tennis.tourn1.value="<%= tourn1 %> was incorrect"
	tennis.tourn1.style.color="red"

<% else %>

	tennis.tourn1.value="'Wimbledon' was correct"

<% end if %>



<% if star2 = "" then %>

sub tourney2_onmouseover()
	tennis.star2.value="amsspar"
	str2.style.display="inline"
	submitter.style.visibility="visible"
end sub

<% elseif star2 = "sampras" or star2 = "'sampras' was correct" then %>
	
	tennis.star2.value="'Sampras' was correct"
	str2.style.display="inline"
	submitter.style.visibility="visible"

<% else %>

	tennis.star2.value="amsspar"
	tennis.star2.style.color="red"
	str2.style.display="inline"
	submitter.style.visibility="visible"

<% end if %>



<% if tourn2 = "" then %>

	tennis.tourn2.value="What is this tournament?"

<% elseif tourn2="what is this tournament?" then %>
	
	tennis.tourn2.value="What is this tournament?"
	tennis.tourn2.style.color="red"

<% elseif tourn2 <> "french open" and tourn2 <> "french" and tourn2 <> "'french open' was correct" then %>

	<%
		if instr(tourn2,"was incorrect")>0 then 
			tourn2 = left(tourn2,len(tourn2)-14)
		end if 
	%>

	tennis.tourn2.value="<%= tourn2 %> was incorrect"
	tennis.tourn2.style.color="red"

<% else %>

	tennis.tourn2.value="'French Open' was correct"

<% end if %>

<% if star3 = "" then %>

sub tourney3_onmouseover()
	tennis.star3.value="redbge"
	str3.style.display="inline"
	submitter.style.visibility="visible"
end sub

<% elseif star3 = "edberg" or star3 = "'edberg' was correct" then %>

	tennis.star3.value="'Edberg' was correct"
	str3.style.display="inline"
	submitter.style.visibility="visible"

<% else %>
	
	tennis.star3.value="redbge"
	tennis.star3.style.color="red"
	str3.style.display="inline"
	submitter.style.visibility="visible"

<% end if %>


<% if tourn3 = "" then %>
	
	tennis.tourn3.value="What is this tournament?"

<% elseif tourn3="what is this tournament?" then %>

	tennis.tourn3.value="What is this tournament?"
	tennis.tourn3.style.color="red"

<% elseif tourn3 <> "australian open" and tourn3 <> "australian" and tourn3 <> "'australian open' was correct" then %>

	<%
		if instr(tourn3,"was incorrect")>0 then 
			tourn3 = left(tourn3,len(tourn3)-14)
		end if 
	%>

	tennis.tourn3.value="<%= tourn3 %> was incorrect"
	tennis.tourn3.style.color="red"

<% else %>

	tennis.tourn3.value="'Australian Open' was correct"

<% end if %>



<% if star4 = "" then %>

sub tourney4_onmouseover()
	tennis.star4.value="cerbke"
	str4.style.display="inline"
	submitter.style.visibility="visible"
end sub

<% elseif star4 = "becker" or star4 = "'becker' was correct" then %>
	
	tennis.star4.value="'Becker' was correct"
	str4.style.display="inline"
	submitter.style.visibility="visible"

<% else %>

	tennis.star4.value="cerbke"
	tennis.star4.style.color="red"
	str4.style.display="inline"
	submitter.style.visibility="visible"

<% end if %>



<% if tourn4 = "" then %>

	tennis.tourn4.value="What is this tournament?"

<% elseif tourn4="what is this tournament?" then %>

	tennis.tourn4.value="What is this tournament?"
	tennis.tourn4.style.color="red"

<% elseif tourn4 <> "us open" and tourn4 <> "u.s. open" and tourn4 <> "u.s." and tourn4 <> "us" and tourn4 <> "'us open' was correct" then %>

	<%
		if instr(tourn4,"was incorrect")>0 then 
			tourn4 = left(tourn4,len(tourn4)-14)
		end if 
	%>

	tennis.tourn4.value="<%= tourn4 %> was incorrect"
	tennis.tourn4.style.color="red"

<% else %>
	
	tennis.tourn4.value="'US Open' was correct"

<% end if %>

<% if instr(star1,"agassi") and instr(star2,"sampras") and instr(star3,"edberg") and instr(star4,"becker") then
	if instr(tourn1,"wimb") and instr(tourn2,"french") and instr(tourn3,"aus") and instr(tourn4,"us") then 
%>

	game.style.display="none"
	congrats.style.display="inline"
	footer.style.display="none"

sub won_onmouseover()
	won.style.textDecoration="underline"
end sub

sub won_onmouseout()
	won.style.textdecoration="none"
end sub

<% 
	end if
end if %>

dim curtrans
dim speed
curtrans = 0
speed=3.7

sub window_onLoad()
	bertrand.style.visibility = "hidden"
	call aaronb()
end sub

sub aaron_onfilterchange()
	call aaronb()
end sub

sub aaronb()
	call aaron.filters.item(0).apply()

	randomize
	abert = int(6*rnd+1)

	if abert = 1 then
		berta = 2
	elseif abert = 2 then
		berta = 12
	elseif abert = 3 then
		berta = 6
	elseif abert = 4 then
		berta = 5
	elseif abert = 5 then
		berta = 14
	else
		berta = 17
	end if

   	aaron.filters.item(0).transition = berta

	if curtrans = 0 then
		bertrand.innertext = "Tennis Scramble"
		bertrand.style.visibility = "visible"
	elseif curtrans = 1 then
		bertrand.innertext = ""
		bertrand.style.visibility = "visible"
	elseif curtrans = 2 then
		bertrand.innertext = "Guess the Stars"
		bertrand.style.visibility = "visible"
	elseif curtrans = 3 then
		bertrand.innertext = ""
		bertrand.style.visibility = "visible"
	elseif curtrans = 4 then
		bertrand.innertext = "Name the Tourneys"
		bertrand.style.visibility = "visible"
	elseif curtrans = 5 then
		bertrand.innertext = ""
		bertrand.style.visibility = "visible"
	else
		bertrand.innertext = "Tennis Scramble"
		bertrand.style.visibility = "visible"
	end if

	aaron.filters(0).play(speed)

	curtrans = curtrans + 1
	if curtrans = 6 then 
		' curtrans = 0
		' the above line would repeat the loop over and over
	
		exit sub
		' instead I choose not to eternally annoy + distract the viewer
	end if

end sub

</script>

<% else %>

	</head><body><h1>407 Browser Not Advanced<h3>Sorry, IE4 (build 1008.3) or higher is required to experience the page you requested.<p>Visit <a href='http://www.desktop.on.ca/default.asp'>Desktop Innovations</a></body>

<% end if %>

</html>