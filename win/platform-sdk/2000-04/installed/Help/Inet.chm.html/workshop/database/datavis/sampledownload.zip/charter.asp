<%
	If IsObject(Session("charter_conn")) Then
		Set conn = Session("charter_conn")
	Else
		Set conn = Server.CreateObject("ADODB.Connection")
		conn.open "charter","",""
		Set Session("charter_conn") = conn
	End If

	Dim iShowFruit, iOrderDescending, sYear, iAxisMax
	Dim lAppleQty, iAppleWidth, lMaxApples
	Dim lOrangeQty, iOrangeWidth, lMaxOranges

	If Request.Form("radShowFruit") <> "" Then
		iShowFruit = Request.Form("radShowFruit")
	Else
		iShowFruit = 3
	End If

	iOrderDescending = 0
	If CInt(Request.Form("radOrderDescending")) = 1 Then
		iOrderdescending = 1
	End If

	Function IsChecked(iVariableValue,iElementValue)
		IsChecked = ""
		If CInt(iVariableValue) = CInt(iElementValue) Then
			IsChecked = " CHECKED"
		End If
	End Function

	sql = "SELECT Max(Apples) AS MaxApples FROM tblFruits "
	Set rs = Server.CreateObject("ADODB.Recordset")
	rs.Open sql, conn, 3, 3
	lMaxApples = rs.Fields("MaxApples")

	sql = "SELECT Max(Oranges) AS MaxOranges FROM tblFruits "
	Set rs = Server.CreateObject("ADODB.Recordset")
	rs.Open sql, conn, 3, 3
	lMaxOranges = rs.Fields("MaxOranges")

	iAxisMax = lMaxApples
	If lMaxOranges > lMaxApples Then
		iAxisMax = lMaxOranges
	End If
	iAxisMax = Round(iAxisMax/100 + 1) * 100	

	If iOrderDescending = 0 Then 
		sql = "SELECT [Year], [Apples], [Oranges] FROM tblFruits ORDER BY [Year] "
	Else 
		sql = "SELECT [Year], [Apples], [Oranges] FROM tblFruits ORDER BY [Year] DESC "
	End If
	Set rs = Server.CreateObject("ADODB.Recordset")
	rs.Open sql, conn, 3, 3
%>
<HTML>
<HEAD>
<TITLE>ASP HTML Charter Application</TITLE>
<STYLE>
<!--
	BODY { font-size:10pt; font-family:Verdana; }
	H1 { font-size:18pt; color:teal; }
	H2 { font-size:14pt; color:indianred; }
	TH { font-size:8pt; font-family:Verdana; }
	TD { font-size:8pt; font-family:Verdana; }
	INPUT { font-size:8pt; font-family:Verdana; }
-->
</STYLE>
</HEAD>
<BODY BGCOLOR="beige">
<H1>ASP HTML Charter Application</H1>

<!-- OPEN OUTER POSITIONING TABLE -->
<TABLE BORDER=0><TR><TD VALIGN="top">

<H2>I. Raw Data</H2>

<TABLE BORDER=1 BGCOLOR="white" CELLSPACING=0>
	<TR>
		<TH BGCOLOR="silver">Year</TH>
		<TH BGCOLOR="silver">Apples</TH>
		<TH BGCOLOR="silver">Oranges</TH>
	</TR>
<%
	On Error Resume Next
	rs.MoveFirst
	Do While Not rs.EOF
%>
	<TR VALIGN=TOP>
		<TD ALIGN="right"><%= rs.Fields("Year").Value %></TD>
		<TD ALIGN="right"><%= rs.Fields("Apples").Value %></TD>
		<TD ALIGN="right"><%= rs.Fields("Oranges").Value %></TD>
</TR>
<%
		rs.MoveNext
	Loop
%>
</TABLE>

<!-- CENTER SPACING CELL FOR POSITIONING TABLE -->
</TD>
<TD>&nbsp;&nbsp;&nbsp;&nbsp;</TD>
<TD VALIGN="top">

<H2>II. Charted Data</H2>

<TABLE BORDER=1 BGCOLOR="white" CELLSPACING=0>
	<TR>
		<TH BGCOLOR="silver" COLSPAN=2>Fruit Production</TH>
	</TR>
<%
	On Error Resume Next
	rs.MoveFirst
	Do While Not rs.EOF
	
	sYear = rs.Fields("Year").Value
	lOrangeQty = rs.Fields("Oranges").Value
	lAppleQty = rs.Fields("Apples").Value
	iOrangeWidth = (lOrangeQty/2000) * 200
	iAppleWidth = (lAppleQty/2000) * 200
 %>
	<TR>
		<TD><%= sYear %></TD>
<% 
	If CInt(iShowFruit) = 1 Then 
%>
		<TD WIDTH=200 VALIGN="middle"><IMG HEIGHT=5 WIDTH=<%= iAppleWidth %> SRC="appledot.gif"></TD>
<% 
	ElseIf CInt(iShowFruit) = 2 Then 
%>
		<TD WIDTH=200 VALIGN="middle"><IMG HEIGHT=5 WIDTH=<%= iOrangeWidth %> SRC="orangdot.gif"></TD>
<% 
	ElseIf CInt(iShowFruit) = 3 Then 
%>
		<TD WIDTH=200 VALIGN="middle"><IMG HEIGHT=5 WIDTH=<%= iAppleWidth %> SRC="appledot.gif"><IMG HEIGHT=5 WIDTH=<%= iOrangeWidth %> SRC="orangdot.gif"></TD>
<% 
	End If
%>
	</TR>
<%
		rs.MoveNext
	Loop
	rs.Close
%>
	<TR>
		<TD>&nbsp;</TD>
		<TD>
			<TABLE BORDER=0 CELLPADDING=0 CELLSPACING=0 WIDTH="100%">
				<TR>
					<TD WIDTH="33%" ALIGN="left">0</TD>
					<TD WIDTH="33%" ALIGN="center">'</TD>
					<TD WIDTH="33%" ALIGN="right"><%= iAxisMax %></TD>
				</TR>
			</TABLE>
		</TD>
	<TR>
<% 
	If CInt(iShowFruit) = 1 Then 
%>
		<TD ALIGN="center" VALIGN="middle" COLSPAN=2><IMG HEIGHT=5 WIDTH=5 SRC="appledot.gif"> Apples</TD>
<% 
	ElseIf CInt(iShowFruit) = 2 Then 
%>
		<TD ALIGN="center" VALIGN="middle" COLSPAN=2><IMG HEIGHT=5 WIDTH=5 SRC="orangdot.gif"> Oranges</TD>
<% 
	ElseIf CInt(iShowFruit) = 3 Then 
%>
		<TD ALIGN="center" VALIGN="middle" COLSPAN=2><IMG HEIGHT=5 WIDTH=5 SRC="appledot.gif"> Apples &nbsp;&nbsp;&nbsp;&nbsp; <IMG HEIGHT=5 WIDTH=5 SRC="orangdot.gif"> Oranges</TD>
<% 
	End If
%>
	</TR>
</TABLE>

<!-- OPEN OUTER POSITIONING TABLE -->
</TD></TR></TABLE>

<FORM NAME="frmChart" ACTION="charter.asp" METHOD="post">
<TABLE BORDER=0 BGCOLOR="silver" CELLSPACING=1 CELLPADDING=2>
	<TR>
		<TH BGCOLOR="navy" COLSPAN=3><FONT COLOR="white">Chart Options</FONT></TH>
	</TR>
	<TR>
		<TD VALIGN="top"><B>View Fruit:</B></TD>
		<TD VALIGN="top">&nbsp;&nbsp;&nbsp;</TD>
		<TD VALIGN="top"><B>Order Years:</B></TD>
	</TR>
	<TR>
		<TD ALIGN="left" VALIGN="middle"><INPUT TYPE="radio" NAME="radShowFruit" VALUE=1<%= IsChecked(iShowFruit,1) %>>Apples </TD>
		<TD ALIGN="left" VALIGN="middle">&nbsp;&nbsp;&nbsp;</TD>
		<TD ALIGN="left" VALIGN="middle"><INPUT TYPE="radio" NAME="radOrderDescending" VALUE=0<%= IsChecked(iOrderDescending,0) %>>Ascending </TD>
	</TR>
	<TR>
		<TD><INPUT TYPE="radio" NAME="radShowFruit" VALUE=2<%= IsChecked(iShowFruit,2) %>>Oranges </TD>
		<TD>&nbsp;&nbsp;&nbsp;</TD>
		<TD><INPUT TYPE="radio" NAME="radOrderDescending" VALUE=1<%= IsChecked(iOrderDescending,1) %>>Descending </TD>
	</TR>
	<TR>
		<TD><INPUT TYPE="radio" NAME="radShowFruit" VALUE=3<%= IsChecked(iShowFruit,3) %>>Both </TD>
		<TD>&nbsp;&nbsp;&nbsp;</TD>
		<TD>&nbsp; </TD>
	</TR>
	<TR>
		<TD ALIGN="center" COLSPAN=3><INPUT TYPE="submit" NAME="btnSubmit" VALUE="Update Chart"></TD>
	</TR>
</TABLE>
</FORM>
</BODY>
</HTML>