<%@ LANGUAGE = JScript %>
<%
  // Set the source and style sheet locations here
  var sourceFile = Server.MapPath("simple.xml");
  var styleFile = Server.MapPath("simple.xsl");
  
  // Load the XML 
  var source = Server.CreateObject("Microsoft.XMLDOM");
  source.async = false;
  source.load(sourceFile);

  // Load the XSL
  var style = Server.CreateObject("Microsoft.XMLDOM");
  style.async = false;
  style.load(styleFile);

  source.transformNodeToObject(style, Response);

%>
