These sources accompany the October 27 Extreme XML column, "Internet Explorer 5 and XML."

showEmpInfoAlert.htm - loads employees.xml, accesses typed values and displays that
typed value in a dialogue box.  The data is typed through an XML schema.

showEmpInfoDB.htm - binds a repeated table to an XML data Island via the new C++ XMLDSO.

showEmpInfoXSL.htm - uses the XSL stylesheet, "employeeTable.xsl", to display the data in
"employees.xml".

employeesMV.xml - when run through the XML Mime Viewer, the Mime Viewer uses the xsl stylesheet,
"employeeTableMV.xsl" to display the data within "employeesMV.xml".  

employeeSchema.xml - this is the schema used to validate "employees.xml" and "employeesMV.xml".
