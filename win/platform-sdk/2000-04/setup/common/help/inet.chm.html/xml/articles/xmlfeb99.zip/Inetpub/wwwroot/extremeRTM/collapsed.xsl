<?xml version="1.0"?>
  <DIV xmlns:xsl="http://www.w3.org/TR/WD-xsl" STYLE="font-family:Arial, helvetica, sans-serif; font-size:12pt;
        background-color:#EEEEEE">
    <DIV STYLE="font-weight:bold;font-size=16pt">
      <xsl:value-of select="@date"/>
    </DIV>
    <xsl:for-each select="meeting" order-by="+ start-time">
      <DIV STYLE="background-color:#8B0000; color:#FFFFFF; padding:4px">
        <SPAN STYLE="font-weight:bold; color:white"><xsl:value-of select="start-time"/>
        - <xsl:value-of select="end-time"/>   Subject: <xsl:value-of select="subject"/></SPAN>
      </DIV>
    </xsl:for-each>
  </DIV>