<%@LANGUAGE=VBScript%>
<%

Set NEWCUSTINFO = Server.CreateObject("Microsoft.XMLDOM")
Set CUSTLIST = Server.CreateObject("Microsoft.XMLDOM")

NEWCUSTINFO.async=false
NEWCUSTINFO.load(Request)

CUSTLIST.async = false
CUSTLIST.load(Server.MapPath("customers.xml"))
 
Set CUSTROOT = CUSTLIST.documentElement
Set CUSTOMERS = CUSTROOT.childNodes
Set NEWCUSTROOT = NEWCUSTINFO.documentElement
QUERY = "./customer[name='" & NEWCUSTROOT.childNodes.item(0).text & "']"

Set CUSTDUP = CUSTROOT.selectSingleNode(QUERY)

If isNull(CUSTDUP) = False Then
  CUSTROOT.removeChild(CUSTDUP)
End If

CUSTROOT.appendChild(NEWCUSTROOT)
CUSTLIST.save(Server.MapPath("customers.xml"))

%>

