Attribute VB_Name = "Module1"
Function GetNSInfo(currentNode As IXMLDOMNode)
  Dim I As Integer
  Module1.fillGrid currentNode, False
  If currentNode.nodeTypeString = "element" Then
    For I = 0 To currentNode.Attributes.length - 1
      Module1.fillGrid currentNode.Attributes.Item(I), True
    Next
  End If
  If currentNode.hasChildNodes = True Then
    For I = 0 To currentNode.childNodes.length - 1
      Module1.GetNSInfo currentNode.childNodes.Item(I)
    Next
  End If
  
  
    
End Function

Sub init()
  Module1.resetGrid
End Sub

Function fillGrid(curNode As IXMLDOMNode, indent As Boolean)
  Dim strType As String
  Dim strName As String
  Dim strPrefix As String
  Dim strBase As String
  Dim strNSURI As String
  
  Dim strIndent As String
  strIndent = "  "
  
  If indent = True Then
  strType = strIndent & curNode.nodeTypeString
  Else: strType = curNode.nodeTypeString
  End If
  strName = curNode.nodeName
  strPrefix = curNode.prefix
  strBase = curNode.baseName
  strNSURI = curNode.namespaceURI
  
  Form1.MSFlexGrid1.AddItem (strType & vbTab & strName & vbTab & strPrefix & vbTab & strBase & vbTab & strNSURI)
End Function

Function resetGrid()
  Form1.MSFlexGrid1.Cols = 5
  Form1.MSFlexGrid1.Rows = 1
  Form1.MSFlexGrid1.ColWidth(0) = 1000
  Form1.MSFlexGrid1.ColWidth(1) = 1000
  Form1.MSFlexGrid1.ColWidth(2) = 750
  Form1.MSFlexGrid1.ColWidth(3) = 1000
  Form1.MSFlexGrid1.ColWidth(4) = 3000
  Form1.MSFlexGrid1.Col = 0
  Form1.MSFlexGrid1.Row = 0
  Form1.MSFlexGrid1.CellFontBold = True
  Form1.MSFlexGrid1.Text = "nodeType"
  Form1.MSFlexGrid1.Col = 1
  Form1.MSFlexGrid1.Row = 0
  Form1.MSFlexGrid1.CellFontBold = True
  Form1.MSFlexGrid1.Text = "nodeName"
  Form1.MSFlexGrid1.Col = 2
  Form1.MSFlexGrid1.Row = 0
  Form1.MSFlexGrid1.CellFontBold = True
  Form1.MSFlexGrid1.Text = "prefix"
  Form1.MSFlexGrid1.Col = 3
  Form1.MSFlexGrid1.Row = 0
  Form1.MSFlexGrid1.CellFontBold = True
  Form1.MSFlexGrid1.Text = "baseName"
  Form1.MSFlexGrid1.Col = 4
  Form1.MSFlexGrid1.Row = 0
  Form1.MSFlexGrid1.CellFontBold = True
  Form1.MSFlexGrid1.Text = "namespaceURI"
End Function
