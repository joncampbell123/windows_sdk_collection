<%@ LANGUAGE = VBScript %>

<%
'	Process the submission of a single bid.

    title = Request.QueryString("title")
    price = Request.QueryString("price")
    bidder = Request.QueryString("bidder")

    Set Conn = Server.CreateObject("ADODB.Connection")
    Conn.Open "Auction","auction","auction"
	Set BidRS = Conn.Execute("select * from bids where Title Like '" & title & "' ORDER BY Price DESC")
    BidRS.MoveFirst
    valid = 1
	if Not BidRS.EOF then
        currentprice = BidRS("Price")
        if (currentprice >= CLng(price)) then 
            valid = 0
            bidder = BidRS("bidder")
        end if
    end if

    if (valid > 0) then
	    Set RS = Server.CreateObject("ADODB.RecordSet")
	    connect = "data source=Auction;user id=auction;password=auction;"
	    RS.CursorType = 2
	    RS.LockType = 3			' read/write
	    RS.Open "bids", connect
	    RS.AddNew
	    RS("title") = title
	    RS("price") = price
	    RS("bidder") = bidder
	    RS("time") = Time
	    RS.Update
	    RS.Close %>
        <OK>ok</>
<%  else %>
        <ERROR>Your bid was beaten by '<%=bidder%>'</>
<%  end if %>