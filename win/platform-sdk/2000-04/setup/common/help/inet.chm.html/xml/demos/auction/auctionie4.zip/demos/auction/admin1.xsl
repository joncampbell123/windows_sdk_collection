<xsl>
	<rule>
		<root/>
		<TABLE style="font-family:Verdana;font-size:14pt;background-color:#000000; color:#FFFFFF" CELLSPACING="4">
			<TR>
				<TD ALIGN="CENTER" WIDTH="30%"><B>ITEM</B></TD>
				<TD ALIGN="RIGHT" WIDTH="30%"><B>HIGH BID</B></TD>
				<TD ALIGN="RIGHT" WIDTH="30%"><B>HIGH BIDDER</B></TD>
			</TR>
			<children/>
		</TABLE>
	</rule>
	<rule>
		<target-element type="ITEM"/>
		<TR>
		  <children/>	
		</TR>
	</rule>
	
	<rule>
		<target-element type="TITLE"/>
		<TD onclick="handleEvent()"><children/></TD>
	</rule>
	
	<rule>
		<target-element type="BIDS"/>
		<children/>
	</rule>
	<rule>
		<target-element type="BID" position="first-of-type"/>
		<children/>
	</rule>
	<rule>
		<target-element type="PRICE"/>
		<TD ALIGN="right">$<children/></TD>
	</rule>
	<rule>	
		<target-element type="BIDDER"/>
		<TD ALIGN="RIGHT"><children/></TD>
	</rule>
	
	<rule>
		<target-element/>
		<empty/>
	</rule>
</xsl>
