<xsl>
  <rule>
    <root/>
	  <TABLE id="iteminfo" WIDTH="100%" CELLPADDING="0" CELLSPACING="0" BORDER="0" STYLE="visibility:hidden">
	    <TR VALIGN="top">
		  <TD>
		  	<DIV STYLE="margin-left:16px; margin-top:16px; margin-right:16px">
			  <DIV ID="pict"></DIV>

			  <DIV CLASS="details">
					<select-elements from="descendants">
						<target-element type="MATERIALS"/>
					</select-elements>
					<select-elements from="descendants">
						<target-element type="YEAR"/>
					</select-elements>
					<select-elements from="descendants">
						<target-element type="DIMENSIONS"/>
					</select-elements>
					<IMG SRC="images/page.gif" hspace="5" style="cursor:hand" 
                        title="Click here to see the XML representing this item."
                        onclick="showxml()"/>
			  </DIV>
			</DIV>
		 </TD>
		</TR>
		<TR>
		 <TD WIDTH="100%">
			<TABLE BORDER="0" CELLPADDING="0" CELLSPACING="0" WIDTH="100%">
			<TR><TD>
				<DIV CLASS="title" STYLE="margin-top:16px; margin-right:8px; margin-top:16px">
					<select-elements from="descendants">
						<target-element type="ARTIST"/>
					</select-elements>
					<select-elements from="descendants">
						<target-element type="TITLE"/>
					</select-elements>
                </DIV>
                <DIV CLASS="copyright">
                    Copyright &copy; 1997 Linda Mann, all rights reserved. <A HREF="http://home.navisoft.com/lindamann/" target="_top">Linda Mann Art Gallery</A>
                </DIV>
				</TD>
			</TR>				
			</TABLE>
		</TD>
	   </TR>
	</TABLE>
  </rule>
  <rule>
	<target-element type="ITEM"/>
	<children/>
  </rule>
  <rule>
	<target-element type="MATERIALS"/>
	<SPAN><children/></SPAN>
  </rule>
  <rule>
	<target-element type="YEAR"/>
	<SPAN><children/></SPAN>
  </rule>
  <rule>
	<target-element type="DIMENSIONS"/>
	<SPAN><children/></SPAN>
  </rule>
  <rule>
	<target-element type="ARTIST"/>
	<DIV><children/></DIV>
  </rule>
  <rule>
	<target-element type="TITLE"/>
	<DIV><children/></DIV>
  </rule>
  <rule>
	<target-element/>
	<empty/>
  </rule>
</xsl>