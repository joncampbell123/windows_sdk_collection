VERSION 5.00
Object = "{5E9E78A0-531B-11CF-91F6-C2863C385E30}#1.0#0"; "MSFLXGRD.OCX"
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   6480
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   8055
   LinkTopic       =   "Form1"
   ScaleHeight     =   6480
   ScaleWidth      =   8055
   StartUpPosition =   3  'Windows Default
   Begin MSFlexGridLib.MSFlexGrid MSFlexGrid1 
      Height          =   4335
      Left            =   0
      TabIndex        =   3
      Top             =   1920
      Width           =   7095
      _ExtentX        =   12515
      _ExtentY        =   7646
      _Version        =   393216
      Rows            =   1
      Cols            =   5
      FixedRows       =   0
      FixedCols       =   0
      ScrollTrack     =   -1  'True
      ScrollBars      =   2
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Find Namespace Info"
      Height          =   375
      Left            =   120
      TabIndex        =   2
      Top             =   1200
      Width           =   2055
   End
   Begin VB.TextBox XMLlocation 
      Height          =   375
      Left            =   120
      TabIndex        =   0
      Text            =   "cameras.xml"
      Top             =   600
      Width           =   3255
   End
   Begin VB.Label Label1 
      Caption         =   "Enter XML File Location:"
      Height          =   255
      Left            =   120
      TabIndex        =   1
      Top             =   240
      Width           =   2055
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim xmldoc1 As New MSXML.DOMDocument

Private Sub Command1_Click()
  Dim docRoot As IXMLDOMNode
  Module1.resetGrid
  xmldoc1.async = False
  xmldoc1.Load (XMLlocation.Text)
  If xmldoc1.parseError.reason <> "" Then
    MsgBox xmldoc1.parseError.reason & vbCr & xmldoc1.parseError.srcText
  Else
  Set docRoot = xmldoc1.documentElement
  GetNSInfo docRoot
  End If
End Sub


Private Sub Form_Load()
  Module1.init
End Sub

