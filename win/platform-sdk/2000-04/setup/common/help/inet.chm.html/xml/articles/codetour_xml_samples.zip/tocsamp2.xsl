
<?xml version="1.0"?>

<xsl:stylesheet xmlns:xsl="http://www.w3.org/TR/WD-xsl">

	<xsl:template match="/">

   <HTML>
   <HEAD>
   <TITLE>SBN Workshop - <xsl:value-of select="TOC/TOCINFO/TITLE" /> Topic Listing</TITLE>
   <META NAME="robots" CONTENT="noindex" />
   <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1" />

   <SCRIPT>
   //<xsl:comment><![CDATA[
	  var sUA = window.navigator.userAgent;
	  var bIsIE4 = -1 != sUA.indexOf("MSIE 4"); 
	  var bIsIE5 = -1 != sUA.indexOf("MSIE 5"); 
	  var bIsMac = sUA.indexOf("Mac") > -1;
	  var bDoesAll = (bIsIE4 || bIsIE5) && !bIsMac;

	  var sSheet = "/sitebuilder/shared/css/";
	  if (bDoesAll || bIsMac) 
	  {
	  	if (bIsMac) sSheet += "ie4Mac-toc.css";
	  	else sSheet += "ie4-toc.css";
	  }
	  else 
	  {
	  	sSheet += "all-toc.css";
	  }
	  document.write('<LINK REL="stylesheet" TYPE="text/css" HREF="' + sSheet + '">');

    function newItem(sStampDate) {
      dExpireDate = new Date(sStampDate)
      if (Date.parse(Date()) < Date.parse(dExpireDate))	{
         document.write("<IMG SRC='/sitebuilder/graphics/new1.gif' ALIGN='middle' WIDTH='19' HEIGHT='9' BORDER='0' ALT='New'>");
      }
    }

    function updatedItem(sStampDate) {
      dExpireDate = new Date(sStampDate)
      if (Date.parse(Date()) < Date.parse(dExpireDate))	{
         document.write("<IMG SRC='/sitebuilder/graphics/rev1.gif' WIDTH='19' HEIGHT='9' BORDER='0' ALT='Updated'>");
      }
   }

   // do nothing but enable items to receive focus
   function NoOp()
   {
      return;
   }   

   //]]></xsl:comment>
   </SCRIPT>

   </HEAD>
   <BODY BGCOLOR="white" TOPMARGIN="0" LEFTMARGIN="0" MARGINHEIGHT="0" MARGINWIDTH="0" LINK="#000066" VLINK="#666666" TEXT="#000000">

   <TABLE CELLPADDING="5" WIDTH="100%">
   <TR>
      <TD ALIGN="center"><A ID="lnkToWorkshop" HREF="/workshop/toc.htm"><IMG ALIGN="top" ID="imgUp" HEIGHT="13" WIDTH="17" BORDER="0" TITLE="Workshop TOC" SRC="/workshop/graphics/icons/nl-up-0.gif" /><B>workshop toc</B></A></TD>
   </TR>
   </TABLE>

   <TABLE CELLPADDING="7" CELLSPACING="0" WIDTH="100%">
   <TR>
      <TD ALIGN="left" VALIGN="middle" BGCOLOR="#99CCFF"><A ID="lnkBucketTitle" expResetToc="true"><xsl:attribute name="HREF"><xsl:value-of select="TOC/TOCINFO/HREF"/></xsl:attribute><IMG ID="imgBucketIcon" HEIGHT="32" WIDTH="31" BORDER="0"><xsl:attribute name="SRC"><xsl:value-of select="TOC/TOCINFO/ICON"/></xsl:attribute><xsl:attribute name="ALT"><xsl:value-of select="TOC/TOCINFO/TITLE"/></xsl:attribute></IMG></A></TD>
      <TD ALIGN="left" VALIGN="middle" WIDTH="100%" BGCOLOR="#99CCFF"><A ID="lnkBucketTitle" expResetToc="true"><xsl:attribute name="HREF"><xsl:value-of select="TOC/TOCINFO/HREF"/></xsl:attribute><B><xsl:value-of select="TOC/TOCINFO/TITLE" /> TOC</B></A></TD>
   </TR>
   </TABLE>


   <FONT SIZE="1" FACE="Verdana,Arial,Helvetica">
   <UL STYLE="behavior:url('/sitebuilder/shared/htc/tocstate.htc')">
   <xsl:for-each select="TOC/SECTIONS/SECTION">
	
      <xsl:apply-templates select="SECTIONINFO" />
      <xsl:apply-templates select="ARTICLES"/>

   </xsl:for-each>
   </UL>
   </FONT>

   <SCRIPT>
   //<xsl:comment><![CDATA[
   if (bDoesAll) {
      document.write("<SCR" + "IPT LANGUAGE='javascript' SRC='/sitebuilder/shared/js/toc.js'></SCR" + "IPT>");
   }
   //]]></xsl:comment>
   </SCRIPT>
   </BODY>
   </HTML>

   </xsl:template>


	<xsl:template match="ARTICLES">
    <UL CLASS="clsItemsHide">

      <!-- can be simplified to ARTICLE | ARTICLE/VERSION[@VID='IE5B2']" for RTW -->
      <xsl:for-each select=".//*[(nodeName()='ARTICLE' $and$ HREF) $or$ (nodeName()='VERSION' $and$ @VID='IE5B2')]"> 

      <!-- Process all ARTICLEs with VERSIONs as immediate children -->
      <!-- Process all ARTICLEs with HREFs as immediate children -->

            <LI><A CLASS="clsTOCItem">

            <xsl:choose>
            <xsl:when test="*[TARGET]">
              <xsl:attribute name="TARGET"><xsl:value-of select="TARGET" /></xsl:attribute>
            </xsl:when>
            <xsl:when test="*[LINKTYPE]">
              <xsl:attribute name="TARGET">_top</xsl:attribute>
            </xsl:when>
           </xsl:choose>

           <xsl:if match="*[ABSTRACT]">
              <xsl:attribute name="TITLE"><xsl:value-of select="ABSTRACT" /></xsl:attribute>
           </xsl:if>

           <xsl:attribute name="HREF"><xsl:value-of select="HREF"/></xsl:attribute><xsl:value-of select="TITLE"/></A>
           <xsl:apply-templates select="LINKTYPE" />
           <xsl:apply-templates select="UPDATED" />
           <xsl:apply-templates select="POSTED" />

           </LI>
        </xsl:for-each> <!-- ARTICLE | ARTICLES/VERSION -->

         </UL>		
	</xsl:template>

  <!-- Process all vanilla SECTIONINFOs which are siblings of ARTICLES collections -->
  <xsl:template match="SECTIONINFO">
     <LI CLASS="clsShowHide"><A HREF="javascript:NoOp()" CLASS="clsTOCHeading"><xsl:value-of select="TITLE"/></A>
	 <xsl:apply-templates select="UPDATED" />
	 <xsl:apply-templates select="POSTED" />
     </LI>
  </xsl:template>

	  <!-- BUGBUG: Need a clean way to set expNewToc correctly -->
      <!-- In 5.0.708.600 this works correctly, but it feels 'hackish' -->
	  <!-- Process all SECTIONINFOs with HREF subelements -->
      <xsl:template match="SECTIONINFO[HREF]">
         <LI CLASS="noexpand"><A CLASS="clsTOCHeading">
		 <xsl:attribute name="HREF"><xsl:value-of select="HREF"/></xsl:attribute>

		<xsl:choose>
		   <xsl:when test="*[TARGET]">
		      <xsl:attribute name="TARGET"><xsl:value-of select="TARGET" /></xsl:attribute>
		   </xsl:when>
		   <xsl:when test="*[LINKTYPE]">
		      <xsl:attribute name="TARGET">_top</xsl:attribute>
		   </xsl:when>
		</xsl:choose>

		 <xsl:value-of select="TITLE"/></A>
		 <xsl:apply-templates select="LINKTYPE" />
		 <xsl:apply-templates select="UPDATED" />
		 <xsl:apply-templates select="POSTED" />
         </LI>
      </xsl:template>

	  <!-- Process all SECTIONINFOs with NEWTOC attributes -->
	  <!-- Don't generate a TARGET for these although a LINKTYPE might be interesting -->
      <xsl:template match="SECTIONINFO[@NEWTOC]">
         <LI CLASS="noexpand"><A expNewToc="true" CLASS="clsTOCHeading">

		<xsl:if match="*[ABSTRACT]"><xsl:attribute name="TITLE"><xsl:value-of select="ABSTRACT" /></xsl:attribute></xsl:if>
		 <xsl:attribute name="HREF"><xsl:value-of select="HREF"/></xsl:attribute><xsl:value-of select="TITLE"/></A>
		 <xsl:apply-templates select="LINKTYPE" />
		 <xsl:apply-templates select="UPDATED" />
		 <xsl:apply-templates select="POSTED" />
		 </LI>
      </xsl:template>

      <xsl:template match="SECTIONINFO[VERSION[@VID='IE5B2']]">
         <LI CLASS="noexpand"><A CLASS="clsTOCHeading">
		 <xsl:attribute name="HREF"><xsl:value-of select="VERSION[@VID='IE5B2']/HREF"/></xsl:attribute>
		 <xsl:value-of select="VERSION[@VID='IE5B2']/TITLE"/></A>
		 <xsl:apply-templates select="VERSION[@VID='IE5B2']/LINKTYPE" />
		 <xsl:apply-templates select="VERSION[@VID='IE5B2']/UPDATED" />
		 <xsl:apply-templates select="VERSION[@VID='IE5B2']/POSTED" />
         </LI>
      </xsl:template>

      <xsl:template match="UPDATED">
         <SCRIPT LANGUAGE="javascript">//<xsl:comment><![CDATA[
         updatedItem("]]><xsl:value-of /><![CDATA[")
        //]]></xsl:comment></SCRIPT>
      </xsl:template>

      <xsl:template match="POSTED">
         <SCRIPT LANGUAGE="javascript">//<xsl:comment><![CDATA[
         newItem("]]><xsl:value-of /><![CDATA[")
         //]]></xsl:comment></SCRIPT>
      </xsl:template>

	  <!-- The following rule handles plugging in the non-ms and non-sbn icon 
	  Between the two icons, three attributes differ: width, alt, and image name
	  -->

 	  <xsl:template match="LINKTYPE[.='leave-sbn']">
       	<xsl:entityref name="nbsp" /><IMG BORDER="0" HEIGHT="11" WIDTH="17" ALT="Non-SBN link" SRC="/sitebuilder/graphics/leave-site.gif"/>
	  </xsl:template>
     
 	  <xsl:template match="LINKTYPE[.='leave-ms']">
        <xsl:entityref name="nbsp" /><IMG BORDER="0" HEIGHT="11" WIDTH="33" ALT="Non-MS link" SRC="/sitebuilder/graphics/leave-ms.gif"/>
      </xsl:template>
 
</xsl:stylesheet>

