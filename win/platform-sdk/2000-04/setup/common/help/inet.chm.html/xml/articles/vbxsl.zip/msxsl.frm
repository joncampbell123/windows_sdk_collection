VERSION 5.00
Object = "{EAB22AC0-30C1-11CF-A7EB-0000C05BAE0B}#1.1#0"; "shdocvw.dll"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Begin VB.Form frmXSL 
   Caption         =   "XSL Processor"
   ClientHeight    =   8595
   ClientLeft      =   165
   ClientTop       =   450
   ClientWidth     =   9765
   LinkTopic       =   "Form1"
   ScaleHeight     =   8595
   ScaleWidth      =   9765
   StartUpPosition =   3  'Windows Default
   Begin ComctlLib.StatusBar oSB 
      Align           =   2  'Align Bottom
      Height          =   375
      Left            =   0
      TabIndex        =   15
      Top             =   8220
      Width           =   9765
      _ExtentX        =   17224
      _ExtentY        =   661
      Style           =   1
      SimpleText      =   ""
      _Version        =   327682
      BeginProperty Panels {0713E89E-850A-101B-AFC0-4210102A8DA7} 
         NumPanels       =   1
         BeginProperty Panel1 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Tag             =   ""
         EndProperty
      EndProperty
   End
   Begin ComctlLib.TabStrip oTabStrip 
      Height          =   255
      Left            =   240
      TabIndex        =   13
      Top             =   1680
      Width           =   9015
      _ExtentX        =   15901
      _ExtentY        =   450
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   1
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
   Begin VB.CommandButton cmdSelectOutput 
      Caption         =   "..."
      Height          =   375
      Left            =   6480
      TabIndex        =   12
      Top             =   1080
      Width           =   495
   End
   Begin VB.TextBox txtOutPath 
      Height          =   375
      Left            =   840
      TabIndex        =   10
      Text            =   "d:\workshop\author\toc.htm"
      Top             =   1080
      Width           =   5535
   End
   Begin VB.CommandButton cmdSave 
      Caption         =   "&Save"
      Height          =   375
      Left            =   7440
      TabIndex        =   9
      Top             =   1080
      Width           =   1215
   End
   Begin MSComDlg.CommonDialog oDlg 
      Left            =   9120
      Top             =   120
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton cmdOpenXSL 
      Caption         =   "..."
      Height          =   375
      Left            =   6480
      TabIndex        =   7
      Top             =   600
      Width           =   495
   End
   Begin VB.CommandButton cmdOpenXML 
      Caption         =   "..."
      Height          =   375
      Left            =   6480
      TabIndex        =   6
      Top             =   120
      Width           =   495
   End
   Begin VB.TextBox txtHTML 
      Height          =   6135
      Left            =   240
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   5
      Top             =   1920
      Width           =   9015
   End
   Begin VB.CommandButton cmdParse 
      Caption         =   "&Merge"
      Height          =   375
      Left            =   7440
      TabIndex        =   4
      Top             =   600
      Width           =   1215
   End
   Begin VB.TextBox txtXSL 
      Height          =   375
      Left            =   840
      TabIndex        =   2
      Text            =   "d:\workshop\templates\toc.xsl"
      Top             =   600
      Width           =   5535
   End
   Begin VB.TextBox txtXML 
      Height          =   375
      Left            =   840
      TabIndex        =   0
      Text            =   "d:\workshop\author\toc.xml"
      Top             =   120
      Width           =   5535
   End
   Begin SHDocVwCtl.WebBrowser oWB 
      Height          =   6135
      Left            =   240
      TabIndex        =   14
      Top             =   1920
      Width           =   9015
      ExtentX         =   15901
      ExtentY         =   10821
      ViewMode        =   0
      Offline         =   0
      Silent          =   0
      RegisterAsBrowser=   0
      RegisterAsDropTarget=   1
      AutoArrange     =   0   'False
      NoClientEdge    =   0   'False
      AlignLeft       =   0   'False
      ViewID          =   "{0057D0E0-3573-11CF-AE69-08002B2E1262}"
      Location        =   ""
   End
   Begin VB.Frame Frame1 
      Caption         =   "Results"
      Height          =   6735
      Left            =   120
      TabIndex        =   8
      Top             =   1440
      Width           =   9375
   End
   Begin VB.Label Label3 
      AutoSize        =   -1  'True
      Caption         =   "Output"
      Height          =   195
      Left            =   240
      TabIndex        =   11
      Top             =   1200
      Width           =   480
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      Caption         =   "XSL"
      Height          =   195
      Left            =   240
      TabIndex        =   3
      Top             =   720
      Width           =   300
   End
   Begin VB.Label label1 
      AutoSize        =   -1  'True
      Caption         =   "XML"
      Height          =   195
      Left            =   240
      TabIndex        =   1
      Top             =   240
      Width           =   330
   End
End
Attribute VB_Name = "frmXSL"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim g_bMerged As Boolean
Private Sub cmdOpenXML_Click()
Dim sPath As String
sPath = OpenFile("Select an XML data set to process", ".xml", "XML (*.xml) | *.xml")
If sPath = "" Then
    Exit Sub
Else
    txtXML.Text = sPath
End If
End Sub

Private Sub cmdOpenXSL_Click()
Dim sPath As String
sPath = OpenFile("Select XSL template to use", ".xsl", "XSL (*.xsl) | *.xsl")
If sPath = "" Then
    Exit Sub
Else
    txtXSL.Text = sPath
End If
End Sub

Private Function ChooseSaveFile(sTitle, sExt, sFilter) As String
oDlg.DialogTitle = sTitle
oDlg.FileName = "*" & sExt
oDlg.DefaultExt = sExt
oDlg.Filter = sFilter
oDlg.ShowSave
ChooseSaveFile = oDlg.FileName
End Function

Private Function OpenFile(sTitle, sExt, sFilter) As String
oDlg.DialogTitle = sTitle
oDlg.DefaultExt = sExt
oDlg.Filter = sFilter
oDlg.ShowOpen
OpenFile = oDlg.FileName
End Function
Private Sub cmdParse_Click()
    g_bMerged = DoMerge(txtXML.Text, txtXSL.Text)
End Sub

Function EnsureMerge(sXML As String, sXSL As String) As Boolean
If g_bMerged Then
    EnsureMerge = True
Else
    g_bMerged = DoMerge(sXML, sXSL)
    EnsureMerge = g_bMerged
End If
End Function

' Merge the specified XML document and the specified XSL sheet
Function DoMerge(sXML As String, sXSL As String) As Boolean
    Dim oXMLDoc As New MSXML.DOMDocument
    Dim oXSLDoc As New MSXML.DOMDocument
    Dim iHadError As Integer
    txtHTML.Text = ""
    oXMLDoc.Load sXML
    If oXMLDoc.parseError.reason <> "" Then
        txtHTML.Text = oXMLDoc.parseError.reason
        iHadError = iHadError + 1
    End If
    oXSLDoc.Load sXSL
    If oXSLDoc.parseError.reason <> "" Then
        txtHTML.Text = txtHTML.Text & vbCrLf & txtXSL.Text & "(" & oXSLDoc.parseError.Line & "): " & oXSLDoc.parseError.reason
        iHadError = iHadError + 1
    End If

    If iHadError Then
        DoMerge = False
        Exit Function
    End If
    
    ' Merge the XML and XSL documents
    On Error Resume Next
    Dim sHTML As String
    sHTML = oXMLDoc.transformNode(oXSLDoc.documentElement)
    If Err.Number <> 0 Then
        txtHTML.Text = Err.Source & " Error. HRESULT=" & Err.Number & vbCrLf & Err.Description
        DoMerge = False
    Else
        ' Output the results in the HTML textarea
        txtHTML.Text = sHTML
        DoMerge = True
    End If
End Function

Private Sub cmdSave_Click()
If Not g_bMerged Then
    g_bMerged = DoMerge(txtXML.Text, txtXSL.Text)
    If Not g_bMerged Then
        Exit Sub
    End If
End If
If txtOutPath.Text = "" Then
    txtOutPath.Text = GetOutFilePath()
    If txtOutPath.Text = "" Then
        Exit Sub
    End If
End If

SaveFile txtOutPath.Text, txtHTML.Text
End Sub

Private Function SaveFile(sPath, sData) As Boolean
Dim oFS As New Scripting.FileSystemObject
Dim oFile As Scripting.TextStream
On Error Resume Next
Set oFile = oFS.CreateTextFile(sPath)
If Err.Number <> 0 Then
    MsgBox Err.Description & " (" & Err.Number & ")"
    SaveFile = False
    Exit Function
End If
oFile.Write (sData)
oFile.Close
Set oFile = Nothing
Set oFS = Nothing
SaveFile = True
End Function

Private Sub cmdSelectOutput_Click()
Dim sPath As String
sPath = GetOutFilePath()
If sPath = "" Then
    Exit Sub
Else
    txtOutPath.Text = sPath
End If
End Sub

Private Function GetOutFilePath() As String
GetOutFilePath = ChooseSaveFile("Save the output", ".htm", "HTML (*.htm;*.html) | *.htm, *.html")
End Function

Private Sub Form_Load()
' Initialize the file open/save dialog
oDlg.Flags = cdlOFNHideReadOnly + cdlOFNLongNames + cdlOFNFileMustExist
g_bMerged = False
oTabStrip.Tabs(1).Caption = "Code"
Dim oTab As ComctlLib.Tab
Set oTab = oTabStrip.Tabs.Add
oTab.Caption = "Browse"
oSB.SimpleText = "Ready"
End Sub

Private Sub oTabStrip_BeforeClick(Cancel As Integer)
If Not EnsureMerge(txtXML.Text, txtXSL.Text) Then
    Cancel = True
    Exit Sub
End If
Dim sCaption As String
sCaption = oTabStrip.SelectedItem.Caption
If sCaption = "Browse" Then
    txtHTML.Visible = True
    oWB.Visible = False
ElseIf sCaption = "Code" Then
    If g_bMerged Then
        oWB.Navigate txtOutPath.Text
        txtHTML.Visible = False
        oWB.Visible = True
        
    Else
        Cancel = True
    End If
Else
    MsgBox "Not sure what to do"
End If
End Sub

Private Sub oWB_BeforeNavigate2(ByVal pDisp As Object, URL As Variant, Flags As Variant, TargetFrameName As Variant, PostData As Variant, Headers As Variant, Cancel As Boolean)
    If URL = "" Then
        Cancel = True
    End If
End Sub

Private Sub oWB_StatusTextChange(ByVal StatusText As String)
    oSB.SimpleText = StatusText
End Sub
