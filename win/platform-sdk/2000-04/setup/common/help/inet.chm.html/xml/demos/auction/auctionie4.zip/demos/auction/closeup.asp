<%@ LANGUAGE = JScript %>
<html>
<meta name="Microsoft Theme" content="mdcont 011, default"><body topmargin="0" leftmargin="0" background="../../_themes/mdcont/modtextb.gif" bgcolor="#FFFFFF" text="#000000" link="#CC3333" vlink="#808080" alink="#FF3366"><!--mstheme--><font face="verdana, arial, helvetica">
 <img src="<% Response.Write(Request.QueryString("image")); %>">
<!--mstheme--></font></body>
</html>