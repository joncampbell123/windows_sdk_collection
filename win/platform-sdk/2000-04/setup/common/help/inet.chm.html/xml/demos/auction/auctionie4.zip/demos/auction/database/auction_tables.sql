/* Microsoft SQL Server - Scripting			*/
/* Server: XMLWEB					*/
/* Database: Auction					*/
/* Creation Date 10/23/97 11:23:25 AM 			*/

/****** Object:  Table dbo.Bids3    Script Date: 9/22/97 2:25:37 PM ******/
if exists (select * from sysobjects where id = object_id('dbo.Bids') and sysstat & 0xf = 3)
	drop table dbo.Bids
GO

/****** Object:  Table dbo.Item    Script Date: 9/22/97 2:25:37 PM ******/
if exists (select * from sysobjects where id = object_id('dbo.Item') and sysstat & 0xf = 3)
	drop table dbo.Item
GO

/****** Object:  Table dbo.Bids3    Script Date: 10/23/97 11:23:33 AM ******/
CREATE TABLE dbo.Bids (
	Timestamp int IDENTITY (1, 1) NOT NULL ,
	Title varchar (64) NULL ,
	Price money NULL ,
	Time datetime NULL ,
	Bidder varchar (64) NULL 
)
GO

/****** Object:  Table dbo.Item    Script Date: 10/23/97 11:23:33 AM ******/
CREATE TABLE dbo.Item (
	ID int IDENTITY (1, 1) NOT NULL ,
	Title varchar (32) NULL ,
	Artist varchar (32) NULL ,
	Dimensions varchar (16) NULL ,
	Materials varchar (16) NULL ,
	Year int NULL ,
	Description varchar (64) NULL ,
	Preview_small varchar (64) NULL ,
	Preview_large varchar (64) NULL ,
	Bid_price money NULL ,
	Bid_time datetime NULL ,
	Bid_Bidder varchar (64) NULL ,
	Status varchar (32) NULL ,
	CONSTRAINT PK_Item2_1__11 PRIMARY KEY  CLUSTERED 
	(
		ID
	)
)
GO

