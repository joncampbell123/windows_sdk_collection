VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H00C0C0C0&
   Caption         =   "Form1"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "Process Customer"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   1920
      TabIndex        =   2
      Top             =   1080
      Width           =   2175
   End
   Begin VB.TextBox Text1 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   1920
      TabIndex        =   1
      Text            =   "ALFKI"
      Top             =   360
      Width           =   2175
   End
   Begin VB.Label Label1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Enter Customer ID:"
      ForeColor       =   &H8000000D&
      Height          =   255
      Left            =   360
      TabIndex        =   0
      Top             =   480
      Width           =   1335
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim con As ADODB.Connection
Dim rs As ADODB.Recordset
Dim xmlstr As String
Dim xmldoc As MSXML.DOMDocument
Dim xmlhttp As MSXML.XMLHTTPRequest
Dim xsldoc As MSXML.DOMDocument
Dim message As MSXML.DOMDocument


Private Sub Command1_Click()
  Dim query As String
  query = "Select * FROM Customers WHERE CustomerID = '" & Text1.Text & "'"
  
  MsgBox query
  
  Set rs = con.Execute(query)
  
  'Persist Recordset to file as XML
  On Error Resume Next
    Kill ("recordset.xml")
  rs.Save "recordset.xml", adPersistXML

  xmldoc.async = False
  xmldoc.Load ("recordset.xml")
  
  MsgBox xmldoc.selectSingleNode("//z:row").xml
  
  'Load the stylesheet to standardize the XML
  xsldoc.async = False
  xsldoc.Load ("standard.xsl")
  
  'Standardize the XML
  xmldoc.transformNodeToObject xsldoc, message
  MsgBox message.xml
  
  'Post the XML to server for processing
  Set xmlhttp = New MSXML.XMLHTTPRequest
  xmlhttp.Open "POST", "http://platdemo2/process.asp", False
  xmlhttp.send message
  MsgBox xmlhttp.responseXML.xml
End Sub

Private Sub Form_Load()
  init
End Sub

Private Sub init()
  'Create and Open the ADODB Connection
  Set con = New ADODB.Connection
  con.ConnectionString = "DSN=nwind;UID=sa;PWD=;"
  con.Open
  
  'Instatiation the XML Document Objects
  Set xmldoc = New MSXML.DOMDocument
  Set xsldoc = New MSXML.DOMDocument
  Set message = New MSXML.DOMDocument
  
End Sub


