<%@Language=VBScript%>
<%
client = Request.ServerVariables("HTTP_USER_AGENT")
version = Split(client,";",-1,1)
IF version(1) = " MSIE 5.0b2" Then%>
  <HTML>
    <BODY>
      <XML ID="XMLDoc"></XML>
      <XML ID="XSLDoc"></XML>
      <DIV ID="insertHTML"></DIV>
      <SCRIPT LANGUAGE=VBScript>
        XMLDoc.async = false
        XMLDoc.load("schedule.xml")
        XSLDoc.async = false
        XSLDoc.load("expanded.xsl")
        result = XMLDoc.documentElement.transformNode(XSLDoc.documentElement)
        insertHTML.innerHTML = result
        
        Sub details_onclick()
          If details.value = "Hide Details" Then
            details.value = "Show Details"
            XSLDoc.load("collapsed.xsl")
          Else 
            details.value = "Hide Details"
            XSLDoc.load("expanded.xsl")
          End If
          insertHTML.innerHTML = XMLDoc.documentElement.transformNode(XSLDoc.documentElement)
        End Sub
      </SCRIPT>
      <INPUT TYPE=BUTTON NAME="details" VALUE="Hide Details">
    </BODY>
  </HTML>
<%
Else
%>
  <HTML>
    <BODY>
    <SCRIPT LANGUAGE=VBScript> 
    Sub details_onclick()
      If details.value = "Hide Details" Then
        window.location.replace("multipleViews.asp?details='hide'")
      Else window.location.replace("MultipleViews.asp?details='show'")
      End If
    End Sub
    </SCRIPT>
  <%
  display = Request.QueryString("details")
  Set XMLDoc = Server.CreateObject("Microsoft.XMLDOM")
  Set XSLDoc = Server.CreateObject("Microsoft.XMLDOM")
  XMLDoc.async = false
  XMLDoc.load(Server.MapPath("schedule.xml"))
  XSLDoc.async = false
  If display = "'show'" Then
    XSLDoc.load(Server.MapPath("expanded.xsl"))
    response.write(XMLDoc.documentElement.transformNode(XSLDoc.documentElement))
  %>
    <INPUT TYPE=BUTTON NAME="details" VALUE="Hide Details">
  <%
  Else
    XSLDoc.load(Server.MapPath("collapsed.xsl"))
    response.write(XMLDoc.documentElement.transformNode(XSLDoc.documentElement))
  %>
    <INPUT TYPE=BUTTON NAME="details" VALUE="Show Details">
  <%
  End If
  %>
    </BODY>
  </HTML>
<%
End IF
%>