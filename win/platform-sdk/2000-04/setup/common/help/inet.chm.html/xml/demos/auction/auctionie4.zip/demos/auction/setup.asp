<%@ LANGUAGE = VBScript %>

<%
'	Setup the admin table.
%>

<% 
	Set conn = Server.CreateObject("ADODB.Connection")
	conn.Open("data source=Auction;user id=auction;password=auction;")
	conn.Execute "DELETE FROM admin"
	conn.Close

	' Initialize the admin table.
	Set BidRS = Server.CreateObject("ADODB.RecordSet")
	connect = "data source=Auction;user id=auction;password=auction;"
	query = "admin"
	BidRS.CursorType = 2
	BidRS.LockType = 3			' read/write
	BidRS.Open query, connect
	Set Conn = Server.CreateObject("ADODB.Connection")
	Conn.Open "Auction","auction","auction"
	BidRS.AddNew
	BidRS("maxusers") = 10
	BidRS("numhits") = 0
	BidRS.Update
	BidRS.Close
%>
<RESULT>ok</RESULT>

