<% @LANGUAGE=VBScript%>
<%
  Set xmlCust = Server.CreateObject("Microsoft.XMLDOM")
  xmlCust.async=false
  xmlCust.load(Request)
  IF xmlCust.parseError.reason = "" Then
    xmlCust.save(Server.MapPath("customer.xml"))
    Response.contentType = "text/xml"
    Response.write("<result>Processed Successfully</result>")
  Else Response.write("<error/>")
  End If
%>