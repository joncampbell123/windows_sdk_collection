<xsl:stylesheet xmlns:xsl="http://www.w3.org/TR/WD-xsl">

  <xsl:template match="//">
    <xsl:apply-templates/>
  </xsl:template>
  <xsl:template match="//z:row">
  <Customer>
    <xsl:element name="CustomerID"><xsl:value-of select="@CustomerID"/></xsl:element>
    <xsl:element name="CompanyName"><xsl:value-of select="@CompanyName"/></xsl:element>
    <xsl:element name="ContactName"><xsl:value-of select="@ContactName"/></xsl:element>
    <xsl:element name="ContactTitle"><xsl:value-of select="@ContactTitle"/></xsl:element>
    <xsl:element name="Address"><xsl:value-of select="@Address"/></xsl:element>
    <xsl:element name="City"><xsl:value-of select="@City"/></xsl:element>
  </Customer>
  </xsl:template>

</xsl:stylesheet>