<%@ LANGUAGE = VBScript %>

<%
'	Reset the demo to its initial state by deleting all the bids.  After the bid
'	table is cleared out, one bid is created for each item.  This bid contains the
'	opening price for the item.
%>

<% 
	Set conn = Server.CreateObject("ADODB.Connection")
	conn.Open("data source=Auction;user id=auction;password=auction;")
	conn.Execute "DELETE FROM bids"
	conn.Close

	' Initialize the bids table with one bid for each item.
	Set BidRS = Server.CreateObject("ADODB.RecordSet")
	connect = "data source=Auction;user id=auction;password=auction;"
	query = "bids"
	BidRS.CursorType = 2
	BidRS.LockType = 3			' read/write
	BidRS.Open query, connect
	Set Conn = Server.CreateObject("ADODB.Connection")
	Conn.Open "Auction","auction","auction"
	Set ItemRS = Conn.Execute("select * from item")
	Do While Not ItemRS.EOF
		BidRS.AddNew
		BidRS("title") = CStr(ItemRS("Title"))
		BidRS("price") = ItemRS("Bid_price")
		BidRS("bidder") = CStr(ItemRS("Bid_bidder"))
		BidRS("time") = Time
		BidRS.Update
		ItemRS.MoveNext
	loop
	ItemRS.Close
	BidRS.Close

%>

