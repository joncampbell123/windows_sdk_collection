<patients>
  <xsl:for-each order-by="+ name" select="patient" xmlns:xsl="http://www.w3.org/TR/WD-xsl">
    <patient>
      <xsl:attribute name="patientID"><xsl:value-of select="@patientID"/></xsl:attribute>
      <name><xsl:value-of select="name"/></name>
      <address>
        <street><xsl:value-of select="address/street"/></street>
        <apt><xsl:value-of select="address/apt"/></apt>
        <city><xsl:value-of select="address/city"/></city>
        <state><xsl:value-of select="address/state"/></state>
        <zip><xsl:value-of select="address/zip"/></zip>
      </address>
      <birthdate><xsl:value-of select="birthdate"/></birthdate>
    </patient>
  </xsl:for-each>
</patients>

