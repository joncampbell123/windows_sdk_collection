<%@ LANGUAGE = VBScript %>

<%
' Process a click on the Update button.  A timestamp should be passed as a parameter
' and an updategram is sent containing changes since that timestamp.  Currently the
' changes only include bids, not changes to items.

timestamp = CLng(Request.QueryString("timestamp"))
if timestamp > 0 then %>
	<AUCTIONBLOCK>
<%
	latestTimestamp = 0

	Set Conn = Server.CreateObject("ADODB.Connection")
	Conn.Open "Auction","sa",""
	Set BidRS = Conn.Execute("select * from bids where Timestamp > " & timestamp & " ORDER BY Price DESC")
	Do While Not BidRS.EOF
	    BidTimestamp = CLng(BidRS("Timestamp"))
        title = CStr(BidRS("Title"))
		price = CStr(BidRS("Price"))
		if BidTimestamp > latestTimestamp then
			latestTimestamp = BidTimestamp
		end if
	%>
		<ITEM>
			<TITLE><%=title%></TITLE>
            <BIDS>
				<BID UPDATE-ACTION="INSERT">
					<PRICE><%=price %></PRICE>
					<TIME><%=BidRS("Time") %></TIME>
					<BIDDER><%=BidRS("Bidder")%></BIDDER>
					<TIMESTAMP><%=BidTimestamp%></TIMESTAMP>
				</BID>
			</BIDS>
			<TIMESTAMP UPDATE-ACTION="REPLACE"><%=latestTimestamp%></TIMESTAMP>
		</ITEM>
<%
	    BidRS.MoveNext
	loop
	BidRS.Close %>
</AUCTIONBLOCK>

<% end if %>



