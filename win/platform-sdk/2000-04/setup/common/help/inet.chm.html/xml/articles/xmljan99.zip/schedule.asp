<%@Language=VBScript%>
<%
client = Request.ServerVariables("HTTP_USER_AGENT")

version = Split(client,";",-1,1)
IF version(1) = " MSIE 5.0b2" Then%>
  <HTML>
    <BODY>
      <XML ID="XMLDoc"></XML>
      <XML ID="XSLDoc"></XML>
      <DIV ID="insertHTML"></DIV>
      <SCRIPT LANGUAGE=VBScript>
        XMLDoc.async = false
        XMLDoc.load("schedule.xml")
        XSLDoc.async = false
        XSLDoc.load("schedule.xsl")
        result = XMLDoc.documentElement.transformNode(XSLDoc.documentElement)
        insertHTML.innerHTML = result
      </SCRIPT>
    </BODY>
  </HTML>
<%
Else
  Set XMLDoc = Server.CreateObject("Microsoft.XMLDOM")
  Set XSLDoc = Server.CreateObject("Microsoft.XMLDOM")
  XMLDoc.async = false
  XMLDoc.load(Server.MapPath("schedule.xml"))
  XSLDoc.async = false
  XSLDoc.load(Server.MapPath("schedule.xsl"))
  response.write(XMLDoc.documentElement.transformNode(XSLDoc.documentElement))
End IF
%>