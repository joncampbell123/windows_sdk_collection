Setting up the demo:
1. Put all files but "process.asp" in the same directory.
2. Put "process.asp" on a server that can execute ASP files.
3. Add Northwind.mdb to your list of User Data Sources and name it "nwind".
4. Test.frm contains a Command_Click SUB in which the following call is made:
  xmlhttp.Open "POST", [url], False
Set the [url] parameter to the location of "process.asp".
5. After running "test.exe", view file created by browsing to the "customer.xml" file that exists in the same directory as "process.asp" 
 