<%@ LANGUAGE = VBScript %>

<%
'	Construct an XML description of the auction items from the data stored in
'	the SQL database.  This script is used when the auction page is first displayed
'	or when it is refreshed.
%>

<?xml version="1.0"?>

<AUCTIONBLOCK>
<%
timestamp = 0

Set Conn = Server.CreateObject("ADODB.Connection")
Conn.Open "Auction","sa",""
Set ItemRS = Conn.Execute("select * from item")
Do While Not ItemRS.EOF

	' Note: these variables are needed because (apparently) you can use a value
	' from the database only once.  So, we copy values we want to reuse to strings.
	Dim title 
	%>
	<ITEM>
	<%
		title = CStr(ItemRS("Title"))
	%>	<TITLE><%=title%></TITLE>
		<ARTIST><%=ItemRS("Artist")%></ARTIST>
		<DIMENSIONS><%=ItemRS("Dimensions")%></DIMENSIONS>
		<MATERIALS><%=ItemRS("Materials")%></MATERIALS>
		<YEAR><%=ItemRS("Year")%></YEAR>
		<DESCRIPTION><%=ItemRS("Description")%></DESCRIPTION>
		<PREVIEW-SMALL <%=ItemRS("Preview_small")%> alt="<%=title%>" ></PREVIEW-SMALL>
		<PREVIEW-LARGE <%=ItemRS("Preview_large")%> alt="<%=title%>"></PREVIEW-LARGE>
		<BIDS>
	<%
	Set BidRS = Conn.Execute("select * from bids where Title Like '" & title & "' ORDER BY Price DESC")
	count = 0
	Do While count < 6 and Not BidRS.EOF 
	%>		<BID>
				<PRICE><%=BidRS("Price") %></PRICE>
				<TIME><%=BidRS("Time") %></TIME>
				<BIDDER><%=BidRS("Bidder")%></BIDDER>
				<% 
					bidTimestamp = CLng(BidRS("Timestamp"))
					if bidTimestamp > timestamp then
						timestamp = bidTimestamp
					end if
				%><TIMESTAMP><%=bidTimestamp%></TIMESTAMP>
			</BID>
	<% 
		count = count + 1
		BidRS.MoveNext
	Loop

	if Not BidRS.EOF then	' additional bids available - get last one
		Set BidRS = Conn.Execute("select * from bids where Title Like '" & title & "' ORDER BY Price ASC")
		%>		<BID>
				<PRICE><%=BidRS("Price") %></PRICE>
				<TIME><%=BidRS("Time") %></TIME>
				<BIDDER><%=BidRS("Bidder")%></BIDDER>
				<TIMESTAMP><%=BidRS("Timestamp")%></TIMESTAMP>
			</BID>
	<% 
	end if
	%>
		</BIDS>
		<TIMESTAMP><%=timestamp%></TIMESTAMP>
	</ITEM>
<%
	ItemRS.MoveNext
Loop
%>
</AUCTIONBLOCK>

