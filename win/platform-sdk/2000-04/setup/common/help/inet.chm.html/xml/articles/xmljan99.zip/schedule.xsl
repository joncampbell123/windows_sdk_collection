<?xml version="1.0"?>
<HTML xmlns:xsl="http://www.w3.org/TR/WD-xsl">
  <BODY STYLE="font-family:Arial, helvetica, sans-serif; font-size:12pt;
        background-color:#EEEEEE">
    <DIV STYLE="font-weight:bold;font-size=16pt">
      <xsl:value-of select="@date"/>
    </DIV>
    <xsl:for-each select="meeting" order-by="+ start-time">
      <DIV STYLE="background-color:#8B0000; color:#FFFFFF; padding:4px">
        <SPAN STYLE="font-weight:bold; color:white"><xsl:value-of select="start-time"/>
        - <xsl:value-of select="end-time"/>   Subject: <xsl:value-of select="subject"/></SPAN>
      </DIV>
      <DIV STYLE="font-weight:bold">LOCATION: <xsl:value-of select="location"/></DIV>
      <DIV STYLE="font-weight:bold">ATTENDEES: </DIV>
        <xsl:for-each select="./attendees/attendee">
          <DIV STYLE="text-indent:1cm"><xsl:value-of select="name"/></DIV>
        </xsl:for-each>
    </xsl:for-each>
  </BODY>
</HTML>