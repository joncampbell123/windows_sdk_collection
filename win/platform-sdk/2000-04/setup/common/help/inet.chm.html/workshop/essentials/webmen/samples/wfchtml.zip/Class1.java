/*
  * Sample produced by the Web Men
  * November 1998 column
  * webmen@microsoft.com
*/
#define HTMLPERSON
#undef MOREABSTRACT

import com.ms.wfc.html.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;


public class Class1 extends DhDocument 
{
	DhForm divAddition;
#if HTMLPERSON
	DhRawHTML newImage;
#elif MOREABSTRACT
	DhImage newImage;
#endif

	public Class1() 
	{
		// Required for Visual J++ Form Designer support
		initForm();		

		// TODO: Add any constructor code after initForm call
	}

	/**
	 * Class1 overrides dispose so it can clean up the
	 * component list.
	 */
	public void dispose() 
	{
		super.dispose();
	}

	/**
	 * Add all your initialization code here. The code here can add elements,
	 * set bindings to existing elements, set new properties and event handlers
	 * on elements. The underlying HTML document is not available at this stage,
	 * so any calls that rely on the document being present should be added to
	 * the onDocumentLoad() function below (client-only).
	 */
	private void initForm() 
	{
	}
	
	/**
	 * Client-side only.
	 * 
	 * Here, the underlying HTML document is available for inspection. Add any code 
	 * that wants to get properties of elements or inspect the document in any other way.
	 */
	protected void onDocumentLoad(Object sender, Event e) 
	{
	#if HTMLPERSON
		// HTML text to be added to our <DIV> tag
		String str = "<img src=webmen-a.gif width=79 height=79 style='position:relative; top:20;left:25'>";
		
		// create the raw HTML to be added
		newImage = new DhRawHTML();
		newImage.setHTML (str);
	#elif MOREABSTRACT
		// create a new bitmap file to display
		newImage = new DhImage();
		newImage.setURL("webmen-a.gif");
		
		// set size, position and location
		newImage.setSize(79,79);
		newImage.setPosRelative();
		newImage.setLocation(25,20);
		// we now have the equivalent of our raw HTML from the code above
	#endif

		// first find the element we are looking for and cast the element to DhForm
		// casting it allows us to use it as a DIV element
		divAddition = (DhForm) findElement("mydiv");
		
		// WFC's equivalent to insertAdjacentHTML() method
		divAddition.add(newImage,null, DhInsertOptions.BEGINNING);
	}
}
