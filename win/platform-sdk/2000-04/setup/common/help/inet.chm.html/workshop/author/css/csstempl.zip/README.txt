
  CSS TEMPLATE SAMPLE 
  FOR INTERNET EXPLORER 4.0 PREVIEW 2
  (C) 1997 Microsoft Corporation

  ---------------------------------

  To run the sample:
  
  (1) Unzip this archive to a folder. 

  (2) Double-click on cssTempl.htm in the folder.

  ---------------------------------



