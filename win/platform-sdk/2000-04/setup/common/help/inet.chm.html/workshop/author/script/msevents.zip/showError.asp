<%@ LANGUAGE=VBScript %>
<%response.expires = 0%>
<%	' *******************************************************************
	' *	FILENAME	: showError.asp										*
	' * Purpose		: This page gets called from trapError.asp. It tells*
	' *               the user something went wrong, and auto retries   *
	' *               the page request. It also allows the user to retry*
	' *               the page request manually. Note how the users's   *
	' *				  experience is enhanced for Internet Explorer 4+   *	
	' ******************************************************************* %>


<%	'	*****************************************************************
	'	*	Error constants												*
	'	*****************************************************************
	Const SQL_TIMEOUT				= 1				'Generic sql timeout.  Use SQL_TIMEOUT_REGISTRATION for registration issues
	Const MSDATA_OBJECTS			= 2				'Indicates that the data objects are currently down.
	Const SQL_TIMEOUT_REGISTRATION	= 3				'SQL timeout during the middle of a registration process.  This will also
													'show the user where he can use alternative means of registration and will
													'provide a link to that page.
	Const SQL_OTHER					= 3704
	Const INCORRECT_SYNTAX			= -2147217900	'Incorrect syntax near.. this is an error usually caused by passing a bad
%>


<%	Dim ShowID						' INTEGER	-	Integer value of the SHOWID passed as "s" in the URL
                                    '               This is the event code being queried and is useful for
                                    '               determining what went wrong. For example, if registration
                                    '               failed because an event filled while the customer was
                                    '               registering (yes this really happens) a support engineer
                                    '               can determine that based upon the time stamp and event code.
	Dim ErrorType					' INTEGER	-	Signifies the error type and what to display as a result
	Dim ErrMessage					' STRING	-	Contains the error message displayed to the user.
	Dim FromLOC						' STRING    -   The original page request that produced an error (it's used to retry the request)
	Dim DoCountdown					' BOOLEAN	-	If set to true, then the page will refresh itself
%>


<%	'	*****************************************************************
	'	*	Assignment of variables										*
	'	*****************************************************************
	ShowID = Request.QueryString("s")
	
	' the VBScript error number  reported to trapError.asp
	ErrorType = clng(Request.QueryString("errorNum"))
	
	' this is used for the retry operations, it is the url for the original
	' page request which produced an error. As you can see, this is almost
	' always some sort of database access error, ususally due to high traffic
	FromLOC = Request.QueryString("LOC")
	DoCountdown = FALSE
%>


<%
  Select Case ErrorType
		Case SQL_TIMEOUT, SQL_OTHER
				ErrMessage = "We are sorry, but we are experiencing an unusually high volume of traffic."
				DoCountdown = TRUE
		Case MSDATA_OBJECTS
				ErrMessage = "We are sorry, but we are experiencing temporary problems with our web site."
		Case SQL_TIMEOUT_REGISTRATION
				ErrMessage = "Due to heavy system usage, your registration request cannot be completed at this time.  In order to complete your registration, select from one of the options listed."
				DoCountdown = TRUE
		Case else
				ErrMessage = "We are sorry, but we are experiencing temporary problems with our web site."
	End Select
%>

<%
' sniff for IE4 or IE5 (everybody else gets the downlevel page)
' For more information on sniffing the browser, see:
' http://www.microsoft.com/workshop/c-frame.htm#/workshop/management/sniffing.asp
    Dim ua
    ua = Request.ServerVariables("HTTP_USER_AGENT")
    MSIE4 = false
    If Instr(ua, "MSIE 5.") or Instr(ua, "MSIE 4.") Then
        MSIE4 = true
    End if
%>

<html>
<head>
<meta name="VI60_defaultClientScript" content="VBScript">
<% if MSIE4 then %>
	<link rel="stylesheet" href="main.css">
<% end if %>
<meta NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<% if DoCountdown then %>
	<meta HTTP-EQUIV="Refresh" CONTENT="30; URL=<%=FromLOC%>">
<% end if %>
<title>Microsoft Events - Standby</title>
</head>
<body id="MyBody" bgcolor="#ffffff" marginheight="0" marginwidth="0" leftMargin="0" topMargin="0" alink="#003399" vlink="#003399" link="#003399">


<%	'	*****************************************************************
	'	*	We only want to include this client-side script for  MSIE4.	*
	'	*	MSIE3 will generate syntax errors on unknown objects, etc.  *
	'	*****************************************************************%>
		<% if MSIE4 then %>
			<script LANGUAGE="VBscript">
			<!--
			<% if DoCountdown then %>
				Dim BeginCountDown

				BeginCountDown = 30
			
			    ' run this code in the onload event on the client
				Sub Window_Onload()
					trMenu.style.height = (MyBody.clientHeight - 130)
					IntervalID = setinterval("CountDown", 1000, VBScript)
				end sub
				
				Sub CountDown()
					BeginCountDown = BeginCountDown -1
					if BeginCountDown < 1 then 
						HowMuchTime.innerText =  "now. Please standby...."
					else
						HowMuchTime.innerText =  "in " & (BeginCountDown) & " seconds."
					end if
				End sub
			<% else %>
			
				Sub Window_Onload()
					trMenu.style.height = (MyBody.clientHeight - 130)
				end sub
			<% end if %>			
			-->
			</script>
		<% end if %>


<%	'	*****************************************************************
	'	*	Include files for mouseover functions and ms.com toolbar	*
	'	*****************************************************************
	' Note - I removed the mouseover and toolbar includes because 
	'        they are not super relevant to the sample)%>

	<table width="100%" cellpadding="0" cellspacing="0" border="0" leftmargin="0" topmargin="0">
		<tr>
			<td valign="top" bgcolor="#6699cc" style="border-right:solid 0.1em #003399;">

			<%	'	*****************************************************************
				'	*	Featured events cell with graphic and link					*
				'	*****************************************************************%>
				<img src="images/logo2.gif" alt="Microsoft Events" WIDTH="135" HEIGHT="81">
			</td>			
			<td valign="top" width="100%">
							<table border="0" cellpadding="10" cellspacing="0">
								<tr>
									<td nowrap>
									<%	'	*****************************************************************
										'	*	Main logo cell												*
										'	*****************************************************************%>
										<img SRC="images/msevents_logo.gif" WIDTH="138" HEIGHT="48">
									</td>
								</tr>
							</table>
			</td>
		</tr>
		<tr>
			<td vAlign="top" bgcolor="#6699cc" style="border-right:solid 0.1em #003399;">
			
			<%	'	*****************************************************************
				'	*	Contents image cell to line up with the ban_* image			*
				'	*****************************************************************%>
				<% if MSIE4 then %>
						<div CLASS="b13" STYLE="height:25;width:135;
							background:#FFFF9F;
							text-align: center;
							color:red;
							border: solid 0.1em #003399;
							border-left: none;">
							<div STYLE="margin-top:3;">contents</div>
						</div>
				<% else %>
						<img SRC="images/contents.gif" WIDTH="136" HEIGHT="25">
				<% end if %>
			
			</td>
			
			<td vAlign="top">

			<%	'	*****************************************************************
				'	*	Ban_* image cell to line up with the Contents image			*
				'	*****************************************************************%>
				<% if MSIE4 then %>
						<img style="position:absolute;top:75;left:150;" SRC="images/ban_normal.gif" WIDTH="328" HEIGHT="21">
						<span id="titletext" class="b13" style="margin-left:18;padding-top:3;position:absolute;top:75;width:250;">
							 SiteBuilder Network Sample Page
						</span><br>

						<img style="position:absolute;top:105;left:150;" SRC="images/ban_normal.gif" WIDTH="328" HEIGHT="21">
						<span id="titletext" class="b13" style="margin-left:18;padding-top:3;position:absolute;top:105;width:250;">
							 Please standby
						</span>
				<% else %>
				        <P>&nbsp;&nbsp;<b>SiteBuilder Network Sample Page</b><br><br>
						&nbsp;&nbsp;<img SRC="images/ban_bringing_people.gif" WIDTH="330" HEIGHT="22">
				<% end if %>
			</td>
		</tr>
		<tr id="trMenu">

			<td style="border-right:solid 0.1em #003399;" vAlign="top" bgcolor="#6699cc">
            <% if MSIE4 then %>

        	<br>
	        <table cellpadding="0" cellspacing="0" border="0">
		        <tr>
			    <td valign="bottom" align=right>
					<fieldset style="width:125;padding-left:5;padding-right:5;padding-bottom:10;margin-left:5;">
						<legend style="color:white;margin-bottom:5;">
			    			<B>Events</b>									
						</legend>
    					<div style="margin-left:5;" class="smallmenu" align=left>
							<%=ErrMessage%>
	    				</div>
					</fieldset>
				<br>
		    	</td>
		        </tr>
	        </table>
	        
            <% else%>
            
           	<table cellpadding="5" cellspacing="0" border="0" width=100%>
           		<tr>
       			<td width=1>
				<font size=2 color="#FFFFFF" face="Verdana,Arial,Helvetica">
				<B>Microsoft Events</b>									
				</font>
				<table width=100% border=0>
					<tr>
					<td>
					<Font size=1 face="Verdana,Arial,Helvetica">
					<br>
					<%=ErrMessage%>
					</font>
					</td>
					</tr>
				</table>
    			</td>
	        	</tr>
	        </table>				
				
            <% End If 'MSIE4%>

           	</td>
   	    	<td valign="top">

		<%	'	*****************************************************************
			'	*	build the part of the error page specific to the error type received
			'	*****************************************************************%>
			<p>&nbsp;<br>
			<table cellpadding="15" cellspacing="0" border="0">
				<tr>
					<td valign="top">
                    <font face="Verdana, Arial, Helvetica" size=2>
					<%=ErrMessage%>

<%  Select Case ErrorType
		CASE SQL_TIMEOUT_REGISTRATION%>
			<ol>
				<li>
					<% if DoCountdown then %>
						<% if MSIE4 then %>
							Please wait.  We will be continuing your registration <font color="#FF0000"><b><span id="HowMuchTime">in 30 seconds.</span></b></font>
						<% Else %>
							Please wait.  We will be continuing your registration in 30 seconds.
						<% End if %>
					<% End if %>
				</li>
				<li>
					<a href="<%=FromLOC%>">Try the registration process again.</a>
				</li>
				<li>
		        <%	'	*****************************************************************
		        	'	* Note, the actual Events site uses the showID variable to send the
		        	'   * user back to the page for the event they were registering for
					'	*****************************************************************%>
					<a href="demoError.asp">Return to the homepage</a> for this event.  If there are alternative means of registering for this event (phone, fax, email) that
					information is shown on the left hand side of the page as indicated in the sample image below.
					<br><br>
					<img SRC="images/reg_alt_sample.gif" alt="Sample of where to find alternative registration methods" WIDTH="473" HEIGHT="370">
				</li>
			</ol>
			<p>
				<b>NOTE:</b> If you have already been to this page one or more times
				while attempting to register for this event, please refer to option 3
				for information on alternative registration methods.
		<% Case MSDATA_OBJECTS %>
			<ol>
				<li>
					<a href="<%=FromLOC%>">Try the registration process again.</a>
				</li>
				<li>
		        <%	'	*****************************************************************
		        	'	* Note, the actual Events site uses the showID variable to send the
		        	'   * user back to the page for the event they were registering for
					'	*****************************************************************%>
					<a href="demoError.asp">Return to the homepage</a> for this event.  If there are alternative means of registering for this event (phone, fax, email) that
					information is shown on the left hand side of the page as indicated in the sample image below.
					<br><br>
					<img SRC="images/reg_alt_sample.gif" alt="Sample of where to find alternative registration methods" WIDTH="473" HEIGHT="370">
				</li>
			</ol>
			<p>
				<b>NOTE:</b> If you have already been to this page one or more times
				while attempting to register for this event, please refer to option 2
				for information on alternative registration methods.
		<% CASE SQL_TIMEOUT, SQL_OTHER %>
			<ol>
				<li>
					<% if DoCountdown then %>
						<% if MSIE4 then %>
							We will attempt your request again <font color="#FF0000"><b><span id="HowMuchTime">in 30 seconds.</span></b></font>
						<% Else %>
							Wait 30 seconds, this page will attempt to resume on its own.
						<% End if %>
					<% End if %>
				</li>
				<li>
					<a href="<%=FromLOC%>">Try the page again.</a>
				</li>
			</ol>
<%End Select %>		

					<% if not(MSIE4) then %>
						<p>&nbsp;<p>&nbsp;<p>&nbsp;<p>&nbsp;<p>&nbsp;<p>&nbsp;<p>
					<% end if %>

					</td>
				</tr>
			</table>

		<%	'	*****************************************************************
			'	*	END main contents											*
			'	*****************************************************************%>
			</td>
		</tr>
	</table>
</body>
</html>
