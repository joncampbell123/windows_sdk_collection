<!--TOOLBAR_START-->
<!--TOOLBAR_EXEMPT-->
<!--TOOLBAR_END-->
<%
' this is asp script that runs on the server when the page is requested
Dim SvrVarCollection
Set SvrVarCollection = Request.ServerVariables
Dim ua, os
Dim IE4RelOrNewer, IE5, IE4, IE3, IE302, AnyIE, Netscape3, Netscape4, AnyNetscape, BetaVer, IE4Release
Dim Win95, Win98, WinNT, AnyMac, PPC, Mac68K, Unix
Dim SC1, SC2, MB, MP

''''''''''''''''''''
' Server Variables '
''''''''''''''''''''

ua  = SvrVarCollection("HTTP_USER_AGENT")
os  = SvrVarCollection("HTTP_UA_OS")


'''''''''''''''''''''''''
' Determine the Browser '
'''''''''''''''''''''''''

AnyIE = False
IE5 = False
IE4 = False
IE3 = False
IE302 = False
AnyNetscape = False
Netscape4 = False
Netscape3 = False

If Instr(ua, "MSIE") Then
   AnyIE = True
   If Instr(ua, "MSIE 5.") Then
      IE5 = True
   ElseIf Instr(ua, "MSIE 4.") Then
      IE4 = True
   ElseIf Instr(ua, "MSIE 3.") Then
      IE3 = True
      If Instr(ua, "MSIE 3.02") Then
         IE302 = True
      End If
   End If
ElseIf Instr(ua, "Mozilla") And Instr(ua, "compatible") = 0 Then
   AnyNetscape = True
   If Instr(ua, "Mozilla/4") Then
      Netscape4 = True
   ElseIf Instr(ua, "Mozilla/3") Then
      Netscape3 = True
   End If
End If

'''''''''''''''''''''
' Determine if Beta '
'''''''''''''''''''''
BetaVer = False

SC1 = Instr(ua, ";")
SC2 = Instr(SC1 + 1, ua, ";")
MB = Instr(SC1 + 1, ua, "b")
MP = Instr(SC1 + 1, ua, "p")

If (AnyIE And ((MB > SC1 And MB < SC2) Or (MP > SC1 And MP < SC2))) Or (AnyNetscape And Instr(ua, "b") < SC1) Then
   BetaVer = True
End If

''''''''''''''''''''
' Determine the OS '
''''''''''''''''''''

Win95 = False
Win98 = False
WinNT = False
AnyMac = False
PPC = False
Mac68K = False
Unix = False
Win31_WinNT351 = False

If InStr(ua, "Windows 95") Or InStr(ua, "Win95") Then
   Win95 = True
ElseIf InStr(ua, "Windows 98") Or InStr(ua, "Win98") Then
   Win98 = True
ElseIf InStr(ua, "Windows 3.1") Or InStr(os, "Win16") Then
   Win31_WinNT351 = True
ElseIf InStr(ua, "NT") Or InStr(os, "NT") Then
   WinNT = True
ElseIf InStr(ua, "Mac") Then
   AnyMac = True
   If InStr(ua, "PowerPC") Or InStr(ua, "PPC") Then
      PPC = True
   ElseIf InStr(ua, "68000") Or InStr(ua, "68K") Then
      Mac68K = True
   End If
ElseIf InStr(ua, "X11") Then
   Unix = true
End If
%>

<HTML>
<HEAD>
<TITLE>Sitebuilder Network Workshop - Sniffing the browser and os in ASP</TITLE>
<SCRIPT LANGUAGE="JavaScript">
<!--
function fill_table()
{
<%if AnyIE then%>
    document.browserTable.Name.value = "Microsoft Internet Explorer";
<%elseif AnyNetscape then%>
    document.browserTable.Name.value = "Netscape Navigator";
<%else%>
    document.browserTable.Name.value = "Not supported";
<%end if%>

<%if IE5 then%>
   document.browserTable.Version.value = "5.x";
<%elseif IE4 Or Netscape4 then%>
   document.browserTable.Version.value = "4.x";
<%elseif IE3 Or Netscape3 then%>
    document.browserTable.Version.value = "3.x";
<%else%>
    document.browserTable.Version.value = "Not supported";
<%end if%>

<%if Win95 then%>
   document.browserTable.os.value = "Windows 95";
<%elseif Win98 then%>
   document.browserTable.os.value = "Windows 98";
<%elseif Win31_WinNT351 then%>
    document.browserTable.os.value = "Windows 3.1 or Windows 3.51";
<%elseif WinNT then%>
    document.browserTable.os.value = "Windows NT";
<%elseif AnyMac then%>
    document.browserTable.os.value = "Macintosh";
<%elseif Unix then%>
    document.browserTable.os.value = "Unix";
<%else%>
    document.browserTable.os.value = "Not supported";
<%end if%>
}
// -->
</SCRIPT>

</HEAD>

<BODY onload=fill_table()>

<FONT FACE="Verdana, Arial, Helvetica" SIZE=2>
<HR>
<H2 ALIGN = "center">Sniffing the browser and OS using ASP</H2>
<BR>
<P>This page contains (server-side) script that was executed on the server before this HTML was sent to you!</P>

  <FORM NAME="browserTable">
    <TABLE BORDER=0>

      <TR><TD COLSPAN=2><HR></TD></TR>

      <TR><TH COLSPAN=2 ALIGN="LEFT"><FONT FACE="Verdana, Arial, Helvetica">
        Browser and operating system information:</TH></TR>

      <TR><TD><FONT FACE="Verdana, Arial, Helvetica" SIZE=2>
        <B>Name:</B> </TD>
        <TD> <INPUT TYPE="txt" NAME="Name" Size="30"></TD></TR>

      <TR><TD><FONT FACE="Verdana, Arial, Helvetica" SIZE=2>
        <B>Version:</B> </TD>
        <TD> <INPUT TYPE="txt" NAME="Version" Size="30"></TD></TR>

      <TR><TD><FONT FACE="Verdana, Arial, Helvetica" SIZE=2>
        <B>Operating System:</B> </TD>
        <TD> <INPUT TYPE="txt" NAME="os" Size="30"></TD></TR>

      <TR><TD COLSPAN=2><HR></TD></TR>

    </TABLE>
  </FORM>

<HR>
</FONT>
</BODY>
</HTML>
