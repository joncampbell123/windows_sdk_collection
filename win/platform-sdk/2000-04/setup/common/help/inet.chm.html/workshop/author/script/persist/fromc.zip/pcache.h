/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.01.75 */
/* at Thu Dec 18 17:29:18 1997
 */
/* Compiler settings for pcache.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"
#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __pcache_h__
#define __pcache_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IPropertyCache_FWD_DEFINED__
#define __IPropertyCache_FWD_DEFINED__
typedef interface IPropertyCache IPropertyCache;
#endif 	/* __IPropertyCache_FWD_DEFINED__ */


#ifndef __IDiscardable_FWD_DEFINED__
#define __IDiscardable_FWD_DEFINED__
typedef interface IDiscardable IDiscardable;
#endif 	/* __IDiscardable_FWD_DEFINED__ */


#ifndef __PropertyCache_FWD_DEFINED__
#define __PropertyCache_FWD_DEFINED__

#ifdef __cplusplus
typedef class PropertyCache PropertyCache;
#else
typedef struct PropertyCache PropertyCache;
#endif /* __cplusplus */

#endif 	/* __PropertyCache_FWD_DEFINED__ */


#ifndef __Discardable_FWD_DEFINED__
#define __Discardable_FWD_DEFINED__

#ifdef __cplusplus
typedef class Discardable Discardable;
#else
typedef struct Discardable Discardable;
#endif /* __cplusplus */

#endif 	/* __Discardable_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IPropertyCache_INTERFACE_DEFINED__
#define __IPropertyCache_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IPropertyCache
 * at Thu Dec 18 17:29:18 1997
 * using MIDL 3.01.75
 ****************************************/
/* [unique][helpstring][dual][uuid][object] */ 



EXTERN_C const IID IID_IPropertyCache;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("68A12880-7584-11d1-A259-00C04FD97350")
    IPropertyCache : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CacheData( 
            /* [in] */ BSTR bstrPropName,
            /* [in] */ VARIANT vData,
            /* [optional][in] */ long lSecurityLevel) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RetrieveCachedData( 
            /* [in] */ BSTR bstrPropName,
            /* [retval][out] */ VARIANT __RPC_FAR *pvData) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPropertyCacheVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IPropertyCache __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IPropertyCache __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IPropertyCache __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IPropertyCache __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IPropertyCache __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IPropertyCache __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IPropertyCache __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CacheData )( 
            IPropertyCache __RPC_FAR * This,
            /* [in] */ BSTR bstrPropName,
            /* [in] */ VARIANT vData,
            /* [optional][in] */ long lSecurityLevel);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RetrieveCachedData )( 
            IPropertyCache __RPC_FAR * This,
            /* [in] */ BSTR bstrPropName,
            /* [retval][out] */ VARIANT __RPC_FAR *pvData);
        
        END_INTERFACE
    } IPropertyCacheVtbl;

    interface IPropertyCache
    {
        CONST_VTBL struct IPropertyCacheVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPropertyCache_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPropertyCache_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPropertyCache_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPropertyCache_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPropertyCache_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPropertyCache_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPropertyCache_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPropertyCache_CacheData(This,bstrPropName,vData,lSecurityLevel)	\
    (This)->lpVtbl -> CacheData(This,bstrPropName,vData,lSecurityLevel)

#define IPropertyCache_RetrieveCachedData(This,bstrPropName,pvData)	\
    (This)->lpVtbl -> RetrieveCachedData(This,bstrPropName,pvData)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPropertyCache_CacheData_Proxy( 
    IPropertyCache __RPC_FAR * This,
    /* [in] */ BSTR bstrPropName,
    /* [in] */ VARIANT vData,
    /* [optional][in] */ long lSecurityLevel);


void __RPC_STUB IPropertyCache_CacheData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPropertyCache_RetrieveCachedData_Proxy( 
    IPropertyCache __RPC_FAR * This,
    /* [in] */ BSTR bstrPropName,
    /* [retval][out] */ VARIANT __RPC_FAR *pvData);


void __RPC_STUB IPropertyCache_RetrieveCachedData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPropertyCache_INTERFACE_DEFINED__ */


#ifndef __IDiscardable_INTERFACE_DEFINED__
#define __IDiscardable_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IDiscardable
 * at Thu Dec 18 17:29:18 1997
 * using MIDL 3.01.75
 ****************************************/
/* [unique][helpstring][dual][uuid][object] */ 



EXTERN_C const IID IID_IDiscardable;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("68A12881-7584-11d1-A259-00C04FD97350")
    IDiscardable : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_data( 
            /* [retval][out] */ VARIANT __RPC_FAR *pvData) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_data( 
            /* [in] */ VARIANT vData) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_site( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstrSite) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_site( 
            /* [in] */ BSTR bstrSite) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDiscardableVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDiscardable __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDiscardable __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDiscardable __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IDiscardable __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IDiscardable __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IDiscardable __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IDiscardable __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_data )( 
            IDiscardable __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pvData);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_data )( 
            IDiscardable __RPC_FAR * This,
            /* [in] */ VARIANT vData);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_site )( 
            IDiscardable __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrSite);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_site )( 
            IDiscardable __RPC_FAR * This,
            /* [in] */ BSTR bstrSite);
        
        END_INTERFACE
    } IDiscardableVtbl;

    interface IDiscardable
    {
        CONST_VTBL struct IDiscardableVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDiscardable_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDiscardable_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDiscardable_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDiscardable_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDiscardable_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDiscardable_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDiscardable_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDiscardable_get_data(This,pvData)	\
    (This)->lpVtbl -> get_data(This,pvData)

#define IDiscardable_put_data(This,vData)	\
    (This)->lpVtbl -> put_data(This,vData)

#define IDiscardable_get_site(This,pbstrSite)	\
    (This)->lpVtbl -> get_site(This,pbstrSite)

#define IDiscardable_put_site(This,bstrSite)	\
    (This)->lpVtbl -> put_site(This,bstrSite)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDiscardable_get_data_Proxy( 
    IDiscardable __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pvData);


void __RPC_STUB IDiscardable_get_data_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDiscardable_put_data_Proxy( 
    IDiscardable __RPC_FAR * This,
    /* [in] */ VARIANT vData);


void __RPC_STUB IDiscardable_put_data_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDiscardable_get_site_Proxy( 
    IDiscardable __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrSite);


void __RPC_STUB IDiscardable_get_site_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDiscardable_put_site_Proxy( 
    IDiscardable __RPC_FAR * This,
    /* [in] */ BSTR bstrSite);


void __RPC_STUB IDiscardable_put_site_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDiscardable_INTERFACE_DEFINED__ */



#ifndef __PCACHELib_LIBRARY_DEFINED__
#define __PCACHELib_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: PCACHELib
 * at Thu Dec 18 17:29:18 1997
 * using MIDL 3.01.75
 ****************************************/
/* [helpstring][version][uuid] */ 



EXTERN_C const IID LIBID_PCACHELib;

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_PropertyCache;

class DECLSPEC_UUID("68A12883-7584-11d1-A259-00C04FD97350")
PropertyCache;
#endif

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_Discardable;

class DECLSPEC_UUID("68A12884-7584-11d1-A259-00C04FD97350")
Discardable;
#endif
#endif /* __PCACHELib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
