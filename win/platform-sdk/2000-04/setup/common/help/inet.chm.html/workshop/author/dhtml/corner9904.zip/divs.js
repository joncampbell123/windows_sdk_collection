
	/* DIVS.JS */
	
	function GetChildElem(eSrc,sTagName)
	{
		var cKids = document.all;
		for (var i=eSrc.sourceIndex;i<cKids.length;i++)
		{
			if (sTagName == cKids[i].tagName) return cKids[i];
		}
		return false;
	}
	
	function document.onclick()
	{
		var eSrc = window.event.srcElement;
		if ("clsHasKids" == eSrc.className && (eChild = GetChildElem(eSrc,"SPAN")))
		{
			eChild.style.display = ("block" == eChild.style.display ? "none" : "block");
		}
	}

	function ShowAll(sTagName)
	{
		var cElems = document.all.tags(sTagName);
		var iNumElems = cElems.length;
		for (var i=0;i<iNumElems;i++) cElems[i].style.display = "block";
	}
	
	function HideAll(sTagName)
	{
		var cElems = document.all.tags(sTagName);
		var iNumElems = cElems.length;
		for (var i=0;i<iNumElems;i++) cElems[i].style.display = "none";
	}
