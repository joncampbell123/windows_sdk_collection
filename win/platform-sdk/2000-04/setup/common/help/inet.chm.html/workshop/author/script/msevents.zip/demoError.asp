<%@ Language=VBScript %>
<% response.buffer = True %>
<%	' *******************************************************************
	' *	FILENAME	: demoError.asp                                     *
	' * Purpose		: This page demonstrates how to use the             *
	' *               trapError.asp and showError.asp pages             *
	' *******************************************************************%>
<%
' include IE4/5 stylesheet if appropriate
    Dim ua
    ua = Request.ServerVariables("HTTP_USER_AGENT")
    MSIE4 = false
    If Instr(ua, "MSIE 5.") or Instr(ua, "MSIE 4.") Then
        MSIE4 = true
    End if
%>
<HTML>
<HEAD>
<% if MSIE4 then %>
   	<link rel="stylesheet" href="sbnie4.css">
<% end if %>
</HEAD>
<BODY>
<%	'	*****************************************************************
	'	* Include trapError.asp to handle the script errors on this page*
	'	*****************************************************************%>
	<!--#include file = "trapError.asp"-->
<%
Dim ErrorNumber			' INT			Error Number passed through URL
%>

<%
ErrorNumber = Request.QueryString("errornum")
%>
<H1>Microsoft Events Site Error-Trapping Sample - Demo Page 
</H1>
<br>
<p>This page demonstrates the <A 
href="msevents.htm">Microsoft Events Site Error-Trapping Sample</A> for 
trapping run-time scripting errors. It serves the double-duty of showing you 
their error pages and demo'ing how to use their sample code.
<p><A href="msevents.zip">Download 
the files used for this sample</A>.</p>
<p>If you enter a run-time script error number in the editbox 
below and click the &quot;Submit Error&quot; button, this page will call the 
VBScript <STRONG>Err.Raise</STRONG> function with your 
error code. That will generate a real run-time script error as if it had 
actually occurred in the process of executing a VBScript script statement. As 
you can see when you view the source code for this page (it's in the above 
download), all we had to do to make this work was include the trapError.asp file 
like this: <PRE>&lt;%' ***************************************************************** 
<BR>&nbsp; ' * Include trapError.asp to handle the script errors on this page*
  ' *****************************************************************%&gt;
<BR>&lt;!--#include file = &quot;trapError.asp&quot; --&gt;</PRE>
<p>
<p>Refer to <A href="Script Errors.htm">Microsoft Script Engine Error Codes</A> if you'd like to review the list 
of run-time script error codes. The sample error-handler procedure in 
trapError.asp filters all possible run-time errors into one of three error pages 
that are presented to users when that error occurs. You can also just enter '1', 
'2', or '3' (without the ' characters) in the editbox to skip the filtering code 
and just show the error pages.</p>
<p>Please enter the run-time script error number you would 
like generate:</p>
<form action="demoError.asp" method="get" id=form1 name=form1>
<input name="errornum" >
<p>&nbsp;<input type=submit value="Submit Error"></form>
<%
if ErrorNumber <> 0 then
    On Error Resume Next
    
    ' Simulate the indicated error number. Obviously, you don't actually include this
    ' statement in your real code, you just need to do the subsequent conditional check
    ' and call the trapError subroutine as indicated
	Err.Raise ErrorNumber

    ' Invoke the error handler if there has been an error
    '   - do this after every line of code where a run-time error could occur.
    '   - alternatively, you  may determine that just doing this after the last line of
    '   code on a given page works fine -- since Err.Number will never be reset to '0',
    '   the error handler will be passed the last error that occurred.
	If Err.Number <> 0 Then
	    ' pass the original URL that produced the error, along with the query string to retry
		' trapError server.URLEncode(Request.ServerVariables("URL") &"?" & Request.ServerVariables("QUERY_STRING")), Err.Number, Err.Description
		
		' return to this demo page without an ?errornum= query string:
		trapError server.URLEncode(Request.ServerVariables("URL")), Err.Number, Err.Description
	End If
End If
%>
</BODY>
</HTML>
