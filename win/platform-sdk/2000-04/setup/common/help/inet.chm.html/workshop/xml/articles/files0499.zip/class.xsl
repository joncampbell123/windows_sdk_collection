<xsl:stylesheet xmlns:xsl="http://www.w3.org/TR/WD-xsl">
  <xsl:template match="//">
  <xsl:copy>
    <xsl:attribute name="code"><xsl:value-of select="@code"/></xsl:attribute>
    <xsl:attribute name="title"><xsl:value-of select="@title"/></xsl:attribute>
    <xsl:attribute name="units"><xsl:value-of select="@units"/></xsl:attribute>
    <xsl:attribute name="taughtBy"><xsl:value-of select="@taughtBy"/></xsl:attribute>
    <xsl:attribute name="attendedBy"><xsl:value-of select="@attendedBy"/></xsl:attribute>
    <xsl:attribute name="xmlns">x-schema:classSchema.xml</xsl:attribute>
  <xsl:element name="teachers">
  <xsl:for-each select="id(@taughtBy)">
    <xsl:copy>
       <xsl:attribute name="id"><xsl:value-of select="@id"/></xsl:attribute>
       <xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
       <xsl:attribute name="position"><xsl:value-of select="@position"/></xsl:attribute>
    </xsl:copy>
  </xsl:for-each>
  </xsl:element>
  <xsl:element name="students">
  <xsl:for-each select="id(@attendedBy)">
    <xsl:copy>
       <xsl:attribute name="id"><xsl:value-of select="@id"/></xsl:attribute>
       <xsl:attribute name="name"><xsl:value-of select="@name"/></xsl:attribute>
       <xsl:attribute name="year"><xsl:value-of select="@year"/></xsl:attribute>
       <xsl:attribute name="status"><xsl:value-of select="@status"/></xsl:attribute>
    </xsl:copy>
  </xsl:for-each>
  </xsl:element>
  </xsl:copy>
  </xsl:template>
</xsl:stylesheet>