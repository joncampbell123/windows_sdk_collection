<?XML version="1.0"?>

<CHANNEL 
  HREF	= "mctp://www.yourserver.com/CurrentNews/CurrentNews.cdf" 
  BASE	= "http://www.yourserver.com/CurrentNews/" 
  ID	= "CurrentNews"
>
    <SELF HREF="http://www.yourserver.com/CurrentNews/CurrentNews.cdf"/>

    <TITLE>Current News Mobile Channel</TITLE>
    <ABSTRACT>News where and when you want it.</ABSTRACT>

    <LOGO STYLE="IMAGE" HREF="static/logonews.gif" ID="LOGO"/>
    <LOGO STYLE="ICON" HREF="static/icnews.gif" ID="LOGOIC"/>

	<!-- Subscription update interval -->
    <SCHEDULE><INTERVALTIME MIN="60"/></SCHEDULE>

	<!-- Scripts -->
    <ITEM HREF="main.mcs" ID="CS"><USAGE VALUE="None"/></ITEM>
	<ITEM HREF="articles.mcs" ID="CS_ARTS"><USAGE VALUE="None"/></ITEM>

	<!-- Images -->
    <ITEM HREF="static/news_home01.gif" ID="HEADER"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/dot.gif" ID="DOT"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/news_ico.gif" ID="IC-NEWS"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/com_ico.gif" ID="IC-BUSINESS"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/wet_ico.gif" ID="IC-WEATHER"><USAGE VALUE="None"/></ITEM>

    <USAGE VALUE="MobileChannel"/>
    <CHANSCRIPT VALUE="CS"/>

    <CHANNEL ID="NEWS">
        <TITLE>News</TITLE>

		<USAGE VALUE="MobileChannel"/>
		<CHANSCRIPT VALUE="CS_ARTS"/>
		<ITEMFORMAT VALUE="Title,Summary;"/>

        <ITEM HREF="articles/media.mcd" ID="NEWS1"/>
        <ITEM HREF="articles/gatewaywins.mcd" ID="NEWS2"/>
        <ITEM HREF="articles/disabled.mcd" ID="NEWS3"/>
        <ITEM HREF="articles/snoop.mcd" ID="NEWS4"/>
        <ITEM HREF="articles/sonics.mcd" ID="NEWS5"/>
    </CHANNEL>

    <CHANNEL ID="BUSINESS">
		<TITLE>Business</TITLE>

		<USAGE VALUE="MobileChannel"/>
		<CHANSCRIPT VALUE="CS_ARTS"/>
		<ITEMFORMAT VALUE="Title,Summary;"/>

        <ITEM HREF="articles/boeing.mcd" ID="COM1"/>
        <ITEM HREF="articles/stocks.mcd" ID="COM2"/>
        <ITEM HREF="articles/business.mcd" ID="COM3"/>
        <ITEM HREF="articles/moodys.mcd" ID="COM4"/>
    </CHANNEL>

    <CHANNEL ID="WEATHER">
		<TITLE>Weather</TITLE>

		<USAGE VALUE="MobileChannel"/>
		<CHANSCRIPT VALUE="CS_ARTS"/>
		<ITEMFORMAT VALUE="Title,Summary;"/>

        <ITEM HREF="articles/florida.mcd" ID="WEA1"/>
        <ITEM HREF="articles/mexico.mcd" ID="WEA2"/>
    </CHANNEL>
</CHANNEL>
