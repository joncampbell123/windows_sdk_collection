<%	' *******************************************************************
	' *	FILENAME	: trapError.asp										*
	' * Purpose		: To be included by pages needing to handle VBScript*
	' *               runtime errors. See demoError.asp for example.    *
	' *******************************************************************
%>


<%
Sub trapError(docTitle, errNum, errDesc)
	On Error Resume Next%>
	<!--# file = "admin/GlobalVariables.asp"-->
<%	Dim errSev
	Dim errMsg
    Dim errLog
	Dim LogFile
	Dim FileSys
	Dim ShowID
	
	' ShowID enables the feature that allows the user to return to the Home page for
	' the event they were registering for when the error occurred. The ShowID value
	' can be used to request the correct event home page in the event it is no longer
	' cached on the user's machine (the Events site caches it for 10 minutes to reduce
	' the possibility that the high server traffic that probably caused the registration
	' error in the first place will also prevent the home page from getting reconstructed).
	' (note I've left this feature intact in case you find it useful - even though it is
	'  not used in this demo/sample)
	ShowID = Request.QueryString("s")

    ' clear the VBScript Err object's error number. This value is never cleared by 
    ' anybody but the developer. It is only ever set to an actual error number
    ' by the VBScript engine when an error occurs. Thus, you need to reset this
    ' yourself after you detect and deal with an error.
	Err.Clear 
	
	' open up access to the logfile
	' (note I have disabled opening, writing and close the logfile in this sample code)
    'set FileSys = CreateObject("Scripting.FileSystemObject")
	'set LogFile = FileSys.OpenTextFile (ErrorLogFullName, 8, True)
    
    ' generate information to be written to the error log on the error that was
    ' encountered. Here is where you could expand on the information you needed to
    ' figure out a given problem, as necessary.
    Select Case errNum

        ' The Events pages call this subroutine with errNum=1 for all SQL timeout errors
		Case 1 ' SQL TIMEOUT
					ErrLog = "Error: " & errdesc 
        ' The Events pages call this subroutine with errNum=2 when data objects are down
		Case 2 ' MSDATA objects error
					ErrLog = "MSCOM error - data objects are down"
        ' The Events pages call this subroutine with errNum=3 for SQL timeout errors during
        ' event registration (so the user can be taken back to the event home page if necessary)
		Case 3 ' SQL TIMEOUT during registration
					ErrLog = "Error during registration: " & errdesc
        Case 5 ' Invalid procedure call or argument
        Case 6 ' Overflow
        Case 7 ' Out of memory
        Case 9 ' Subscript out of range
        Case 10 ' This array is fixed or temporarily locked
        Case 11 ' Division by zero
        Case 13 ' Type mismatch
        Case 14 ' Out of string space
        Case 17 ' Can't perform requested operation
        Case 28 ' Out of stack space
        Case 35 ' Sub or Function not defined
        Case 48 ' Error in loading DLL
        Case 51 ' Internal error
        Case 52 ' Bad file name or number
        Case 53 ' File not found
        Case 54 ' Bad file mode
        Case 55 ' File already open
        Case 57 ' Device I/O error
        Case 58 ' File already exists
        Case 61 ' Disk full
        Case 62 ' Input past end of file
        Case 67 ' Too many files
        Case 68 ' Device unavailable
        Case 70 ' Permission denied
			ErrMsg = "You do not have correct permissions to do that"
			ErrLog = "I don't care about info on this one"
        Case 71 ' Disk not ready
        Case 74 ' Can't rename with different drive
        Case 75 ' Path/File access error
        Case 76 ' Path not found
        Case 91 ' Object variable not set
        Case 92 ' For loop not initialized
        Case 94 ' Invalid use of Null
        Case 322 ' Can't create necessary temporary file
        Case 424 ' Object required
        Case 429 ' ActiveX component can't create object
        Case 430 ' Class doesn't support Automation
        Case 432 ' File name or class name not found during Automation operation
        Case 438 ' Object doesn't support this property or method
        Case 440 ' Automation error
        Case 445 ' Object doesn't support this action
        Case 446 ' Object doesn't support named arguments
        Case 447 ' Object doesn't support current locale setting
        Case 448 ' Named argument not found
        Case 449 ' Argument not optional
        Case 450 ' Wrong number of arguments or invalid property assignment
        Case 451 ' Object not a collection
        Case 453 ' Specified DLL function not found
        Case 455 ' Code resource lock error
        Case 457 ' This key is already associated with an element of this collection
        Case 458 ' Variable uses an Automation type not supported in VBScript
        Case 500 ' Variable is undefined
        Case 501 ' Illegal assignment
        Case 502 ' Object not safe for scripting
        Case 503 ' Object not safe for initializing
        Case 504 ' Object not safe for creating
        Case 1001 ' Out of memory
        Case 1002 ' Syntax error
        Case 1003 ' Expected ':'
        Case 1005 ' Expected '('
        Case 1006 ' Expected ')'
        Case 1007 ' Expected ']'
        Case 1010 ' Expected identifier
        Case 1011 ' Expected '='
        Case 1012 ' Expected 'If'
        Case 1013 ' Expected 'To'
        Case 1014 ' Expected 'End'
        Case 1015 ' Expected 'Function'
        Case 1016 ' Expected 'Sub'
        Case 1017 ' Expected 'Then'
        Case 1018 ' Expected 'Wend'
        Case 1019 ' Expected 'Loop'
        Case 1020 ' Expected 'Next'
        Case 1021 ' Expected 'Case'
        Case 1022 ' Expected 'Select'
        Case 1023 ' Expected expression
        Case 1024 ' Expected statement
        Case 1025 ' Expected end of statement
        Case 1026 ' Expected integer constant
        Case 1027 ' Expected 'While' or 'Until'
        Case 1028 ' Expected 'While', 'Until' or end of statement
        Case 1030 ' Identifier too long
        Case 1031 ' Invalid number
        Case 1032 ' Invalid character
        Case 1033 ' Unterminated string constant
        Case 1034 ' Unterminated comment
        Case 1037 ' Invalid use of 'Me' keyword
        Case 1038 ' 'loop' without 'do'
        Case 1039 ' Invalid 'exit' statement
        Case 1040 ' Invalid 'for' loop control variable
        Case 1041 ' Name redefined
        Case 1042 ' Must be first statement on the line
        Case 1043 ' Cannot assign to non-ByVal argument
        Case 1044 ' Cannot use parens when calling a Sub
        Case 1045 ' Expected literal constant
        Case 1046 ' Expected 'In'
        Case 4096 ' Microsoft VBScript compilation error
        Case 4097 ' Microsoft VBScript runtime error
        Case -2147217900
			ErrLog = "Incorrect syntax near [SQL ERROR]:" & errdesc
		Case 3704 ' SQL Server not available or timed out	
			ErrLog = "SQL Server not available or timed out [SQL ERROR]:" & errdesc
        Case Else
    End Select
  
    ' generate a log entry for this error
    ' I have removed this code for the sample
    'if trim(errLog) = "" then
	'	LogFile.Writeline (Now & vbTab & errNum & vbTab & errDesc & vbTab & URLDecode(docTitle) & vbTab & Request.ServerVariables("HTTP_USER_AGENT"))
	'else
	'	logfile.writeline (Now & vbTab & errNum & vbTab & errLog & vbTab & URLDecode(docTitle) & vbTab & Request.ServerVariables("HTTP_USER_AGENT")) 
	'end if
	'LogFile.Close
	
	' display the user's error page
	Response.Redirect "showError.asp?errorNum=" & errNum & "&LOC=" & docTitle & "&s=" & ShowID
	
End Sub

' helper function used to un-encode a URL string
Function URLDecode(strToDecode)
	strIn = strToDecode
	strOut = ""			'The result string
	intPos = instr(strIn, "+")	'look for + and replace with a space
	Do while intPos
		strLeft = ""
		strRight = ""
		If intPos > 1 Then strLeft = Left(strIn, intPos -1)
		If intPos < Len(strIn) Then strRight = Mid(strIn, intPos +1)
		strIn = strLeft & " " & strRight
		intPos = Instr(strIn, "+") ' and then look for next one
		intLoop = intLoop + 1
	Loop
	intPos = Instr(strIn, "%")	'Look for ASCII coded chars
	Do While intPos
		If intPos > 1 Then strOut = strOut & Left(strIn, intPos -1)
		strOut = strOut & Chr(Cint("&H" & Mid(strIn, intPos + 1, 2)))
		If intPos > (Len(strIn) - 3) Then
			strIn = ""
		Else
			strIn = Mid(strIn, intPos + 3)
		End If
		intPos = Instr(strIn, "%")	'and then look for next one
	Loop
	URLDecode = strOut & strIn
End Function

%>
