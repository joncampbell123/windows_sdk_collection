<xsl:stylesheet xmlns:xsl="http://www.w3.org/TR/WD-xsl">

<xsl:script><![CDATA[

	function GetIndent(iIndent)
	{
		var sIndent = "";
		for (var i=2;i<iIndent;i++) sIndent += ".";
		return sIndent;
	}

]]></xsl:script>

<xsl:template match="/">
	<HTML>
	<HEAD>
	<TITLE>Divs <xsl:value-of select="TOPICLIST/@TYPE" /></TITLE>
	<LINK REL="stylesheet" TYPE="text/css" HREF="divs.css" />
	<SCRIPT TYPE="text/javascript" LANGUAGE="javascript" SRC="divs.js"></SCRIPT>
	</HEAD>
	<BODY>
	<BUTTON ONCLICK="ShowAll('SPAN')">Show All</BUTTON>
	<BUTTON ONCLICK="HideAll('SPAN')">Hide All</BUTTON>
	<H1>Divs <xsl:value-of select="TOPICLIST/@TYPE" /></H1>
	<xsl:apply-templates select="TOPICLIST/TOPICS" />
	<P><BUTTON ONCLICK="window.alert(document.body.innerHTML);">View HTML</BUTTON></P>
	</BODY>
	</HTML>
</xsl:template>

<xsl:template match="TOPICS">
	<DIV CLASS="clsHasKids"><xsl:eval>GetIndent(depth(this))</xsl:eval>
		<B CLASS="clsHasKids"><xsl:value-of select="@TYPE" /></B>
	</DIV>
	<SPAN CLASS="clsKids">
	<xsl:for-each select="TOPIC">
		<DIV>
			<xsl:eval>GetIndent(depth(this))</xsl:eval>
			<A TARGET="_new">
				<xsl:attribute name="HREF">http://msdn.microsoft.com<xsl:value-of select="URL" /></xsl:attribute>
				<xsl:value-of select="TITLE" />
			</A>
		</DIV>
	</xsl:for-each>
	<xsl:if test="TOPICS"><xsl:apply-templates /></xsl:if>
	</SPAN>
</xsl:template>

</xsl:stylesheet>