<?XML version="1.0"?>
<CHANNEL 
  HREF="mctp://www.yourserver.com/GlobalNewshtml/globalnews.cdf" 
  BASE="http://www.yourserver.com/GlobalNewshtml/" 
  ID="GlobalNews">
    <SELF HREF="http://www.yourserver.com/GlobalNewshtml/globalnews.cdf"/>
    <SCHEDULE><INTERVALTIME MIN="60"/></SCHEDULE>
    <TITLE>GlobalNews Mobile Channel</TITLE>
    <ABSTRACT>Up-to-the-minute news from around the globe.</ABSTRACT>
    <LOGO STYLE="Image" HREF="static/logoglobalnews.gif" ID="LOGO"/>
    <LOGO STYLE="Icon" HREF="static/icglobalnews.gif" ID="LOGOIC"/>
    <CHANSCRIPT VALUE="CS"/>
    <USAGE VALUE="MobileChannel"/>
    
    <ITEM HREF="index.htm" ID="CS"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/globalnews_home01.gif" ID="Head"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/logoglobalnews.gif" ID="LO"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/icglobalnews.gif" ID="IC"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/dot.gif" ID="DOT"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/news_ico.gif" ID="IC-NEWS"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/com_ico.gif" ID="IC-COM"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/soc_ico.gif" ID="IC-SOC"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/loc_ico.gif" ID="IC-LOC"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/tech_ico.gif" ID="IC-TECH"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/liv_ico.gif" ID="IC-LIV"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/ona_ico.gif" ID="IC-ONAIR"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/op_ico.gif" ID="IC-OP"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/wet_ico.gif" ID="IC-WET"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="static/sum_ico.gif" ID="IC-SUM"><USAGE VALUE="None"/></ITEM>
    <CHANNEL ID="NEWS"><USAGE VALUE="MobileData"/><CHANSCRIPT VALUE="NEWS1"/>
        <TITLE>News</TITLE>
        <ITEM HREF="news.htm" ID="NEWS1">
            <USAGE VALUE="None"/>
        </ITEM>
    </CHANNEL>
    <CHANNEL ID="COM"><USAGE VALUE="MobileData"/><CHANSCRIPT VALUE="COM1"/>
        <TITLE>CNBC & The Wall Street Journal. Business</TITLE>
        <ITEM HREF="business.htm" ID="COM1">
            <USAGE VALUE="None"/>
        </ITEM>
    </CHANNEL>
    <CHANNEL ID="SPT"><USAGE VALUE="MobileData"/><CHANSCRIPT VALUE="SPT1"/>
        <TITLE>Sports</TITLE>
        <ITEM HREF="sports.htm" ID="SPT1">
            <USAGE VALUE="None"/>
        </ITEM>
    </CHANNEL>
    <CHANNEL ID="LIV"><USAGE VALUE="MobileData"/><CHANSCRIPT VALUE="LIV1"/>
        <TITLE>Living & Travel</TITLE>
        <ITEM HREF="living.htm" ID="LIV1">
            <USAGE VALUE="None"/>
        </ITEM>
    </CHANNEL>
    <CHANNEL ID="TECH"><USAGE VALUE="MobileData"/><CHANSCRIPT VALUE="TECH1"/>
        <TITLE>Technology</TITLE>
        <ITEM HREF="technology.htm" ID="TECH1">
            <USAGE VALUE="None"/>
        </ITEM>
    </CHANNEL>
    <CHANNEL ID="OA"><USAGE VALUE="MobileData"/><CHANSCRIPT VALUE="OA1"/>
        <TITLE>On Air</TITLE>
        <ITEM HREF="onair.htm" ID="OA1">
            <USAGE VALUE="None"/>
        </ITEM>
    </CHANNEL>
    <CHANNEL ID="OP"><USAGE VALUE="MobileData"/><CHANSCRIPT VALUE="OP1"/>
        <TITLE>Opinion</TITLE>
        <ITEM HREF="opinion.htm" ID="OP1">
            <USAGE VALUE="None"/>
        </ITEM>
    </CHANNEL>
    <CHANNEL ID="WEA"><USAGE VALUE="MobileData"/><CHANSCRIPT VALUE="WEA1"/>
        <TITLE>Weather</TITLE>
        <ITEM HREF="weather.htm" ID="WEA1">
            <USAGE VALUE="None"/>
        </ITEM>
    </CHANNEL>
</CHANNEL>
