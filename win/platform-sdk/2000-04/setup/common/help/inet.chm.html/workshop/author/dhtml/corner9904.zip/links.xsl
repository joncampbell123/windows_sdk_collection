<xsl:stylesheet xmlns:xsl="http://www.w3.org/TR/WD-xsl">

<xsl:template match="/">
	<HTML>
	<HEAD>
	<TITLE>Links <xsl:value-of select="TOPICLIST/@TYPE" /></TITLE>
	<LINK REL="stylesheet" TYPE="text/css" HREF="links.css" />
	</HEAD>
	<BODY>
	<H1>Links <xsl:value-of select="TOPICLIST/@TYPE" /></H1>
	<TABLE CELLPADDING="3" CELLSPACING="0" BORDER="1">
	<xsl:apply-templates select="//TOPIC" />
	</TABLE>
	<P><BUTTON ONCLICK="window.alert(document.body.innerHTML);">View HTML</BUTTON></P>
	</BODY>
	</HTML>
</xsl:template>

<xsl:template match="TOPIC">
	<TR VALIGN="top">
	<TD>
		<xsl:eval>this.parentNode.selectSingleNode("@TYPE").text</xsl:eval> <xsl:value-of select="TITLE" />
	</TD>
	<TD>
		<A>
			<xsl:attribute name="HREF">http://msdn.microsoft.com<xsl:value-of select="URL" /></xsl:attribute>
			http://msdn.microsoft.com<xsl:value-of select="URL" />
		</A>
	</TD>
	</TR>
</xsl:template>

</xsl:stylesheet>