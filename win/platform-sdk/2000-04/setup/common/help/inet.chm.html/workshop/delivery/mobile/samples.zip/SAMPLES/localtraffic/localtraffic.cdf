<?XML version="1.0"?>
<CHANNEL 
  HREF="mctp://www.yourserver.com/localtraffic/localtraffic.cdf" 
  BASE="http://www.yourserver.com/localtraffic/" 
  ID="localtraffic">
    <SELF HREF="http://www.yourserver.com/localtraffic/localtraffic.cdf"/>
    <SCHEDULE><INTERVALTIME MIN="60"/></SCHEDULE>
    <TITLE>localtraffic Mobile Channel</TITLE>
    <ABSTRACT>Traffic news when and where you want it.</ABSTRACT>
    <LOGO STYLE="Image" HREF="images/logolocaltraffic.gif" ID="LOGO"/>
    <LOGO STYLE="Icon" HREF="images/iclocaltraffic.gif" ID="LOGOIC"/>
    <CHANSCRIPT VALUE="CS"/>
    <USAGE VALUE="MobileChannel"/>
    
    <ITEM HREF="LW_traffic.htm" ID="CS"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="images/logolocaltraffic.gif" ID="Head"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="images/traffic1.gif" ID="tr1"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="images/traffic2.gif" ID="tr2"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="images/traffic3.gif" ID="tr3"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="images/traffic4.gif" ID="tr4"><USAGE VALUE="None"/></ITEM>
    <ITEM HREF="images/next.gif" ID="next"><USAGE VALUE="None"/></ITEM>


<CHANNEL ID="Central"><USAGE VALUE="MobileData"/><CHANSCRIPT VALUE="Central"/>
        <TITLE>Central</TITLE>
        <ITEM HREF="central.htm" ID="Central">
            <USAGE VALUE="None"/>
        </ITEM>
    </CHANNEL>
<CHANNEL ID="North"><USAGE VALUE="MobileData"/><CHANSCRIPT VALUE="North"/>
        <TITLE>North</TITLE>
        <ITEM HREF="north.htm" ID="North">
            <USAGE VALUE="None"/>
        </ITEM>
    </CHANNEL>
<CHANNEL ID="East"><USAGE VALUE="MobileData"/><CHANSCRIPT VALUE="East"/>
        <TITLE>East</TITLE>
        <ITEM HREF="east.htm" ID="East">
            <USAGE VALUE="None"/>
        </ITEM>
    </CHANNEL>
<CHANNEL ID="South"><USAGE VALUE="MobileData"/><CHANSCRIPT VALUE="South"/>
        <TITLE>South</TITLE>
        <ITEM HREF="south.htm" ID="South">
            <USAGE VALUE="None"/>
        </ITEM>
    </CHANNEL>

</CHANNEL>
