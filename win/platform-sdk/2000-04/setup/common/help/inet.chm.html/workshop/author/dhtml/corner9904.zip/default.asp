<HTML>
<HEAD>

<TITLE>Code Corner "DXML" Samples</TITLE>

<META NAME="Author" CONTENT="George Young">
<META NAME="AuthorEmail" CONTENT="corner@microsoft.com">

<STYLE TYPE="text/css"><!--

	BODY { font-family:verdana; font-size:8pt; }
	H1 { font-size:14pt; font-weight:normal; }
	OL { line-height:15pt; }
	A:link { font-weight:bold; }
	A:visited { font-weight:bold; color:navy; }
	A:hover { font-weight:bold; text-decoration:none; }

--></STYLE>

</HEAD>

<BODY>

<H1>Code Corner "DXML" Samples</H1>

<P>The 5 samples below use the same XML file -- <A TARGET="_new" HREF="webdev.xml">webdev.xml</A> -- transformed using 5 different XSL stylesheets.  The purpose is to demonstrate how the same dataset can be easily rendered any number of different ways, using XSL, and to illustrate some very basic XSL techniques.</P>

<OL>
	<LI><A HREF="webdev.asp?xsl=list.xsl">webdev.asp?xsl=list.xsl</A> nested DHTML UL format.</LI>
	<LI><A HREF="webdev.asp?xsl=divs.xsl">webdev.asp?xsl=divs.xsl</A> nested DHTML DIV format.</LI>
	<LI><A HREF="webdev.asp?xsl=flat.xsl">webdev.asp?xsl=flat.xsl</A> plain flat DIV format.</LI>
	<LI><A HREF="webdev.asp?xsl=links.xsl">webdev.asp?xsl=links.xsl</A> list of (text) links in flat TABLE format.</LI>
	<LI><A HREF="webdev.asp?xsl=list_pp.xsl">webdev.asp?xsl=list_pp.xsl</A> "pretty print format" DHTML UL format (view source).</LI>
</OL>

Go to the latest MSDN Online Voices <A HREF="http://msdn.microsoft.com/voices/corner.asp">Code Corner</A> article.

</BODY>
</HTML>
