<%@LANGUAGE=JSCRIPT%>
<%
	var idCode = Request.QueryString("code");
        var schedule = Application("classesDoc");

        //Response.write(schedule.documentElement.nodeName);

	var classSS = Application("classXSL");

        var indexClass = schedule.nodeFromID(idCode);
        
        //Response.write(indexClass.xml);
        var newDoc = indexClass.transformNode(classSS.documentElement);
        Response.write(newDoc);
%>