<%@LANGUAGE=JSCRIPT%>
<%
	var schedule = Application("classesDoc");
  	
        var classes = schedule.documentElement.childNodes.item(0);
        
%>
<DIV style="background-color:blue;color:white">
<H1>Class Viewer</H1>
</DIV>
<XML id=classDoc></XML>
<BR>
<BR>
<TABLE>
<TR>
<TD><SPAN>Class:</SPAN></TD><TD><DIV ID="classTitle">
<SELECT NAME='classTitles' SIZE='1' onchange='getClassInfo()'>
<%for (var i=0;i<classes.childNodes.length;i++){%>
<OPTION VALUE="<%=classes.childNodes.item(i).getAttribute("code")%>"><%=classes.childNodes.item(i).getAttribute("title")%></OPTION>
<%}%>
</SELECT></DIV></TD>
</TR>
<TR>
<TD><SPAN>Units:</SPAN></TD><TD><DIV ID="classUnits"></DIV></TD>
</TR>
<TR>
<TD VALIGN="top"><SPAN>Teachers:</SPAN></TD><TD><DIV ID="teachers"></DIV></TD>
</TR>
<TR>
<TD VALIGN="top"><SPAN>Students:</SPAN></TD><TD><DIV ID="students"></DIV></TD>
</TR>
</TABLE>
<BR>

<SCRIPT>
function getClassInfo(){
  var code = classTitles.value;
  classDoc.async = false;
  classDoc.load("getClass.asp?code=" + code);
  classUnits.innerHTML = makeSelect("units", classDoc.cloneNode(true));
  teachers.innerHTML = makeTable(classDoc.documentElement.childNodes(0).cloneNode(true));
  students.innerHTML = makeTable(classDoc.documentElement.childNodes(1).cloneNode(true));
}

function makeSelect(attName, xmlDoc){
  var contextAtt = xmlDoc.documentElement.attributes.getNamedItem(attName);
  var schemaDef = contextAtt.definition;
  var enumArray = new Array();
  enumArray = schemaDef.getAttribute("dt:values").split(" ");
  
  var selectStr = "<SELECT NAME='select" + attName + "' SIZE='1' onchange='updateUnits()'>";
  for (var i=0; i < enumArray.length; i++){
    if (enumArray[i] == contextAtt.nodeValue)
      selectStr += "<OPTION Value='" + enumArray[i] + "' SELECTED>" + enumArray[i] + "</OPTION>";
    else
      selectStr += "<OPTION Value='" + enumArray[i] + "'>" + enumArray[i] + "</OPTION>";
  }
  selectStr += "</SELECT>";
  return selectStr;
}

function makeTable(node){
  var tableStr = "<TABLE BORDER>";
  for (var i=0;i<node.childNodes.length;i++){
    tableStr += "<TR><TD><SPAN>" + node.childNodes(i).getAttribute("name") + "</TD></TR>";
  }
  tableStr += "</TABLE>";
  return tableStr;
}
</SCRIPT>
</BODY>
</HTML>