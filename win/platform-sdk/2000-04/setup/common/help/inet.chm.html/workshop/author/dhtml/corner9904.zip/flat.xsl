<xsl:stylesheet xmlns:xsl="http://www.w3.org/TR/WD-xsl">

<xsl:template match="/">
	<HTML>
	<HEAD>
	<TITLE>Flat <xsl:value-of select="TOPICLIST/@TYPE" /></TITLE>
	<LINK REL="stylesheet" TYPE="text/css" HREF="flat.css" />
	</HEAD>
	<BODY>
	<H1>Flat <xsl:value-of select="TOPICLIST/@TYPE" /></H1>
	<xsl:apply-templates select="//TOPIC"/>
	<P><BUTTON ONCLICK="window.alert(document.body.innerHTML);">View HTML</BUTTON></P>
	</BODY>
	</HTML>
</xsl:template>

<xsl:template match="TOPIC">
	<DIV>
		<A TARGET="_new">
			<xsl:attribute name="HREF">http://msdn.microsoft.com<xsl:value-of select="URL" /></xsl:attribute>
			<xsl:eval>this.parentNode.selectSingleNode("@TYPE").text</xsl:eval> <xsl:value-of select="TITLE" />
		</A>
	</DIV>
</xsl:template>

</xsl:stylesheet>