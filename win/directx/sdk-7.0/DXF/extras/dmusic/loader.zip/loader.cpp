// loader.cpp 
//
// (c) 1999 Microsoft Corporation.
//

#include <objbase.h>
#include <initguid.h>
#include "loader.h"
#include "dmusicc.h"
#include "dmusici.h"
#include <share.h>

//  NEED_GM_SET causes the default GM set to be loaded by the CLoader.Init() call.

#define NEED_GM_SET

int main(int argc, char* argv[])
{
	CoInitialize(NULL);
    CLoader *pLoader = new CLoader;
    if (pLoader)
    {
        pLoader->Init();
        IDirectMusicPerformance *pPerformance = NULL;
        HRESULT hr = CoCreateInstance(
                CLSID_DirectMusicPerformance,
                NULL,
                CLSCTX_INPROC, 
                IID_IDirectMusicPerformance,
                (void**)&pPerformance);
        if (SUCCEEDED(hr))
        {
            hr = pPerformance->Init(NULL,NULL,NULL);
            hr = pPerformance->AddPort( NULL );
            IDirectMusicSegment *pSegment;
            DMUS_OBJECTDESC ObjDesc;     
            wcscpy(ObjDesc.wszFileName,L"test.mid");
            ObjDesc.guidClass = CLSID_DirectMusicSegment;
            ObjDesc.dwSize = sizeof(DMUS_OBJECTDESC);
            ObjDesc.dwValidData = DMUS_OBJ_CLASS | DMUS_OBJ_FILENAME;
	        hr = pLoader->GetObject( &ObjDesc,
                    IID_IDirectMusicSegment, (void**) &pSegment );
            if (SUCCEEDED(hr))
            {
                pSegment->SetParam(GUID_StandardMIDIFile,-1,0,0,(void *) pPerformance);
              	pSegment->SetParam(GUID_Download,-1,0,0,(void *) pPerformance);
                pPerformance->PlaySegment(pSegment,DMUS_SEGF_QUEUE,0,NULL);
                Sleep(20000);
                pPerformance->Stop(pSegment,0,0,0);
              	pSegment->SetParam(GUID_Unload,-1,0,0,(void *) pPerformance);
            }
            pPerformance->CloseDown();
            pPerformance->Release();
        }
        delete pLoader;
    }
    CoUninitialize();
	return 0;
}

/*  DirectMusic handles file names and object names in UNICODE. 
    This means you need to track whether your dll is running
    on a Win9x or WinNT machine, in order to make the right calls
    for file io. The global variable g_fIsUnicode should be initialized
    at startup with a call to setUnicodeMode(). 
    In this way, your binary code runs on both Win9x and NT.
*/

static BOOL g_fIsUnicode;

void setUnicodeMode()

{
    OSVERSIONINFO osvi;
    osvi.dwOSVersionInfoSize = sizeof(osvi);
    GetVersionEx(&osvi);
    g_fIsUnicode = 
		(osvi.dwPlatformId != VER_PLATFORM_WIN32_WINDOWS);
}

CFileStream::CFileStream( CLoader *pLoader)

{
	m_cRef = 1;         // Start with one reference for caller.
	m_pFile = NULL;     // No file yet.
	m_pLoader = pLoader; // Link to loader, so loader can be found from stream.
	if (pLoader)
	{
		pLoader->AddRefP(); // Addref the private counter to avoid cyclic references.
	}
}

CFileStream::~CFileStream() 

{ 
	if (m_pLoader)
	{
		m_pLoader->ReleaseP();
	}
	Close();
}

HRESULT CFileStream::Open(WCHAR * lpFileName,DWORD dwDesiredAccess)

{
	Close();
    if( dwDesiredAccess == GENERIC_READ )
    {
		if (g_fIsUnicode)
		{
			m_pFile = _wfsopen( lpFileName, L"rb", _SH_DENYWR );
		}
		else
		{
			char path[MAX_PATH];
			wcstombs( path, lpFileName, MAX_PATH );
			m_pFile = _fsopen( path, "rb", _SH_DENYWR );
		}
	}
    else if( dwDesiredAccess == GENERIC_WRITE )
    {
		if (g_fIsUnicode)
		{
			m_pFile = _wfsopen( lpFileName, L"wb", _SH_DENYNO );
		}
		else
		{
			char path[MAX_PATH];
			wcstombs( path, lpFileName, MAX_PATH );
			m_pFile = _fsopen( path, "wb", _SH_DENYNO );
		}   
	}
	if (m_pFile == NULL)
	{
		return DMUS_E_LOADER_FAILEDOPEN;
	}
	return S_OK;
}

HRESULT CFileStream::Close()

{
	if (m_pFile)
	{
		fclose(m_pFile);
	}
	m_pFile = NULL;
	return S_OK;
}

STDMETHODIMP CFileStream::QueryInterface( const IID &riid, void **ppvObj )
{
    if (riid == IID_IUnknown || riid == IID_IStream) {
        *ppvObj = static_cast<IStream*>(this);
        AddRef();
        return S_OK;
    }
	else if (riid == IID_IDirectMusicGetLoader) 
    {
        *ppvObj = static_cast<IDirectMusicGetLoader*>(this);
        AddRef();
        return S_OK;
    }
    *ppvObj = NULL;
    return E_NOINTERFACE;
}


/*  The GetLoader interface is used to find the loader from the IStream.
    When an object is loading data from the IStream via the object's
    IPersistStream interface, it may come across a reference chunk that
    references another object that also needs to be loaded. It QI's the
    IStream for the IDirectMusicGetLoader interface. It then uses this
    interface to call GetLoader and get the actual loader. Then, it can
    call GetObject on the loader to load the referenced object.
*/

STDMETHODIMP CFileStream::GetLoader(
	IDirectMusicLoader ** ppLoader)	// Returns an AddRef'd pointer to the loader.

{
	if (m_pLoader)
	{
		return m_pLoader->QueryInterface( IID_IDirectMusicLoader,(void **) ppLoader );
	}
	*ppLoader = NULL;
	return E_NOINTERFACE;
}


STDMETHODIMP_(ULONG) CFileStream::AddRef()
{
    return InterlockedIncrement(&m_cRef);
}

STDMETHODIMP_(ULONG) CFileStream::Release()
{
    if (!InterlockedDecrement(&m_cRef)) 
	{
		delete this;
		return 0;
    }
    return m_cRef;
}

/* IStream methods */
STDMETHODIMP CFileStream::Read( void* pv, ULONG cb, ULONG* pcbRead )
{
	size_t dw;
	dw = fread( pv, sizeof(char), cb, m_pFile );
	if( cb == dw )
	{
		if( pcbRead != NULL )
		{
			*pcbRead = cb;
		}
		return S_OK;
	}
	return E_FAIL ;
}

STDMETHODIMP CFileStream::Write( const void* pv, ULONG cb, ULONG* pcbWritten )
{
	if( cb == fwrite( pv, sizeof(char), cb, m_pFile ))
	{
		if( pcbWritten != NULL )
		{
			*pcbWritten = cb;
		}
		return S_OK;
	}
    return STG_E_MEDIUMFULL;
}

STDMETHODIMP CFileStream::Seek( LARGE_INTEGER dlibMove, DWORD dwOrigin, ULARGE_INTEGER* plibNewPosition )
{
	// fseek can't handle a LARGE_INTEGER seek...
	long lOffset;

	lOffset = dlibMove.LowPart;

	int i = fseek( m_pFile, lOffset, dwOrigin );
	if( i ) 
	{
		return E_FAIL;
	}

	if( plibNewPosition != NULL )
	{
		plibNewPosition->LowPart = ftell( m_pFile );
		if( lOffset < 0 )
		{
			plibNewPosition->HighPart = -1;
		}
		else
		{
			plibNewPosition->HighPart = 0;
		}
	}
    return S_OK;
}

STDMETHODIMP CFileStream::SetSize( ULARGE_INTEGER /*libNewSize*/ )
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CFileStream::CopyTo( IStream* /*pstm */, ULARGE_INTEGER /*cb*/,
                     ULARGE_INTEGER* /*pcbRead*/,
                     ULARGE_INTEGER* /*pcbWritten*/ )
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CFileStream::Commit( DWORD /*grfCommitFlags*/ )
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CFileStream::Revert()
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CFileStream::LockRegion( ULARGE_INTEGER /*libOffset*/, ULARGE_INTEGER /*cb*/,
                         DWORD /*dwLockType*/ )
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CFileStream::UnlockRegion( ULARGE_INTEGER /*libOffset*/, ULARGE_INTEGER /*cb*/,
                           DWORD /*dwLockType*/)
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CFileStream::Stat( STATSTG* /*pstatstg*/, DWORD /*grfStatFlag*/ )
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CFileStream::Clone( IStream** /*ppstm*/ )
{ 
	return E_NOTIMPL; 
}


CMemStream::CMemStream( CLoader *pLoader)

{
	m_cRef = 1;
	m_pbData = NULL;
	m_llLength = 0;
	m_llPosition = 0;
	m_pLoader = pLoader;
	if (pLoader)
	{
		pLoader->AddRefP();
	}
}

CMemStream::~CMemStream() 

{ 
	if (m_pLoader)
	{
		m_pLoader->ReleaseP();
	}
	Close();
}

HRESULT CMemStream::Open(BYTE *pbData, LONGLONG llLength)

{
	Close();
	m_pbData = pbData;
	m_llLength = llLength;
	m_llPosition = 0;
	if ((pbData == NULL) || (llLength == 0))
	{
		return DMUS_E_LOADER_FAILEDOPEN;
	}
	if (IsBadReadPtr(pbData, (DWORD) llLength))
	{
		m_pbData = NULL;
		m_llLength = 0;
		return DMUS_E_LOADER_FAILEDOPEN;
	}
	return S_OK;
}

HRESULT CMemStream::Close()

{
	m_pbData = NULL;
	m_llLength = 0;
	return S_OK;
}

STDMETHODIMP CMemStream::QueryInterface( const IID &riid, void **ppvObj )
{
    if (riid == IID_IUnknown || riid == IID_IStream) {
        *ppvObj = static_cast<IStream*>(this);
        AddRef();
        return S_OK;
    }
	else if (riid == IID_IDirectMusicGetLoader) 
    {
        *ppvObj = static_cast<IDirectMusicGetLoader*>(this);
        AddRef();
        return S_OK;
    }
    *ppvObj = NULL;
    return E_NOINTERFACE;
}


STDMETHODIMP CMemStream::GetLoader(
	IDirectMusicLoader ** ppLoader)	

{
	if (m_pLoader)
	{
		return m_pLoader->QueryInterface( IID_IDirectMusicLoader,(void **) ppLoader );
	}
	*ppLoader = NULL;
	return E_NOINTERFACE;
}


STDMETHODIMP_(ULONG) CMemStream::AddRef()
{
    return InterlockedIncrement(&m_cRef);
}

STDMETHODIMP_(ULONG) CMemStream::Release()
{
    if (!InterlockedDecrement(&m_cRef)) 
	{
		delete this;
		return 0;
    }
    return m_cRef;
}

/* IStream methods */
STDMETHODIMP CMemStream::Read( void* pv, ULONG cb, ULONG* pcbRead )
{
	if ((cb + m_llPosition) <= m_llLength)
	{
		memcpy(pv,&m_pbData[m_llPosition],cb);
		m_llPosition += cb;
		if( pcbRead != NULL )
		{
			*pcbRead = cb;
		}
		return S_OK;
	}
	return E_FAIL ;
}

STDMETHODIMP CMemStream::Write( const void* pv, ULONG cb, ULONG* pcbWritten )
{
    return E_NOTIMPL;
}

STDMETHODIMP CMemStream::Seek( LARGE_INTEGER dlibMove, DWORD dwOrigin, ULARGE_INTEGER* plibNewPosition )
{
	// Since we only parse RIFF data, we can't have a file over 
	// DWORD in length, so disregard high part of LARGE_INTEGER.

	LONGLONG llOffset;

	llOffset = dlibMove.QuadPart;
	if (dwOrigin == STREAM_SEEK_CUR)
	{
		llOffset += m_llPosition;
	} 
	else if (dwOrigin == STREAM_SEEK_END)
	{
		llOffset += m_llLength;
	}
	if ((llOffset >= 0) && (llOffset <= m_llLength))
	{
		m_llPosition = llOffset;
	}
	else return E_FAIL;

	if( plibNewPosition != NULL )
	{
		plibNewPosition->QuadPart = m_llPosition;
	}
    return S_OK;
}

STDMETHODIMP CMemStream::SetSize( ULARGE_INTEGER /*libNewSize*/ )
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CMemStream::CopyTo( IStream* /*pstm */, ULARGE_INTEGER /*cb*/,
                     ULARGE_INTEGER* /*pcbRead*/,
                     ULARGE_INTEGER* /*pcbWritten*/ )
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CMemStream::Commit( DWORD /*grfCommitFlags*/ )
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CMemStream::Revert()
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CMemStream::LockRegion( ULARGE_INTEGER /*libOffset*/, ULARGE_INTEGER /*cb*/,
                         DWORD /*dwLockType*/ )
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CMemStream::UnlockRegion( ULARGE_INTEGER /*libOffset*/, ULARGE_INTEGER /*cb*/,
                           DWORD /*dwLockType*/)
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CMemStream::Stat( STATSTG* /*pstatstg*/, DWORD /*grfStatFlag*/ )
{ 
	return E_NOTIMPL; 
}

STDMETHODIMP CMemStream::Clone( IStream** /*ppstm*/ )
{ 
	return E_NOTIMPL; 
}


CLoader::CLoader()

{
    InitializeCriticalSection(&m_CriticalSection);
	m_cRef = 1;
	m_cPRef = 0;
    m_pObjectList = NULL;
    m_wzSearchPath[0] = 0;
}

CLoader::~CLoader()

{
    while (m_pObjectList)
    {
        CObjectRef * pObject = m_pObjectList;
        m_pObjectList = pObject->m_pNext;
        if (pObject->m_pObject)
        {
            pObject->m_pObject->Release();
        }
        delete pObject;
    }
    DeleteCriticalSection(&m_CriticalSection);
}


HRESULT CLoader::Init()

{
    HRESULT hr = S_OK;
    // Initialize loader to handle Unicode properly for this machine. 
    setUnicodeMode();
    // If support for the GM set is desired, create a direct music loader
    // and get the GM dls collection from it, then release that loader.
#ifdef NEED_GM_SET
    IDirectMusicLoader *pLoader;
    hr = CoCreateInstance(            
	    CLSID_DirectMusicLoader,
        NULL,            
	    CLSCTX_INPROC,             
	    IID_IDirectMusicLoader,
        (void**)&pLoader); 
    if (SUCCEEDED(hr))
    {
        DMUS_OBJECTDESC ObjDesc;     
        IDirectMusicObject* pGMSet = NULL; 
        ObjDesc.guidClass = CLSID_DirectMusicCollection;
        ObjDesc.guidObject = GUID_DefaultGMCollection;
        ObjDesc.dwSize = sizeof(DMUS_OBJECTDESC);
        ObjDesc.dwValidData = DMUS_OBJ_CLASS | DMUS_OBJ_OBJECT;
	    hr = pLoader->GetObject( &ObjDesc,
                IID_IDirectMusicObject, (void**) &pGMSet );
        if (SUCCEEDED(hr))
        {
            CObjectRef *pRef = new CObjectRef();
            if (pRef)
            {
                pRef->m_guidObject = GUID_DefaultGMCollection;
                pRef->m_pNext = m_pObjectList;
                m_pObjectList = pRef;
                pRef->m_pObject = pGMSet;
                pGMSet->AddRef();
            }
            pGMSet->Release();
        }
        pLoader->Release();
    }
#endif
    return hr;
}

// CLoader::QueryInterface
//
STDMETHODIMP
CLoader::QueryInterface(const IID &iid,
                                   void **ppv)
{
    if (iid == IID_IUnknown || iid == IID_IDirectMusicLoader) {
        *ppv = static_cast<IDirectMusicLoader*>(this);
    }
	else 
	{
        *ppv = NULL;
        return E_NOINTERFACE;
    }
    reinterpret_cast<IUnknown*>(this)->AddRef();
    return S_OK;
}


// CLoader::AddRef
//
STDMETHODIMP_(ULONG)
CLoader::AddRef()
{
    return InterlockedIncrement(&m_cRef);
}

ULONG CLoader::AddRefP()
{
    return InterlockedIncrement(&m_cPRef);
}

// CLoader::Release
//
STDMETHODIMP_(ULONG)
CLoader::Release()
{
    if (!InterlockedDecrement(&m_cRef)) 
	{
		InterlockedIncrement(&m_cRef);		// Keep streams from deleting loader.
		ClearCache(GUID_DirectMusicAllTypes);
		if (!InterlockedDecrement(&m_cRef))
		{
			if (!m_cPRef)
			{
				delete this;
				return 0;
			}
		}
    }
    return m_cRef;
}

ULONG CLoader::ReleaseP()
{
    if (!InterlockedDecrement(&m_cPRef)) 
	{
		if (!m_cRef)
		{
			delete this;
			return 0;
		}
    }
    return m_cPRef;
}

STDMETHODIMP CLoader::GetObject(
	LPDMUS_OBJECTDESC pDESC,	// Description of the requested object in <t DMUS_OBJECTDESC> structure.
    REFIID riid,                // The interface type to return in <p ppv>
	LPVOID FAR *ppv)	        // Receives the interface on success.

{
	HRESULT hr = E_NOTIMPL;

    EnterCriticalSection(&m_CriticalSection);
    IDirectMusicObject * pIObject;
    // At this point, the loader should check with all the objects it already
    // has loaded. It should look for file name, object guid, and name.
    // In this case, we are being cheap and looking for only the object
    // guid, which should be guaranteed to be unique. If the files are all
    // created with guids, (and producer supports that) this should work
    // well.
    // If it sees that the object is already loaded, it should
    // return a pointer to that one and increment the reference. 
    // It is very important to keep the previously loaded objects
    // "cached" in this way. Otherwise, objects, like DLS collections, will get loaded
    // multiple times with a very great expense in memory and efficiency!
    // This is primarily an issue when object reference each other. For
    // example, segments reference style and collection objects. 
    if (pDESC->dwValidData & DMUS_OBJ_OBJECT)
    {
        CObjectRef * pObject = NULL;
        for (pObject = m_pObjectList;pObject;pObject = pObject->m_pNext)
        {
            if (pDESC->guidObject == pObject->m_guidObject)
            {
                break;
            }
        }
        if (pObject)
        {
            hr = E_FAIL;
            pIObject = pObject->m_pObject;
            if (pObject->m_pObject)
            {
                hr = pObject->m_pObject->QueryInterface( riid, ppv );
            }
            LeaveCriticalSection(&m_CriticalSection);
	        return hr;
        }
    }
    if (pDESC->dwValidData & DMUS_OBJ_FILENAME)
	{
		hr = LoadFromFile(pDESC,&pIObject);
	}
	else if (pDESC->dwValidData & DMUS_OBJ_MEMORY)
	{
		hr = LoadFromMemory(pDESC,&pIObject);
	}
	else hr = DMUS_E_LOADER_NOFILENAME;
    if (SUCCEEDED(hr))
    {
        // If we succeeded in loading it, keep a pointer to it, 
        // addref it, and keep the guid for finding it next time.
        // To get the GUID, call ParseDescriptor on the object and
        // it will fill in the fields it knows about, including the
        // guid.
        DMUS_OBJECTDESC DESC;
		memset((void *)&DESC,0,sizeof(DESC));
		DESC.dwSize = sizeof (DMUS_OBJECTDESC);	
		pIObject->GetDescriptor(&DESC);
        if (DESC.dwValidData & DMUS_OBJ_OBJECT)
        {
            CObjectRef * pObject = new CObjectRef;
            if (pObject)
            {
                pObject->m_guidObject = DESC.guidObject;
                pObject->m_pNext = m_pObjectList;
                m_pObjectList = pObject;
                pObject->m_pObject = pIObject;
                pIObject->AddRef();
            }
        }
        hr = pIObject->QueryInterface( riid, ppv );
        pIObject->Release();

    }
	LeaveCriticalSection(&m_CriticalSection);
	return hr;
}

HRESULT CLoader::LoadFromFile(LPDMUS_OBJECTDESC pDesc,IDirectMusicObject ** ppIObject)

{
	HRESULT hr;
    
	hr = CoCreateInstance(pDesc->guidClass,
		NULL,CLSCTX_INPROC_SERVER,IID_IDirectMusicObject,
		(void **) ppIObject);
	if (SUCCEEDED(hr))
	{
		WCHAR wzFullPath[DMUS_MAX_FILENAME];
		ZeroMemory( wzFullPath, sizeof(WCHAR) * DMUS_MAX_FILENAME );
		CFileStream *pStream = new CFileStream ( this );
		if (pStream)
		{
			if (pDesc->dwValidData & DMUS_OBJ_FULLPATH)
			{
				wcscpy(wzFullPath,pDesc->wszFileName);
			}
			else
			{
				// Insert code to get path that was installed with SetSearchDirectory
                // and copy to wzFullPath here. 
                wcscpy(wzFullPath,m_wzSearchPath);
				wcscat(wzFullPath,pDesc->wszFileName);
			}
			hr = pStream->Open(wzFullPath,GENERIC_READ);
			if (SUCCEEDED(hr))
			{
				IPersistStream* pIPS;
				hr = (*ppIObject)->QueryInterface( IID_IPersistStream, (void**)&pIPS );
				if (SUCCEEDED(hr))
				{
                    // Now that we have the IPersistStream interface from the object, we can ask it to load from our stream!
					hr = pIPS->Load( pStream );
					pIPS->Release();
				}
			}
			pStream->Release();
		}
		else
		{
			hr = E_OUTOFMEMORY;
		}
        if (FAILED(hr))
        {
       		(*ppIObject)->Release();
        }
	}
	return hr;
}

HRESULT CLoader::LoadFromMemory(LPDMUS_OBJECTDESC pDesc,IDirectMusicObject ** ppIObject)

{
	HRESULT hr;
	hr = CoCreateInstance(pDesc->guidClass,
		NULL,CLSCTX_INPROC_SERVER,IID_IDirectMusicObject,
		(void **) ppIObject);
	if (SUCCEEDED(hr))
	{
		CMemStream *pStream = new CMemStream ( this );
		if (pStream)
		{
			hr = pStream->Open(pDesc->pbMemData,pDesc->llMemLength);
			if (SUCCEEDED(hr))
			{
				IPersistStream* pIPS;
				hr = (*ppIObject)->QueryInterface( IID_IPersistStream, (void**)&pIPS );
				if (SUCCEEDED(hr))
				{
                    // Now that we have the IPersistStream interface from the object, we can ask it to load from our stream!
					hr = pIPS->Load( pStream );
					pIPS->Release();
				}
			}
			pStream->Release();
		}
		else
		{
			hr = E_OUTOFMEMORY;
		}
        if (FAILED(hr))
        {
       		(*ppIObject)->Release();
        }
	}
	return hr;
}


STDMETHODIMP CLoader::SetObject(
	LPDMUS_OBJECTDESC pDESC)

{
	HRESULT hr = E_NOTIMPL;
    EnterCriticalSection(&m_CriticalSection);
	LeaveCriticalSection(&m_CriticalSection);
 	return hr;
}


STDMETHODIMP CLoader::SetSearchDirectory(
	REFCLSID rguidClass,	// Class id identifies which clas of objects this pertains to.
					        // Optionally, GUID_DirectMusicAllTypes specifies all classes. 
	WCHAR *pwzPath,         // File path for directory. Must be a valid directory and
					        // must be less than MAX_PATH in length.
	BOOL fClear)	        // If TRUE, clears all information about objects
					        // prior to setting directory. 
					        // This helps avoid accessing objects from the
					        // previous directory that may have the same name.
					        // However, this will not remove cached objects.
										
{
    // Cheat and use the same search path for all class types. 
    // This is not correct, but, hey, this is a app specific implementation
    // of the loader so we can do what we want!
    wcscpy(m_wzSearchPath,pwzPath);
    return S_OK;
}

STDMETHODIMP CLoader::ScanDirectory(
	REFCLSID rguidClass,	// Class id identifies which class of objects this pertains to.
	WCHAR *pszFileExtension,// File extension for type of file to look for. 
							// For example, L"sty" for style files. L"*" will look in all
							// files. L"" or NULL will look for files without an
							// extension.
	WCHAR *pszCacheFileName	// Optional storage file to store and retrieve
							// cached file information. This file is created by 
							// the first call to <om IDirectMusicLoader::ScanDirectory>
							// and used by subsequant calls. NULL if cache file
							// not desired.
)

{
    return E_NOTIMPL;
}


STDMETHODIMP CLoader::CacheObject(
	IDirectMusicObject * pObject)	// Object to cache.

{
    return E_NOTIMPL;
}


STDMETHODIMP CLoader::ReleaseObject(
	IDirectMusicObject * pObject)	// Object to release.

{
    return E_NOTIMPL;
}

STDMETHODIMP CLoader::ClearCache(
	REFCLSID rguidClass)	// Class id identifies which class of objects to clear.
					        // Optionally, GUID_DirectMusicAllTypes specifies all types. 

{
    return E_NOTIMPL;
}

STDMETHODIMP CLoader::EnableCache(
	REFCLSID rguidClass,	// Class id identifies which class of objects to cache.
					        // Optionally, GUID_DirectMusicAllTypes specifies all types. 
	BOOL fEnable)	        // TRUE to enable caching, FALSE to clear and disable.
{
    return E_NOTIMPL;
}

STDMETHODIMP CLoader::EnumObject(
	REFCLSID rguidClass,	// Class ID for class of objects to view. 
	DWORD dwIndex,			// Index into list. Typically, starts with 0 and increments.
	LPDMUS_OBJECTDESC pDESC)// DMUS_OBJECTDESC structure to be filled with data about object.
									   
{
    return E_NOTIMPL;
}
